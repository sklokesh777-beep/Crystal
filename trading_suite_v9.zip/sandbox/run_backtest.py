"""
Advanced backtest runner (final + Part 7 risk-adjusted upgrades).

Pulls ~15 years of real US equity data for the **full S&P 500 by default** and
backtests proven swing strategies, with an SPY buy-and-hold benchmark and a
suite of optional risk-adjusted upgrades (all OFF by default, see README Part 7):

  --trailing-stop           ratchet the ATR stop up, never down
  --score-weighted-sizing   scale risk 0.5%..1.5% by confluence-score percentile
  --max-correlation 0.7     skip entries correlated with 2+ held names
  --graduated-regime        continuous SPY-regime exposure multiplier (vs binary)
  --vol-contraction         (TrendPullback) only buy when volatility is contracting
  --stress-costs            compare CAGR/PF at 1x / 2x / 3x costs

Examples
--------
  python run_backtest.py
  python run_backtest.py --compare
  python run_backtest.py --strategy trendpullback --oos-split 2019-01-01
  python run_backtest.py --strategy trendpullback --trailing-stop
  python run_backtest.py --strategy trendpullback --score-weighted-sizing
  python run_backtest.py --strategy trendpullback --max-correlation 0.7
  python run_backtest.py --strategy trendpullback --graduated-regime
  python run_backtest.py --strategy trendpullback --vol-contraction
  python run_backtest.py --strategy trendpullback --stress-costs
"""
from __future__ import annotations

import argparse
from datetime import date

import numpy as np
import pandas as pd

from backtest import data as datamod
from backtest import indicators as ind
from backtest import report as rpt
from backtest import universe as uni
from backtest.engine import PortfolioBacktester, BacktestResult
from backtest.metrics import equity_metrics, trade_metrics, spy_benchmark
from backtest.strategies import build_strategy

ALL_STRATS = ["rsi2", "bollinger", "smacross", "trendpullback"]


def market_regime(data: dict, trend: int = 200):
    """Binary regime gate: SPY above its 200-SMA (legacy default)."""
    if "SPY" not in data:
        return None
    close = data["SPY"]["Close"]
    return (close > ind.sma(close, trend)).fillna(False)


def graduated_regime(data: dict, trend: int = 200):
    """
    Feature 4: continuous regime -> exposure multiplier in [0, 1] from
    (a) SPY's % distance from its 200-SMA and (b) the 200-SMA's 20-day slope.
    1.0 in a strong uptrend, ~0.5 in a weak/rolling-over tape, 0.0 in a
    confirmed downtrend.
    """
    if "SPY" not in data:
        return None
    close = data["SPY"]["Close"]
    sma200 = ind.sma(close, trend)
    dist = (close - sma200) / sma200                     # fractional
    slope_pct = ind.sma_slope(close, trend, 20)          # in %
    d = ((dist + 0.05) / 0.10).clip(0, 1)                # -5%..+5% -> 0..1
    sl = ((slope_pct + 1.5) / 3.0).clip(0, 1)            # -1.5%..+1.5% -> 0..1
    raw = (0.5 * d + 0.5 * sl).clip(0, 1)
    downtrend = (dist < -0.03) & (slope_pct < -0.5)
    return raw.where(~downtrend, 0.0).fillna(0.0)


def spy_daily_returns(data: dict):
    if "SPY" not in data:
        return None
    return data["SPY"]["Close"].pct_change().fillna(0.0)


def slice_result(res: BacktestResult, start, end, label_suffix: str) -> BacktestResult:
    eq = res.equity.loc[start:end]
    inv = res.invested_pct.loc[start:end]
    init = float(eq.iloc[0]) if len(eq) else res.initial_capital
    lo, hi = pd.Timestamp(start), pd.Timestamp(end)
    trades = [t for t in res.trades if lo <= t.entry_date <= hi]
    return BacktestResult(eq, inv, trades, init,
                          f"{res.strategy_name} [{label_suffix}]", res.universe)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Backtest proven swing strategies "
                                            "on ~15 years of real US data.")
    p.add_argument("--strategy", default="trendpullback", choices=ALL_STRATS)
    p.add_argument("--tickers", nargs="+", default=None)
    p.add_argument("--curated", action="store_true",
                   help="Use the small ~26-name basket instead of the S&P 500.")
    p.add_argument("--sp500", action="store_true",
                   help="Explicitly use the full S&P 500 (this is already the "
                        "default; flag kept for convenience/compatibility).")
    p.add_argument("--sp1000", action="store_true",
                   help="Use a ~1000-name universe (S&P 500 + 400 mid + 100 "
                        "small). Slower; tends to DILUTE the edge (README Part 9).")
    p.add_argument("--years", type=int, default=15)
    p.add_argument("--start", default="2010-01-01")
    p.add_argument("--end", default=None)
    p.add_argument("--capital", type=float, default=100_000.0)
    p.add_argument("--max-positions", type=int, default=10)
    p.add_argument("--position-size", type=float, default=0.10)
    p.add_argument("--commission", type=float, default=1.0)
    p.add_argument("--slippage-bps", type=float, default=5.0)
    p.add_argument("--rsi-entry", type=float, default=None)
    p.add_argument("--max-hold", type=int, default=None)
    p.add_argument("--stop-atr", type=float, default=None)
    p.add_argument("--min-score", type=float, default=0.0)
    p.add_argument("--spy-overlay", action="store_true")
    p.add_argument("--oos-split", default=None)
    p.add_argument("--no-regime", action="store_true")
    p.add_argument("--no-cache", action="store_true")
    p.add_argument("--compare", action="store_true")
    # ---- Part 7 opt-in upgrades ----
    p.add_argument("--trailing-stop", action="store_true",
                   help="Feature 1: ratchet the ATR stop up, never down.")
    p.add_argument("--score-weighted-sizing", action="store_true",
                   help="Feature 2: risk 0.5%%..1.5%% by confluence-score percentile.")
    p.add_argument("--max-correlation", type=float, default=None,
                   help="Feature 3: skip entry correlated > X with 2+ held names.")
    p.add_argument("--graduated-regime", action="store_true",
                   help="Feature 4: continuous regime exposure multiplier.")
    p.add_argument("--vol-contraction", action="store_true",
                   help="Feature 5: TrendPullback only when volatility contracts.")
    p.add_argument("--vol-contraction-ratio", type=float, default=0.90)
    p.add_argument("--stress-costs", action="store_true",
                   help="Feature 7: compare 1x/2x/3x commission+slippage.")
    # ---- v9 sprint ----
    p.add_argument("--live-sprint", action="store_true",
                   help="v9: Monte-Carlo validate the 60-trades-in-10-days plan.")
    p.add_argument("--n-positions", type=int, default=18,
                   help="Concurrent open positions for the sprint (default 18).")
    p.add_argument("--mc-windows", type=int, default=250,
                   help="Number of random 10-day windows to sample.")
    p.add_argument("--window-len", type=int, default=10,
                   help="Trading days per window (your sprint is 10).")
    return p.parse_args()


def _make_bt(args, strategy, cost_mult: float = 1.0):
    return PortfolioBacktester(
        strategy=strategy, initial_capital=args.capital,
        max_positions=args.max_positions,
        position_size_pct=args.position_size,
        commission_per_trade=args.commission * cost_mult,
        slippage_bps=args.slippage_bps * cost_mult,
        trailing_stop=args.trailing_stop,
        score_weighted_sizing=args.score_weighted_sizing,
        max_correlation=args.max_correlation)


def _strategy_overrides(args, name):
    skw = {}
    if name in ("rsi2", "trendpullback"):
        if args.rsi_entry is not None:
            skw["rsi_entry"] = args.rsi_entry
        if args.min_score > 0:
            skw["min_score"] = args.min_score
    if name == "trendpullback" and args.vol_contraction:
        skw["vol_contract_max"] = args.vol_contraction_ratio
    if args.max_hold is not None:
        skw["max_hold_days"] = args.max_hold
    if args.stop_atr is not None:
        skw["stop_atr_mult"] = args.stop_atr
    return skw


def _resolve_regime(args, data):
    """Return (binary_market_ok, exposure_multiplier) per the chosen mode."""
    if args.no_regime:
        return None, None
    if args.graduated_regime:
        return None, graduated_regime(data)
    return market_regime(data), None


def main() -> int:
    args = parse_args()
    end = args.end or date.today().isoformat()
    start = args.start

    if args.tickers:
        tickers = [t.upper() for t in args.tickers]
    elif args.curated:
        tickers = list(datamod.DEFAULT_UNIVERSE)
        print(f"Using curated basket: {len(tickers)} names")
    elif args.sp1000:
        tickers = uni.get_expanded(1000)
        print(f"Using EXPANDED ~1000-name universe: {len(tickers)} names")
    else:
        tickers, _ = uni.get_sp500()
        print(f"Using FULL S&P 500 universe: {len(tickers)} names (default)")
    if "SPY" not in tickers:
        tickers.append("SPY")

    print(f"Loading {len(tickers)} tickers  {start} -> {end} ...")
    data = datamod.get_data(tickers, start, end, use_cache=not args.no_cache)
    print(f"Loaded {len(data)} tickers with data.\n")

    regime, expo = _resolve_regime(args, data)
    if regime is not None:
        print(f"Market-regime filter: BINARY (SPY 200-SMA). "
              f"Risk-on on {regime.mean()*100:.0f}% of days.")
        flips = int((regime.astype(int).diff().abs() == 1).sum())
        print(f"  regime flips (whipsaw): {flips}")
    elif expo is not None:
        allowed = (expo > 0)
        gflips = int((allowed.astype(int).diff().abs() == 1).sum())
        print(f"Market-regime filter: GRADUATED (mean exposure "
              f"{expo.mean():.2f}x). on/off flips: {gflips}")
        binflips = int((market_regime(data).astype(int).diff().abs() == 1).sum())
        print(f"  (binary gate would flip {binflips}x — graduated reduces whipsaw)")
    else:
        print("Market-regime filter: OFF")
    spy_ret = spy_daily_returns(data) if args.spy_overlay else None
    if spy_ret is not None:
        print("SPY cash overlay: ON (idle cash tracks SPY).")
    for label, on in [("Trailing stop", args.trailing_stop),
                      ("Score-weighted sizing", args.score_weighted_sizing),
                      ("Vol-contraction (TP)", args.vol_contraction)]:
        if on:
            print(f"{label}: ON")
    if args.max_correlation is not None:
        print(f"Correlation control: ON (skip if corr > {args.max_correlation} "
              "vs 2+ held names)")
    print()

    # ---- v9 live-sprint Monte Carlo mode ---------------------------------
    if args.live_sprint:
        from backtest.montecarlo import run_montecarlo
        N = args.n_positions
        print("=" * 68)
        print(f"   LIVE-SPRINT VALIDATION — can we hit >=60 trades in "
              f"{args.window_len} days?")
        print(f"   {args.mc_windows} random windows · N={N} concurrent · "
              f"long-only · $ {args.capital:,.0f}")
        print("=" * 68)
        configs = {
            "RSI2-sprint": build_strategy(
                "rsi2", rsi_entry=15, max_hold_days=4, exit_sma=5,
                rsi_exit=50, min_down_days=1),
            "Donchian-breakout": build_strategy("donchian"),
        }
        results = {}
        for label, strat in configs.items():
            print(f"\n----- {label} -----")
            mc = run_montecarlo(
                strat, data, n_windows=args.mc_windows, window_len=args.window_len,
                N=N, capital=args.capital, commission=args.commission,
                slippage_bps=args.slippage_bps)
            print(mc.summary())
            results[label] = mc

        # honest recommendation
        def score(mc):
            both = float(((mc.trades >= 60) & (mc.rets > 0)).mean())
            return both, float(np.median(mc.trades)), float(np.median(mc.rets))
        print("\n" + "=" * 68)
        print("   RECOMMENDATION")
        print("=" * 68)
        best = max(results, key=lambda k: score(results[k]))
        for label, mc in results.items():
            both, mt, mr = score(mc)
            print(f"  {label:<20} median {int(mt)} trades, "
                  f"{mr*100:+.1f}% return, {both*100:.0f}% of windows hit "
                  f"BOTH >=60 trades & profit")
        bm = results[best]
        med_t = int(np.median(bm.trades))
        print(f"\n  -> Use **{best}** with N={N}. Honest read below.")
        if med_t < 60:
            print(f"  WARNING: even the best config's MEDIAN is {med_t} trades "
                  f"(<60). To reach 60 you must either raise N (more concurrent "
                  f"positions), loosen the entry filter, or accept some lower-"
                  f"quality fills. The scanner shows a live tally so you can "
                  f"course-correct mid-window.")
        else:
            print(f"  The median window clears 60 trades. Stay disciplined and "
                  f"follow the daily scanner tally.")
        return 0

    def _run(strat, cost_mult=1.0):
        return _make_bt(args, strat, cost_mult).run(
            data, market_ok=regime, spy_returns=spy_ret,
            exposure_multiplier=expo)

    # ---- stress-costs mode (Feature 7) -----------------------------------
    if args.stress_costs:
        strategy = build_strategy(args.strategy,
                                  **_strategy_overrides(args, args.strategy))
        print(f"STRESS-TESTING COSTS for {strategy.name} "
              f"(base commission ${args.commission}, slippage "
              f"{args.slippage_bps}bps)\n")
        header = (f"{'Costs':>7}{'CAGR':>9}{'CAGRvsSPY':>11}{'PF':>7}"
                  f"{'MaxDD':>9}{'Trades':>8}{'Profitable':>11}")
        print(header)
        print("-" * len(header))
        bench = None
        for mult in (1.0, 2.0, 3.0):
            r = _run(strategy, cost_mult=mult)
            em, tm = equity_metrics(r), trade_metrics(r.trades)
            if bench is None:
                bench = spy_benchmark(args.capital, r.equity.index[0],
                                      r.equity.index[-1], data)
            vs = em.cagr - (bench.cagr if bench else 0)
            profitable = sum(1 for t in r.trades if t.pnl > 0)
            pf = "inf" if tm.profit_factor == float("inf") else f"{tm.profit_factor:.2f}"
            print(f"{mult:>6.0f}x{em.cagr*100:>8.1f}%{vs*100:>+10.1f}%{pf:>7}"
                  f"{em.max_drawdown*100:>8.1f}%{tm.n_trades:>8}{profitable:>11}")
        print("\n(Full S&P 500 includes less-liquid names where real slippage "
              "may exceed the model — 2x/3x approximates that.)")
        return 0

    # ---- comparison mode -------------------------------------------------
    if args.compare:
        results = []
        for sname in ALL_STRATS:
            strat = build_strategy(sname)
            print(f"Running {strat.name} ...")
            r = _run(strat)
            results.append((r, equity_metrics(r), trade_metrics(r.trades)))
        bench = spy_benchmark(args.capital, results[0][0].equity.index[0],
                              results[0][0].equity.index[-1], data)
        print("\n" + "=" * 79)
        print("   STRATEGY COMPARISON  (full S&P 500 default)" if not args.curated
              else "   STRATEGY COMPARISON  (curated basket)")
        print("=" * 79)
        print(rpt.comparison_table(results, bench))
        print("=" * 79)
        chart = rpt.plot_comparison(results, bench)
        print(f"\nComparison chart: {chart}")
        return 0

    # ---- single strategy -------------------------------------------------
    strategy = build_strategy(args.strategy, **_strategy_overrides(args, args.strategy))
    print(f"Running backtest: {strategy.name} ...")
    res = _run(strategy)

    em = equity_metrics(res)
    tm = trade_metrics(res.trades)
    bench = spy_benchmark(args.capital, res.equity.index[0],
                          res.equity.index[-1], data)
    print()
    print(rpt.console_summary(res, em, tm, bench))
    print()

    if args.oos_split:
        split = args.oos_split
        is_res = slice_result(res, res.equity.index[0], split, "in-sample")
        oos_res = slice_result(res, split, res.equity.index[-1], "out-of-sample")
        print("=" * 68)
        print(f"   OUT-OF-SAMPLE VALIDATION  (split at {split})")
        print("   Note: textbook params are NOT fitted, so this measures")
        print("   regime consistency of the edge across periods.")
        print("=" * 68)
        for sub in (is_res, oos_res):
            sem, stm = equity_metrics(sub), trade_metrics(sub.trades)
            print(f"  {sub.strategy_name:<28} "
                  f"{sub.equity.index[0].date()} -> {sub.equity.index[-1].date()}")
            print(f"    Return {sem.total_return*100:+6.1f}%  "
                  f"CAGR {sem.cagr*100:+5.1f}%  WinRate {stm.win_rate*100:4.1f}%  "
                  f"PF {stm.profit_factor:4.2f}  MaxDD {sem.max_drawdown*100:5.1f}%  "
                  f"Trades {stm.n_trades}")
        print("=" * 68 + "\n")

    charts = rpt.generate_charts(res, bench)
    md = rpt.write_report(res, em, tm, bench, charts)
    log = rpt.write_trade_log(res)
    print(f"Charts + report written to: {rpt.OUTPUT_DIR}/")
    print(f"  report : {md}")
    print(f"  trades : {log}")
    for c in charts:
        print(f"  chart  : {c}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

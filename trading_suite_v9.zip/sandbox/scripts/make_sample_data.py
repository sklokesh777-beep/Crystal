"""
Generate a realistic 60-trade sample journal (data/sample_trades.csv).

Each trade is defined compactly by (sleeve, ticker, direction, entry_date,
entry, stop, target, exit_date, r_target, catalyst, exit_reason). Quantity is
derived from the 1%-risk rule (0.5% for the overnight sleeve), and the exit
price is back-solved from the intended R-multiple so the demo is internally
consistent and reproducible.

Values approximate US large-cap levels around mid-July 2026 and are for
paper-trading simulation only.

Run:  python scripts/make_sample_data.py
"""
from __future__ import annotations

import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config  # noqa: E402

RISK_SWING = 1000.0     # 1% of 100k
RISK_OVERNIGHT = 500.0  # 0.5% of 100k
COMMISSION = 1.0

# (sleeve, ticker, dir, entry_date, entry, stop, target, exit_date, R, catalyst, exit_reason)
# R values are tuned for a realistic ~55% win rate and a ~10% net return with a
# genuine mid-window drawdown. Sleeve E deliberately underperforms (overnight
# gap risk) so the write-up has an honest "what didn't work" story.
T = [
    # ---- A_EARNINGS (14): post-earnings drift; 8W / 6L
    ("A_EARNINGS", "JPM",  "LONG",  "07-16", 295.0, 288.0, 312.0, "07-21",  1.4, "Q2 beat, guided NII higher, gap held", "Trailed out below target"),
    ("A_EARNINGS", "BAC",  "LONG",  "07-16",  46.5,  45.0,  50.0, "07-20", -0.9, "Bank earnings beat, above opening range", "Faded, stopped"),
    ("A_EARNINGS", "GS",   "LONG",  "07-17", 640.0, 625.0, 680.0, "07-23",  1.5, "Trading revenue blowout", "Trailed out"),
    ("A_EARNINGS", "NFLX", "LONG",  "07-20", 1250.0, 1210.0, 1340.0, "07-22", -1.0, "Subs beat but soft guide", "Stopped on guidance"),
    ("A_EARNINGS", "TSM",  "LONG",  "07-17", 420.0, 408.0, 450.0, "07-24",  1.5, "AI demand, raised capex outlook", "Trailed out"),
    ("A_EARNINGS", "PEP",  "SHORT", "07-16", 145.0, 149.0, 136.0, "07-22",  1.0, "Volume miss, weak NA beverages", "Covered into support"),
    ("A_EARNINGS", "UAL",  "LONG",  "07-20",  92.0,  88.5,  100.0, "07-24", -1.05, "Airline beat fade", "Full stop"),
    ("A_EARNINGS", "JNJ",  "LONG",  "07-16", 162.0, 158.0, 172.0, "07-23", -0.8, "Pharma guide raise", "Reversed, cut"),
    ("A_EARNINGS", "ASML", "LONG",  "07-20", 780.0, 758.0, 840.0, "07-27",  1.6, "Bookings surge", "Trailed out"),
    ("A_EARNINGS", "IBM",  "SHORT", "07-22", 285.0, 292.0, 270.0, "07-27",  0.7, "Software soft, gap-up faded", "Covered early"),
    ("A_EARNINGS", "T",    "LONG",  "07-23",  29.5,  28.6,  31.5, "07-28", -0.9, "Subscriber beat", "Faded, stopped"),
    ("A_EARNINGS", "LMT",  "LONG",  "07-22", 465.0, 452.0, 500.0, "07-29",  1.1, "Defense backlog, buyback", "Partial into strength"),
    ("A_EARNINGS", "KO",   "LONG",  "07-27",  70.0,  68.5,  74.0, "07-30", -0.7, "Defensive earnings, weak follow-through", "Cut early"),
    ("A_EARNINGS", "HON",  "LONG",  "07-27", 235.0, 229.0, 250.0, "07-31",  0.8, "Aerospace strength", "Closed at deadline"),

    # ---- B_REL_STRENGTH (14): leaders in tech/energy; 8W / 6L
    ("B_REL_STRENGTH", "NVDA", "LONG", "07-16", 168.0, 162.0, 184.0, "07-23",  1.3, "Fresh high, AI leadership, vol expansion", "Trailed out"),
    ("B_REL_STRENGTH", "MSFT", "LONG", "07-16", 505.0, 493.0, 535.0, "07-24",  1.3, "Pullback to rising 20-EMA held", "Trailed out"),
    ("B_REL_STRENGTH", "AVGO", "LONG", "07-17", 285.0, 276.0, 310.0, "07-23", -1.0, "Breakout failed on chip wobble", "Full stop"),
    ("B_REL_STRENGTH", "XOM",  "LONG", "07-16", 118.0, 114.5, 127.0, "07-22",  1.2, "Energy leadership, oil bid", "Partial exit"),
    ("B_REL_STRENGTH", "CVX",  "LONG", "07-17", 155.0, 150.5, 166.0, "07-24", -0.9, "Sector rotation into energy", "Reversed, stopped"),
    ("B_REL_STRENGTH", "SMH",  "LONG", "07-20", 285.0, 278.0, 302.0, "07-27",  0.9, "Semis relative strength", "Momentum fade exit"),
    ("B_REL_STRENGTH", "AMD",  "LONG", "07-20", 165.0, 159.0, 180.0, "07-24", -0.95, "Momentum stalled", "Stopped"),
    ("B_REL_STRENGTH", "GOOGL","LONG", "07-21", 195.0, 189.0, 210.0, "07-28",  1.0, "Base breakout on volume", "Trailed out"),
    ("B_REL_STRENGTH", "META", "LONG", "07-21", 720.0, 700.0, 770.0, "07-28",  0.8, "Uptrend continuation", "Pre-earnings trim"),
    ("B_REL_STRENGTH", "XLE",  "LONG", "07-22",  92.0,  89.5,  99.0, "07-29", -0.8, "Energy ETF momentum", "Oil rolled over, cut"),
    ("B_REL_STRENGTH", "AMZN", "LONG", "07-22", 225.0, 218.0, 242.0, "07-29",  1.1, "Retail + cloud strength", "Partial exit"),
    ("B_REL_STRENGTH", "QQQ",  "LONG", "07-23", 555.0, 544.0, 578.0, "07-30",  0.7, "Index momentum, lower-vol proxy", "Time exit"),
    ("B_REL_STRENGTH", "COP",  "LONG", "07-23", 108.0, 104.5, 117.0, "07-30", -1.0, "Oil pulled back", "Stopped"),
    ("B_REL_STRENGTH", "ORCL", "LONG", "07-27", 232.0, 225.0, 250.0, "07-31", -0.9, "Cloud momentum", "Stopped near deadline"),

    # ---- C_MEAN_REVERSION (12): RSI-2 oversold bounces; 7W / 5L
    ("C_MEAN_REVERSION", "AAPL", "LONG", "07-16", 232.5, 226.0, 245.0, "07-20",  1.0, "RSI(2)<10, tag lower BB, above 200DMA", "Reverted to 5-MA"),
    ("C_MEAN_REVERSION", "V",    "LONG", "07-17", 355.0, 347.0, 371.0, "07-21",  0.7, "Oversold bounce", "RSI back to 55"),
    ("C_MEAN_REVERSION", "MA",   "LONG", "07-20", 560.0, 548.0, 585.0, "07-22", -0.8, "Bounce failed", "Stopped"),
    ("C_MEAN_REVERSION", "COST", "LONG", "07-20", 985.0, 965.0, 1025.0, "07-23",  0.9, "Pullback in uptrend", "Reverted"),
    ("C_MEAN_REVERSION", "HD",   "LONG", "07-21", 415.0, 405.0, 435.0, "07-24", -0.7, "Oversold, defensive retail", "Cut early"),
    ("C_MEAN_REVERSION", "PG",   "LONG", "07-21", 168.0, 164.0, 176.0, "07-24",  0.7, "Lower BB tag, quality", "Reverted"),
    ("C_MEAN_REVERSION", "UNH",  "LONG", "07-22", 310.0, 301.0, 328.0, "07-24", -1.0, "Catch failed", "Stopped"),
    ("C_MEAN_REVERSION", "WMT",  "LONG", "07-23", 98.0,  95.5, 103.0, "07-27",  0.8, "Oversold, above 200DMA", "Reverted"),
    ("C_MEAN_REVERSION", "LLY",  "LONG", "07-23", 780.0, 762.0, 815.0, "07-28",  1.1, "Pharma pullback buy", "Target near"),
    ("C_MEAN_REVERSION", "ABBV", "LONG", "07-27", 205.0, 200.0, 215.0, "07-30", -0.8, "RSI bounce", "Failed, stopped"),
    ("C_MEAN_REVERSION", "MRK",  "LONG", "07-27", 128.0, 125.0, 134.0, "07-30", -0.6, "Weak bounce", "Cut early"),
    ("C_MEAN_REVERSION", "CRM",  "LONG", "07-28", 268.0, 261.0, 282.0, "07-31",  0.6, "Oversold snap", "Closed at deadline"),

    # ---- D_PAIRS (10): market-neutral, low vol; 6W / 4L
    ("D_PAIRS", "KO",  "LONG",  "07-16",  70.0,  68.6,  73.0, "07-22",  0.8, "Pair KO/PEP: long laggard KO", "Ratio reverted"),
    ("D_PAIRS", "PEP", "SHORT", "07-16", 145.0, 148.0, 139.0, "07-22",  0.6, "Pair KO/PEP: short leader PEP", "Ratio reverted"),
    ("D_PAIRS", "BAC", "LONG",  "07-20",  46.5,  45.6,  48.5, "07-27",  0.6, "Pair JPM/BAC: long laggard BAC", "Ratio reverted"),
    ("D_PAIRS", "JPM", "SHORT", "07-20", 296.0, 302.0, 285.0, "07-27", -0.6, "Pair JPM/BAC: short leader JPM", "Ratio widened, cut"),
    ("D_PAIRS", "CVX", "LONG",  "07-21", 155.0, 152.0, 162.0, "07-28",  0.5, "Pair XOM/CVX: long laggard CVX", "Ratio reverted"),
    ("D_PAIRS", "XOM", "SHORT", "07-21", 120.0, 123.0, 114.0, "07-28",  0.8, "Pair XOM/CVX: short leader XOM", "Ratio reverted"),
    ("D_PAIRS", "MA",  "LONG",  "07-22", 560.0, 550.0, 580.0, "07-29", -0.5, "Pair V/MA: long laggard MA", "Small adverse, cut"),
    ("D_PAIRS", "V",   "SHORT", "07-22", 358.0, 365.0, 344.0, "07-29", -0.5, "Pair V/MA: short leader V", "Small adverse, cut"),
    ("D_PAIRS", "GOOGL","LONG", "07-23", 196.0, 192.0, 205.0, "07-30",  0.7, "Pair GOOGL/MSFT: long laggard GOOGL", "Ratio reverted"),
    ("D_PAIRS", "MSFT", "SHORT","07-23", 508.0, 518.0, 488.0, "07-30", -0.6, "Pair GOOGL/MSFT: short leader MSFT", "Ratio widened, cut"),

    # ---- E_OVERNIGHT (10): 0.5% risk, buy near close / sell next open; 4W / 6L (underperformed)
    ("E_OVERNIGHT", "NVDA", "LONG",  "07-16", 168.5, 165.5, 174.0, "07-17",  1.0, "Closed at HOD on volume + AI catalyst", "Sold into gap-up"),
    ("E_OVERNIGHT", "TSLA", "LONG",  "07-17", 320.0, 313.0, 334.0, "07-20", -1.0, "Momentum close faded overnight", "Stopped at open"),
    ("E_OVERNIGHT", "AMD",  "LONG",  "07-20", 166.0, 162.5, 173.0, "07-21",  0.9, "Breakout close, semis strength", "Sold gap-up"),
    ("E_OVERNIGHT", "META", "LONG",  "07-21", 722.0, 710.0, 745.0, "07-22", -0.8, "Strong close top of range", "Gapped down, stopped"),
    ("E_OVERNIGHT", "XOM",  "SHORT", "07-22", 120.5, 123.5, 115.0, "07-23",  0.8, "Overbought into resistance, oil fade", "Covered gap-down"),
    ("E_OVERNIGHT", "AAPL", "LONG",  "07-23", 234.0, 230.0, 242.0, "07-24", -0.9, "Overnight momentum stalled", "Stopped"),
    ("E_OVERNIGHT", "SMH",  "LONG",  "07-24", 288.0, 283.0, 297.0, "07-27",  0.8, "ETF momentum close", "Sold gap-up"),
    ("E_OVERNIGHT", "GOOGL","LONG",  "07-27", 198.0, 194.5, 205.0, "07-28", -0.7, "Fresh high into close pre-earnings drift", "Gapped down, cut"),
    ("E_OVERNIGHT", "AVGO", "LONG",  "07-28", 292.0, 287.0, 302.0, "07-29", -0.8, "Strong semis close", "Reversed overnight"),
    ("E_OVERNIGHT", "QQQ",  "LONG",  "07-30", 560.0, 555.0, 570.0, "07-31", -0.5, "Index strength into close", "Soft open at deadline"),
]


def solve_exit(direction: str, entry: float, stop: float, r: float,
               qty: float) -> float:
    """Back-solve the exit price that yields (approximately) the target R,
    accounting for the fixed round-trip commission."""
    rps = abs(entry - stop)
    dollar_risk = rps * qty
    # net_pnl = r * dollar_risk ; gross = net + commission
    gross = r * dollar_risk + COMMISSION
    if direction == "LONG":
        exit_price = entry + gross / qty
    else:
        exit_price = entry - gross / qty
    return round(exit_price, 2)


def main() -> None:
    out_path = config.DEFAULT_TRADES_FILE
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    rows = []
    for i, (sleeve, ticker, direction, ed, entry, stop, target, xd, r,
            catalyst, exit_reason) in enumerate(T, start=1):
        risk_budget = RISK_OVERNIGHT if sleeve == "E_OVERNIGHT" else RISK_SWING
        rps = abs(entry - stop)
        qty = max(1, round(risk_budget / rps))
        exit_price = solve_exit(direction, entry, stop, r, qty)
        rows.append([
            i, ticker, sleeve, direction,
            f"2026-{ed}", entry, stop, target, qty,
            f"2026-{xd}", exit_price, COMMISSION,
            catalyst, exit_reason, "",
        ])

    header = [
        "trade_id", "ticker", "sleeve", "direction", "entry_date",
        "entry_price", "stop_price", "target_price", "quantity",
        "exit_date", "exit_price", "commission", "catalyst",
        "exit_reason", "notes",
    ]
    with open(out_path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)

    print(f"Wrote {len(rows)} trades to {out_path}")


if __name__ == "__main__":
    main()

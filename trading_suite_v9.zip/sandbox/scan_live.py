"""
LIVE trade scanner — the tool you run each day for the paper-trading assignment.

It pulls the latest daily data for your universe, computes the strategy's
signals on the most recent bar, applies the same proven filters as the
backtest (market regime, liquidity, multi-day oversold), then layers on the
LIVE-only context a disciplined trader checks by hand:

  * earnings blackout  - flags/【skips】names reporting within N days
  * news + sentiment    - latest headlines and a naive sentiment tag
  * position sizing     - shares to buy for a fixed 1%-risk stop

Output: a ranked watchlist printed to the console and saved to
output/live/watchlist_<DATE>.csv (+ .md).

Examples
--------
  python scan_live.py                       # default 26-name universe, RSI-2
  python scan_live.py --sp500               # scan the whole S&P 500
  python scan_live.py --sp500 --top 15 --earnings-window 5
  python scan_live.py --tickers AAPL MSFT NVDA JPM XOM
"""
from __future__ import annotations

import argparse
import os
from datetime import date, timedelta

import numpy as np
import pandas as pd

from backtest import data as datamod
from backtest import fundamentals as fund
from backtest import indicators as ind
from backtest import universe as uni
from backtest.strategies import build_strategy

OUT_DIR = os.path.join("output", "live")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Live swing-trade scanner with "
                                            "earnings + news awareness.")
    p.add_argument("--strategy", default="rsi2",
                   choices=["rsi2", "bollinger"])
    p.add_argument("--tickers", nargs="+", default=None)
    p.add_argument("--sp500", action="store_true")
    p.add_argument("--lookback-days", type=int, default=420,
                   help="Calendar days of history to pull (needs >200 for SMA).")
    p.add_argument("--capital", type=float, default=100_000.0)
    p.add_argument("--risk", type=float, default=0.01, help="Risk per trade.")
    p.add_argument("--top", type=int, default=15,
                   help="How many ranked candidates to enrich with news/earnings.")
    p.add_argument("--earnings-window", type=int, default=5,
                   help="Flag/skip names reporting within this many days.")
    p.add_argument("--skip-earnings", action="store_true",
                   help="Drop (not just flag) candidates in the earnings blackout.")
    p.add_argument("--no-news", action="store_true")
    p.add_argument("--no-cache", action="store_true",
                   help="Force fresh download (recommended for a true live scan).")
    # ---- v9 sprint mode ----
    p.add_argument("--sprint", action="store_true",
                   help="60-trades-in-10-days mode: RSI-2 short-hold config, "
                        "equal-weight sizing across N slots, and a live "
                        "trades/60 tally.")
    p.add_argument("--n-positions", type=int, default=28,
                   help="Concurrent slots (sprint sizing = capital / N).")
    p.add_argument("--target-trades", type=int, default=60)
    p.add_argument("--deadline", default="2026-07-31")
    p.add_argument("--journal", default=os.path.join("data", "my_trades.csv"),
                   help="CSV of your closed trades (for the progress tally).")
    return p.parse_args()


def sprint_tally(args, today) -> str:
    """Count closed trades so far and compute the pace needed to hit target."""
    done = 0
    try:
        if os.path.exists(args.journal):
            j = pd.read_csv(args.journal)
            if "exit_date" in j.columns:
                done = int(j["exit_date"].notna().sum() -
                           (j["exit_date"].astype(str).str.strip() == "").sum())
            else:
                done = len(j)
    except Exception:
        done = 0
    dl = pd.Timestamp(args.deadline)
    days_left = len(pd.bdate_range(pd.Timestamp(today), dl))
    remaining = max(args.target_trades - done, 0)
    pace = (remaining / days_left) if days_left else float("inf")
    bar = f"{done}/{args.target_trades}"
    msg = (f"  PROGRESS: {bar} closed trades  |  {days_left} trading days left "
           f"(to {args.deadline})\n"
           f"  PACE NEEDED: ~{pace:.1f} completed trades/day to reach "
           f"{args.target_trades}.")
    if done >= args.target_trades:
        msg += "  ✅ target reached — trade only clean setups now."
    return msg


def main() -> int:
    args = parse_args()
    if args.sprint and args.top < args.n_positions:
        args.top = args.n_positions      # show enough candidates to fill N slots
    today = date.today()
    start = (today - timedelta(days=args.lookback_days)).isoformat()
    end = today.isoformat()

    if args.tickers:
        tickers = [t.upper() for t in args.tickers]
        sectors = {t: "" for t in tickers}
    elif args.sp500 or args.sprint:      # sprint needs the full universe
        tickers, sectors = uni.get_sp500()
    else:
        tickers = list(datamod.DEFAULT_UNIVERSE)
        sectors = {t: "" for t in tickers}
    if "SPY" not in tickers:
        tickers.append("SPY")

    print(f"Scanning {len(tickers)} names  ({start} -> {end}) ...")
    data = datamod.get_data(tickers, start, end, use_cache=not args.no_cache)

    # --- market regime -----------------------------------------------------
    regime_on = True
    if "SPY" in data:
        spy_c = data["SPY"]["Close"]
        regime_on = bool(spy_c.iloc[-1] > ind.sma(spy_c, 200).iloc[-1])
    print(f"Market regime (SPY > 200-SMA): "
          f"{'RISK-ON ✅' if regime_on else 'RISK-OFF ⚠️  (mean-reversion longs discouraged)'}")
    if args.sprint:
        print(sprint_tally(args, today))
    print()

    if args.sprint:
        # short-hold config validated by Monte Carlo (README Part 10)
        strat = build_strategy("rsi2", rsi_entry=15, max_hold_days=4,
                               exit_sma=5, rsi_exit=50, min_down_days=1)
    else:
        strat = build_strategy(args.strategy)

    # --- scan for entry signals on the latest bar --------------------------
    candidates = []
    for t, df in data.items():
        if t == "SPY" or len(df) < 210:
            continue
        prep = strat.prepare(df)
        last = prep.iloc[-1]
        if not bool(last.get("entry", False)):
            continue
        close = float(last["Close"])
        atr = float(last["atr"]) if np.isfinite(last["atr"]) else np.nan
        stop = close - strat.stop_atr_mult * atr if np.isfinite(atr) else np.nan
        candidates.append({
            "ticker": t,
            "sector": sectors.get(t, ""),
            "score": round(float(last.get("score", np.nan)), 0),
            "rsi2": float(last.get("rsi", np.nan)),
            "close": round(close, 2),
            "stop": round(stop, 2) if np.isfinite(stop) else np.nan,
            "as_of": prep.index[-1].date().isoformat(),
        })

    # Highest confluence score first (best technical context).
    candidates.sort(key=lambda c: (-c["score"] if np.isfinite(c["score"]) else 0))
    print(f"{len(candidates)} names triggered an entry signal today.\n")

    # --- position sizing + live earnings/news enrichment (top N) ----------
    risk_budget = args.capital * args.risk
    enriched = []
    for c in candidates[: args.top]:
        # sizing: sprint = equal-weight (capital / N slots); else 1%-risk rule
        if args.sprint and c["close"] > 0:
            shares = int((args.capital / args.n_positions) // c["close"])
        elif np.isfinite(c["stop"]) and c["close"] > c["stop"] > 0:
            per_share = c["close"] - c["stop"]
            shares = int(risk_budget // per_share)
        else:
            shares = 0
        c["shares"] = shares
        c["notional"] = round(shares * c["close"], 2)

        # earnings blackout
        d2e = fund.days_to_earnings(c["ticker"], today)
        c["days_to_earnings"] = d2e if d2e is not None else ""
        blackout = d2e is not None and 0 <= d2e <= args.earnings_window
        c["earnings_flag"] = "SKIP-earnings" if blackout else ""

        # news
        if not args.no_news:
            c["news_sentiment"] = round(fund.news_sentiment_score(c["ticker"], 8), 2)
            heads = fund.get_news(c["ticker"], 2)
            c["headline"] = heads[0].title[:80] if heads else ""
        else:
            c["news_sentiment"] = ""
            c["headline"] = ""

        if args.skip_earnings and blackout:
            continue
        enriched.append(c)

    _print_and_save(enriched, regime_on, args, today)
    return 0


def _print_and_save(rows, regime_on, args, today) -> None:
    if not rows:
        print("No qualifying candidates today (after filters). "
              "That's normal when the market isn't oversold.")
    else:
        hdr = (f"{'#':>2} {'Ticker':<7}{'Score':>6}{'RSI2':>6}{'Close':>9}{'Stop':>8}"
               f"{'Shares':>7}{'Notional':>11}{'ToEarn':>7}{'News':>6}  Flag / Headline")
        print(hdr)
        print("-" * len(hdr))
        for i, c in enumerate(rows, 1):
            print(f"{i:>2} {c['ticker']:<7}{c['score']:>6.0f}{c['rsi2']:>6.1f}"
                  f"{c['close']:>9.2f}"
                  f"{(c['stop'] if isinstance(c['stop'],(int,float)) else 0):>8.2f}"
                  f"{c['shares']:>7}{c['notional']:>11,.0f}"
                  f"{str(c['days_to_earnings']):>7}{str(c['news_sentiment']):>6}  "
                  f"{c['earnings_flag']} {c['headline']}")
    # save
    os.makedirs(OUT_DIR, exist_ok=True)
    stamp = today.isoformat()
    if rows:
        df = pd.DataFrame(rows)
        csv_path = os.path.join(OUT_DIR, f"watchlist_{stamp}.csv")
        try:
            df.to_csv(csv_path, index=False)
        except PermissionError:
            import time
            csv_path = csv_path.replace(".csv", f"_{int(time.time())}.csv")
            df.to_csv(csv_path, index=False)
            print(f"  ! watchlist CSV was open/locked — saved to {csv_path}.")
        md_path = os.path.join(OUT_DIR, f"watchlist_{stamp}.md")
        with open(md_path, "w", encoding="utf-8") as fh:
            fh.write(f"# Live Watchlist — {stamp}\n\n")
            fh.write(f"Strategy: **{args.strategy}** · Market regime: "
                     f"**{'RISK-ON' if regime_on else 'RISK-OFF'}** · "
                     f"Capital ${args.capital:,.0f} · Risk {args.risk*100:.1f}%/trade\n\n")
            fh.write(df.to_markdown(index=False))
            fh.write("\n\n*Earnings/news are live context, not backtested. "
                     "Avoid holding swing trades through earnings. "
                     "Educational use only — not investment advice.*\n")
        print(f"\nSaved: {csv_path}\n       {md_path}")


if __name__ == "__main__":
    raise SystemExit(main())

"""
Analytics engine.

Turns a list of closed `Trade` objects into the full performance picture:
returns, win/loss stats, R-multiple stats, profit factor, expectancy,
drawdown, Sharpe, Sortino, Calmar, streaks, and per-sleeve / long-vs-short
breakdowns. Also builds the daily equity curve used for charts and
risk-adjusted ratios.

All formulas are standard and documented inline so they are defensible in the
write-up.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from typing import Optional

import numpy as np
import pandas as pd

import config
from src.models import Trade, Direction


# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------
def _safe_div(a: float, b: float, default: float = 0.0) -> float:
    return a / b if b else default


def _max_streak(flags: list[bool], want: bool) -> int:
    best = cur = 0
    for f in flags:
        if f == want:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


# ---------------------------------------------------------------------------
# Equity curve
# ---------------------------------------------------------------------------
@dataclass
class EquityCurve:
    """Daily mark of the account based on realised P/L booked on exit dates."""

    dates: pd.DatetimeIndex
    equity: pd.Series           # account value per calendar day
    daily_returns: pd.Series    # simple daily returns
    drawdown: pd.Series         # % drawdown from running peak (<= 0)

    @property
    def max_drawdown_pct(self) -> float:
        return float(self.drawdown.min()) if len(self.drawdown) else 0.0

    @property
    def max_drawdown_dollars(self) -> float:
        running_peak = self.equity.cummax()
        dd_dollars = self.equity - running_peak
        return float(dd_dollars.min()) if len(dd_dollars) else 0.0


def build_equity_curve(trades: list[Trade],
                       starting_capital: float) -> EquityCurve:
    """
    Build a calendar-day equity curve.

    P/L for each trade is booked on its exit date (realised). Days with no
    exits carry the previous equity forward (0% return). This gives an honest,
    reproducible curve for drawdown and Sharpe/Sortino.
    """
    if not trades:
        idx = pd.DatetimeIndex([pd.Timestamp.today().normalize()])
        eq = pd.Series([starting_capital], index=idx)
        return EquityCurve(idx, eq, eq.pct_change().fillna(0.0),
                           pd.Series([0.0], index=idx))

    pnl_by_exit: dict = {}
    for t in trades:
        d = pd.Timestamp(t.exit_date)
        pnl_by_exit[d] = pnl_by_exit.get(d, 0.0) + t.pnl

    start = min(pd.Timestamp(t.entry_date) for t in trades)
    end = max(pd.Timestamp(t.exit_date) for t in trades)
    # Business-day calendar so daily-return annualisation by sqrt(252) is
    # internally consistent (weekends carry no P/L and would just dilute vol).
    idx = pd.date_range(start=start, end=end, freq="B")

    daily_pnl = pd.Series(0.0, index=idx)
    for d, pnl in pnl_by_exit.items():
        if d in daily_pnl.index:
            daily_pnl.loc[d] += pnl

    equity = starting_capital + daily_pnl.cumsum()
    daily_returns = equity.pct_change().fillna(0.0)
    running_peak = equity.cummax()
    drawdown = (equity - running_peak) / running_peak

    return EquityCurve(idx, equity, daily_returns, drawdown)


# ---------------------------------------------------------------------------
# Metrics container
# ---------------------------------------------------------------------------
@dataclass
class Metrics:
    label: str
    n_trades: int
    wins: int
    losses: int
    breakeven: int
    win_rate: float
    gross_profit: float
    gross_loss: float
    net_pnl: float
    total_return_pct: float
    avg_win: float
    avg_loss: float
    largest_win: float
    largest_loss: float
    profit_factor: float
    expectancy_dollars: float
    avg_r: float
    total_r: float
    expectancy_r: float
    avg_hold_days: float
    max_consec_wins: int
    max_consec_losses: int

    def to_dict(self) -> dict:
        return self.__dict__.copy()


def compute_metrics(trades: list[Trade],
                    starting_capital: float,
                    label: str = "All trades") -> Metrics:
    n = len(trades)
    if n == 0:
        return Metrics(label, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                       0, 0, 0, 0)

    pnls = [t.pnl for t in trades]
    rs = [t.r_multiple for t in trades]
    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p < 0]
    breakeven = [p for p in pnls if p == 0]

    gross_profit = sum(wins)
    gross_loss = sum(losses)            # negative
    net = sum(pnls)

    return Metrics(
        label=label,
        n_trades=n,
        wins=len(wins),
        losses=len(losses),
        breakeven=len(breakeven),
        win_rate=_safe_div(len(wins), n),
        gross_profit=gross_profit,
        gross_loss=gross_loss,
        net_pnl=net,
        total_return_pct=_safe_div(net, starting_capital),
        avg_win=_safe_div(gross_profit, len(wins)),
        avg_loss=_safe_div(gross_loss, len(losses)),
        largest_win=max(pnls),
        largest_loss=min(pnls),
        profit_factor=_safe_div(gross_profit, abs(gross_loss),
                                default=float("inf") if gross_profit else 0.0),
        expectancy_dollars=_safe_div(net, n),
        avg_r=float(np.mean(rs)),
        total_r=float(np.sum(rs)),
        expectancy_r=float(np.mean(rs)),
        avg_hold_days=float(np.mean([t.holding_days for t in trades])),
        max_consec_wins=_max_streak([t.is_win for t in trades], True),
        max_consec_losses=_max_streak([t.pnl < 0 for t in trades], True),
    )


# ---------------------------------------------------------------------------
# Risk-adjusted ratios (need the equity curve)
# ---------------------------------------------------------------------------
@dataclass
class RiskRatios:
    sharpe: float                 # annualised (interpret with care on short samples)
    sortino: float                # annualised
    return_to_maxdd: float        # period return / |max drawdown| (robust, intuitive)
    period_return: float          # actual return over the window
    annualised_volatility: float
    n_days: int                   # number of trading days in the sample
    short_sample: bool            # True if too few days to annualise robustly


def compute_risk_ratios(curve: EquityCurve,
                        starting_capital: float,
                        risk_free_annual: float = config.RISK_FREE_ANNUAL,
                        periods_per_year: int = config.TRADING_DAYS_PER_YEAR
                        ) -> RiskRatios:
    r = curve.daily_returns.copy()
    # Drop the leading 0 (first day has no prior day).
    if len(r) > 1:
        r = r.iloc[1:]

    period_return = _safe_div(curve.equity.iloc[-1] - starting_capital,
                              starting_capital)
    return_to_maxdd = _safe_div(period_return, abs(curve.max_drawdown_pct)) \
        if curve.max_drawdown_pct else 0.0
    n_days = int(len(r))
    # A month of trading is ~21 days; below that, annualised ratios are noisy.
    short_sample = n_days < 21

    if n_days < 2 or r.std(ddof=1) == 0:
        return RiskRatios(0.0, 0.0, return_to_maxdd, period_return, 0.0,
                          n_days, short_sample)

    rf_daily = risk_free_annual / periods_per_year
    excess = r - rf_daily

    std_daily = r.std(ddof=1)

    # Sortino downside deviation: root-mean-square of returns that fall below
    # the target (here the risk-free rate), measured over ALL periods (the
    # standard definition), not just the std of the negative subset.
    shortfall = np.minimum(0.0, r - rf_daily)
    downside_dev = float(np.sqrt(np.mean(np.square(shortfall))))

    sharpe = _safe_div(excess.mean(), std_daily) * np.sqrt(periods_per_year)
    sortino = (_safe_div(excess.mean(), downside_dev) * np.sqrt(periods_per_year)
               if downside_dev > 0 else 0.0)
    ann_vol = std_daily * np.sqrt(periods_per_year)

    return RiskRatios(
        sharpe=float(sharpe),
        sortino=float(sortino),
        return_to_maxdd=float(return_to_maxdd),
        period_return=float(period_return),
        annualised_volatility=float(ann_vol),
        n_days=n_days,
        short_sample=short_sample,
    )


# ---------------------------------------------------------------------------
# Breakdowns
# ---------------------------------------------------------------------------
def metrics_by_sleeve(trades: list[Trade],
                      starting_capital: float) -> dict[str, Metrics]:
    out: dict[str, Metrics] = {}
    sleeves = sorted({t.sleeve for t in trades})
    for s in sleeves:
        subset = [t for t in trades if t.sleeve == s]
        cap = config.SLEEVES.get(s, {}).get("capital", starting_capital)
        out[s] = compute_metrics(subset, cap, label=s)
    return out


def metrics_by_direction(trades: list[Trade],
                         starting_capital: float) -> dict[str, Metrics]:
    out: dict[str, Metrics] = {}
    for d in (Direction.LONG, Direction.SHORT):
        subset = [t for t in trades if t.direction is d]
        if subset:
            out[d.value] = compute_metrics(subset, starting_capital,
                                           label=d.value)
    return out


# ---------------------------------------------------------------------------
# Full report bundle
# ---------------------------------------------------------------------------
@dataclass
class FullAnalytics:
    starting_capital: float
    ending_capital: float
    overall: Metrics
    risk: RiskRatios
    curve: EquityCurve
    by_sleeve: dict[str, Metrics]
    by_direction: dict[str, Metrics]
    trades: list[Trade]

    @property
    def max_drawdown_pct(self) -> float:
        return self.curve.max_drawdown_pct

    @property
    def max_drawdown_dollars(self) -> float:
        return self.curve.max_drawdown_dollars


def analyse(trades: list[Trade],
            starting_capital: float = config.STARTING_CAPITAL) -> FullAnalytics:
    trades = sorted(trades, key=lambda t: (t.exit_date, t.entry_date, t.trade_id))
    curve = build_equity_curve(trades, starting_capital)
    overall = compute_metrics(trades, starting_capital, "All trades")
    risk = compute_risk_ratios(curve, starting_capital)
    return FullAnalytics(
        starting_capital=starting_capital,
        ending_capital=starting_capital + overall.net_pnl,
        overall=overall,
        risk=risk,
        curve=curve,
        by_sleeve=metrics_by_sleeve(trades, starting_capital),
        by_direction=metrics_by_direction(trades, starting_capital),
        trades=trades,
    )

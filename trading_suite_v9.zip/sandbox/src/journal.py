"""
Trade journal I/O.

Reads/writes the trade log as CSV so you can maintain it in Excel / Google
Sheets / TradingView export and feed it straight into the analytics.

Expected CSV columns (header row required):
    trade_id, ticker, sleeve, direction, entry_date, entry_price,
    stop_price, target_price, quantity, exit_date, exit_price,
    commission, catalyst, exit_reason, notes
"""
from __future__ import annotations

import csv
import os
from typing import List

import config
from src.models import Trade

REQUIRED_COLUMNS = [
    "trade_id", "ticker", "sleeve", "direction", "entry_date", "entry_price",
    "stop_price", "target_price", "quantity", "exit_date", "exit_price",
]
OPTIONAL_COLUMNS = ["commission", "catalyst", "exit_reason", "notes"]
ALL_COLUMNS = REQUIRED_COLUMNS + OPTIONAL_COLUMNS


def load_trades(path: str = config.DEFAULT_TRADES_FILE) -> List[Trade]:
    """Load and validate trades from a CSV file."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"Trades file not found: {path}")

    trades: List[Trade] = []
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        missing = [c for c in REQUIRED_COLUMNS if c not in reader.fieldnames]
        if missing:
            raise ValueError(
                f"CSV {path} is missing required columns: {missing}")

        for lineno, row in enumerate(reader, start=2):
            # Skip completely blank lines.
            if not any((v or "").strip() for v in row.values()):
                continue
            try:
                trades.append(Trade(
                    trade_id=int(float(row["trade_id"])),
                    ticker=row["ticker"],
                    sleeve=row["sleeve"],
                    direction=row["direction"],
                    entry_date=row["entry_date"],
                    entry_price=row["entry_price"],
                    stop_price=row["stop_price"],
                    target_price=row["target_price"],
                    quantity=row["quantity"],
                    exit_date=row["exit_date"],
                    exit_price=row["exit_price"],
                    commission=row.get("commission") or 0.0,
                    catalyst=row.get("catalyst", ""),
                    exit_reason=row.get("exit_reason", ""),
                    notes=row.get("notes", ""),
                ))
            except (ValueError, KeyError) as exc:
                raise ValueError(f"Error parsing {path} line {lineno}: {exc}") from exc

    if not trades:
        raise ValueError(f"No valid trades found in {path}")
    return trades


def save_trades(trades: List[Trade], path: str) -> None:
    """Write trades back out to CSV (useful after programmatic edits)."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(ALL_COLUMNS)
        for t in trades:
            writer.writerow([
                t.trade_id, t.ticker, t.sleeve, t.direction.value,
                t.entry_date.isoformat(), t.entry_price, t.stop_price,
                t.target_price, t.quantity, t.exit_date.isoformat(),
                t.exit_price, t.commission, t.catalyst, t.exit_reason, t.notes,
            ])


def write_template(path: str = config.TEMPLATE_FILE) -> str:
    """Create a blank, header-only CSV template with two example rows."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(ALL_COLUMNS)
        writer.writerow([
            1, "AAPL", "A_EARNINGS", "LONG", "2026-07-16", 232.50,
            226.00, 245.00, 153, "2026-07-20", 241.20, 1.00,
            "Q3 beat + gap-up held above opening range",
            "Target hit", "Textbook post-earnings drift",
        ])
        writer.writerow([
            2, "XOM", "E_OVERNIGHT", "SHORT", "2026-07-17", 118.40,
            121.00, 113.00, 96, "2026-07-20", 116.10, 1.00,
            "Overbought into resistance on oil spike fade",
            "Covered next morning", "Overnight mean-reversion",
        ])
    return path

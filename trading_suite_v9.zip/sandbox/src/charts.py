"""
Chart generation (matplotlib, headless).

Produces the visuals that make a submission look professional:
    1. equity_curve.png       - strategy equity vs SPY buy & hold
    2. drawdown.png           - underwater (drawdown) curve
    3. sleeve_pnl.png         - net P/L by strategy sleeve
    4. r_distribution.png     - histogram of R-multiples
    5. cumulative_r.png       - cumulative R over the trade sequence

All files are written to config.OUTPUT_DIR.
"""
from __future__ import annotations

import os

import matplotlib
matplotlib.use("Agg")  # headless / no display
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np

import config
from src.analytics import FullAnalytics
from src.benchmark import BenchmarkResult

plt.rcParams.update({
    "figure.figsize": (11, 6),
    "figure.dpi": 130,
    "axes.grid": True,
    "grid.alpha": 0.3,
    "font.size": 11,
    "axes.titlesize": 14,
    "axes.titleweight": "bold",
})

_GREEN = "#1a9850"
_RED = "#d73027"
_BLUE = "#2166ac"
_GREY = "#888888"


def _ensure_output() -> None:
    os.makedirs(config.OUTPUT_DIR, exist_ok=True)


def _path(name: str) -> str:
    return os.path.join(config.OUTPUT_DIR, name)


def plot_equity_curve(analytics: FullAnalytics,
                      benchmark: BenchmarkResult | None = None) -> str:
    _ensure_output()
    fig, ax = plt.subplots()
    eq = analytics.curve.equity
    ax.plot(eq.index, eq.values, color=_BLUE, linewidth=2,
            label="Strategy (all sleeves)")

    if benchmark is not None and benchmark.equity is not None:
        b = benchmark.equity.reindex(eq.index).ffill().bfill()
        ax.plot(b.index, b.values, color=_GREY, linewidth=1.8,
                linestyle="--", label=f"{benchmark.ticker} buy & hold")

    ax.axhline(analytics.starting_capital, color="black", linewidth=1,
               alpha=0.5, linestyle=":")
    ax.set_title("Equity Curve — Strategy vs Benchmark")
    ax.set_ylabel("Account value ($)")
    ax.set_xlabel("Date")
    ax.yaxis.set_major_formatter(
        plt.FuncFormatter(lambda x, _: f"${x:,.0f}"))
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %d"))
    ax.legend(loc="best")
    fig.autofmt_xdate()
    out = _path("equity_curve.png")
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)
    return out


def plot_drawdown(analytics: FullAnalytics) -> str:
    _ensure_output()
    fig, ax = plt.subplots()
    dd = analytics.curve.drawdown * 100
    ax.fill_between(dd.index, dd.values, 0, color=_RED, alpha=0.35)
    ax.plot(dd.index, dd.values, color=_RED, linewidth=1.2)
    ax.set_title("Drawdown (Underwater) Curve")
    ax.set_ylabel("Drawdown (%)")
    ax.set_xlabel("Date")
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %d"))
    fig.autofmt_xdate()
    out = _path("drawdown.png")
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)
    return out


def plot_sleeve_pnl(analytics: FullAnalytics) -> str:
    _ensure_output()
    sleeves = list(analytics.by_sleeve.keys())
    pnls = [analytics.by_sleeve[s].net_pnl for s in sleeves]
    labels = [config.SLEEVES.get(s, {}).get("name", s) for s in sleeves]
    colors = [_GREEN if p >= 0 else _RED for p in pnls]

    fig, ax = plt.subplots()
    bars = ax.bar(range(len(sleeves)), pnls, color=colors, alpha=0.85)
    ax.axhline(0, color="black", linewidth=0.8)
    ax.set_xticks(range(len(sleeves)))
    ax.set_xticklabels([f"{s}\n{lbl}" for s, lbl in zip(sleeves, labels)],
                       rotation=0, fontsize=8)
    ax.set_title("Net P/L by Strategy Sleeve")
    ax.set_ylabel("Net P/L ($)")
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"${x:,.0f}"))
    for b, p in zip(bars, pnls):
        ax.annotate(f"${p:,.0f}", (b.get_x() + b.get_width() / 2, p),
                    ha="center", va="bottom" if p >= 0 else "top", fontsize=9)
    out = _path("sleeve_pnl.png")
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)
    return out


def plot_r_distribution(analytics: FullAnalytics) -> str:
    _ensure_output()
    rs = [t.r_multiple for t in analytics.trades]
    fig, ax = plt.subplots()
    ax.hist(rs, bins=20, color=_BLUE, alpha=0.8, edgecolor="white")
    ax.axvline(0, color="black", linewidth=1)
    ax.axvline(float(np.mean(rs)), color=_GREEN, linewidth=2, linestyle="--",
               label=f"Mean = {np.mean(rs):.2f}R")
    ax.set_title("Distribution of R-Multiples")
    ax.set_xlabel("R-multiple (P/L ÷ initial risk)")
    ax.set_ylabel("Number of trades")
    ax.legend()
    out = _path("r_distribution.png")
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)
    return out


def plot_cumulative_r(analytics: FullAnalytics) -> str:
    _ensure_output()
    # Trades ordered by exit date (analytics already sorts them this way).
    rs = [t.r_multiple for t in analytics.trades]
    cum = np.cumsum(rs)
    fig, ax = plt.subplots()
    ax.plot(range(1, len(cum) + 1), cum, color=_BLUE, linewidth=2, marker="o",
            markersize=3)
    ax.axhline(0, color="black", linewidth=0.8)
    ax.fill_between(range(1, len(cum) + 1), cum, 0,
                    where=(cum >= 0), color=_GREEN, alpha=0.15)
    ax.fill_between(range(1, len(cum) + 1), cum, 0,
                    where=(cum < 0), color=_RED, alpha=0.15)
    ax.set_title("Cumulative R-Multiple Over Trade Sequence")
    ax.set_xlabel("Trade number (by exit order)")
    ax.set_ylabel("Cumulative R")
    out = _path("cumulative_r.png")
    fig.tight_layout()
    fig.savefig(out)
    plt.close(fig)
    return out


def generate_all_charts(analytics: FullAnalytics,
                        benchmark: BenchmarkResult | None = None) -> list[str]:
    return [
        plot_equity_curve(analytics, benchmark),
        plot_drawdown(analytics),
        plot_sleeve_pnl(analytics),
        plot_r_distribution(analytics),
        plot_cumulative_r(analytics),
    ]

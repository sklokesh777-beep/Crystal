"""
Position sizing.

Implements the 1%-risk rule that anchors the whole strategy:

    shares = (capital * risk_pct) / |entry - stop|

Then applies the guard-rails from config (max % of capital in a single name).
This is the single most important piece for the grade, so it returns a fully
explained breakdown you can drop straight into the write-up.
"""
from __future__ import annotations

from dataclasses import dataclass

import config


@dataclass
class PositionPlan:
    ticker: str
    direction: str
    entry: float
    stop: float
    target: float
    capital: float
    risk_pct: float

    # computed
    risk_per_share: float
    dollar_risk_budget: float
    raw_shares: float
    shares: int
    notional: float
    position_pct_of_capital: float
    reward_risk: float
    capped_by_position_limit: bool
    warnings: list

    def explain(self) -> str:
        lines = [
            f"Position plan for {self.ticker} ({self.direction})",
            f"  Entry ${self.entry:.2f} | Stop ${self.stop:.2f} | Target ${self.target:.2f}",
            f"  Risk per share      : ${self.risk_per_share:.2f}",
            f"  Risk budget ({self.risk_pct*100:.2f}% of ${self.capital:,.0f}): "
            f"${self.dollar_risk_budget:,.2f}",
            f"  Raw shares          : {self.raw_shares:.2f}",
            f"  Final shares        : {self.shares}",
            f"  Notional exposure   : ${self.notional:,.2f} "
            f"({self.position_pct_of_capital*100:.1f}% of capital)",
            f"  Reward:risk         : {self.reward_risk:.2f} : 1",
        ]
        if self.capped_by_position_limit:
            lines.append("  NOTE: size reduced to respect max-position-% limit.")
        for w in self.warnings:
            lines.append(f"  WARNING: {w}")
        return "\n".join(lines)


def calculate_position(
    ticker: str,
    direction: str,
    entry: float,
    stop: float,
    target: float,
    capital: float = config.STARTING_CAPITAL,
    risk_pct: float = config.RISK_PER_TRADE_PCT,
    max_position_pct: float = config.MAX_POSITION_PCT,
    min_reward_risk: float = config.MIN_REWARD_RISK,
) -> PositionPlan:
    """Compute how many shares to buy/short for a given trade idea."""
    direction = direction.upper()
    risk_per_share = abs(entry - stop)
    if risk_per_share <= 0:
        raise ValueError("Entry and stop cannot be equal (risk per share = 0).")

    dollar_risk_budget = capital * risk_pct
    raw_shares = dollar_risk_budget / risk_per_share

    # Apply max-position cap (never let one name exceed X% of capital).
    max_notional = capital * max_position_pct
    max_shares_by_position = max_notional / entry
    capped = raw_shares > max_shares_by_position
    shares = int(min(raw_shares, max_shares_by_position))

    notional = shares * entry
    position_pct = notional / capital if capital else 0.0
    reward_risk = abs(target - entry) / risk_per_share

    warnings: list[str] = []
    if reward_risk < min_reward_risk:
        warnings.append(
            f"reward:risk {reward_risk:.2f} is below target {min_reward_risk:.1f}. "
            "Consider a wider target or a tighter stop.")
    # Sanity checks on stop side vs direction.
    if direction == "LONG" and stop >= entry:
        warnings.append("LONG stop is not below entry.")
    if direction == "SHORT" and stop <= entry:
        warnings.append("SHORT stop is not above entry.")
    if shares == 0:
        warnings.append("Computed share count is 0 — risk-per-share too large "
                        "for the risk budget.")

    return PositionPlan(
        ticker=ticker.upper(),
        direction=direction,
        entry=entry,
        stop=stop,
        target=target,
        capital=capital,
        risk_pct=risk_pct,
        risk_per_share=risk_per_share,
        dollar_risk_budget=dollar_risk_budget,
        raw_shares=raw_shares,
        shares=shares,
        notional=notional,
        position_pct_of_capital=position_pct,
        reward_risk=reward_risk,
        capped_by_position_limit=capped,
        warnings=warnings,
    )

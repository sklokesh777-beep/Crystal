"""
Core data models.

A `Trade` is the atomic unit. It stores what you entered in TradingView
(ticker, direction, entry/stop/target, quantity, dates) and derives everything
the analytics need (P/L, %, R-multiple, holding period). All derived values are
computed from raw inputs so the numbers are auditable and reproducible.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from enum import Enum
from typing import Optional


class Direction(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"

    @classmethod
    def parse(cls, value: str) -> "Direction":
        v = str(value).strip().upper()
        if v in ("LONG", "L", "BUY", "B"):
            return cls.LONG
        if v in ("SHORT", "S", "SELL"):
            return cls.SHORT
        raise ValueError(f"Unknown direction: {value!r}")


def _parse_date(value) -> date:
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if isinstance(value, datetime):
        return value.date()
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y", "%d/%m/%Y"):
        try:
            return datetime.strptime(str(value).strip(), fmt).date()
        except ValueError:
            continue
    raise ValueError(f"Unrecognised date format: {value!r}")


@dataclass
class Trade:
    """A single completed (closed) trade."""

    trade_id: int
    ticker: str
    sleeve: str                      # e.g. "A_EARNINGS"
    direction: Direction
    entry_date: date
    entry_price: float
    stop_price: float                # planned stop-loss at entry
    target_price: float              # planned take-profit at entry
    quantity: float
    exit_date: date
    exit_price: float
    commission: float = 0.0          # round-trip commission in $
    catalyst: str = ""               # why you entered
    exit_reason: str = ""            # why you exited
    notes: str = ""

    # -- normalisation -------------------------------------------------------
    def __post_init__(self) -> None:
        self.ticker = str(self.ticker).strip().upper()
        self.sleeve = str(self.sleeve).strip().upper()
        if not isinstance(self.direction, Direction):
            self.direction = Direction.parse(self.direction)
        self.entry_date = _parse_date(self.entry_date)
        self.exit_date = _parse_date(self.exit_date)
        for f in ("entry_price", "stop_price", "target_price",
                  "quantity", "exit_price", "commission"):
            setattr(self, f, float(getattr(self, f)))
        self._validate()

    def _validate(self) -> None:
        if self.quantity <= 0:
            raise ValueError(f"Trade {self.trade_id}: quantity must be > 0")
        if self.entry_price <= 0 or self.exit_price <= 0:
            raise ValueError(f"Trade {self.trade_id}: prices must be > 0")
        if self.exit_date < self.entry_date:
            raise ValueError(f"Trade {self.trade_id}: exit_date before entry_date")
        # Stop must be on the correct side of entry given the direction.
        if self.direction is Direction.LONG and self.stop_price >= self.entry_price:
            raise ValueError(
                f"Trade {self.trade_id}: LONG stop ({self.stop_price}) must be "
                f"below entry ({self.entry_price})")
        if self.direction is Direction.SHORT and self.stop_price <= self.entry_price:
            raise ValueError(
                f"Trade {self.trade_id}: SHORT stop ({self.stop_price}) must be "
                f"above entry ({self.entry_price})")

    # -- direction helper ----------------------------------------------------
    @property
    def sign(self) -> int:
        """+1 for long, -1 for short."""
        return 1 if self.direction is Direction.LONG else -1

    # -- money ---------------------------------------------------------------
    @property
    def gross_pnl(self) -> float:
        """P/L before commissions, in $."""
        return (self.exit_price - self.entry_price) * self.quantity * self.sign

    @property
    def pnl(self) -> float:
        """Net P/L in $ (after commissions)."""
        return self.gross_pnl - self.commission

    @property
    def cost_basis(self) -> float:
        """Notional capital committed at entry."""
        return self.entry_price * self.quantity

    @property
    def pnl_pct(self) -> float:
        """Return on the capital committed to this trade."""
        if self.cost_basis == 0:
            return 0.0
        return self.pnl / self.cost_basis

    # -- risk ----------------------------------------------------------------
    @property
    def risk_per_share(self) -> float:
        return abs(self.entry_price - self.stop_price)

    @property
    def dollar_risk(self) -> float:
        """The $ you planned to lose if the stop was hit (initial risk = 1R)."""
        return self.risk_per_share * self.quantity

    @property
    def r_multiple(self) -> float:
        """Realised P/L expressed in units of initial risk (R)."""
        if self.dollar_risk == 0:
            return 0.0
        return self.pnl / self.dollar_risk

    @property
    def planned_reward_risk(self) -> float:
        """Target reward:risk ratio set at entry."""
        if self.risk_per_share == 0:
            return 0.0
        return abs(self.target_price - self.entry_price) / self.risk_per_share

    # -- time ----------------------------------------------------------------
    @property
    def holding_days(self) -> int:
        return (self.exit_date - self.entry_date).days

    @property
    def is_win(self) -> bool:
        return self.pnl > 0

    @property
    def is_overnight(self) -> bool:
        return self.holding_days <= 1

    def as_row(self) -> dict:
        """Flat dict for tabular display / CSV export."""
        return {
            "id": self.trade_id,
            "ticker": self.ticker,
            "sleeve": self.sleeve,
            "direction": self.direction.value,
            "entry_date": self.entry_date.isoformat(),
            "entry": round(self.entry_price, 2),
            "stop": round(self.stop_price, 2),
            "target": round(self.target_price, 2),
            "qty": round(self.quantity, 2),
            "exit_date": self.exit_date.isoformat(),
            "exit": round(self.exit_price, 2),
            "hold_days": self.holding_days,
            "risk_$": round(self.dollar_risk, 2),
            "pnl_$": round(self.pnl, 2),
            "pnl_%": round(self.pnl_pct * 100, 2),
            "R": round(self.r_multiple, 2),
            "catalyst": self.catalyst,
            "exit_reason": self.exit_reason,
            "notes": self.notes,
        }

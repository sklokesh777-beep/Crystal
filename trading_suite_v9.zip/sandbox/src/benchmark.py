"""
Benchmark comparison against SPY (S&P 500 ETF).

The most persuasive line in any trading write-up is "my strategy returned X%
vs the market's Y%". This module builds an apples-to-apples comparison:

    - Fetches SPY daily closes over your trading window via yfinance.
    - Simulates buying $STARTING_CAPITAL of SPY on day one and holding.
    - Falls back to manual prices in config.py if the network is unavailable,
      so the tool never hard-fails.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import Optional

import pandas as pd

import config


@dataclass
class BenchmarkResult:
    ticker: str
    start_date: date
    end_date: date
    start_price: float
    end_price: float
    total_return_pct: float
    ending_value: float          # value of a buy-and-hold of starting_capital
    equity: Optional[pd.Series]  # daily buy-and-hold equity, or None if fallback
    source: str                  # "yfinance" or "fallback"

    def summary(self) -> str:
        return (f"{self.ticker} buy & hold  {self.start_date} -> {self.end_date}: "
                f"{self.total_return_pct*100:+.2f}%  "
                f"(${config.STARTING_CAPITAL:,.0f} -> ${self.ending_value:,.0f}) "
                f"[{self.source}]")


def _fetch_spy(start: date, end: date) -> Optional[pd.Series]:
    """Return a daily SPY close Series, or None on any failure."""
    try:
        import yfinance as yf
    except Exception:
        return None
    try:
        # yfinance 'end' is exclusive, so pad by a couple of days.
        df = yf.download(
            config.BENCHMARK_TICKER,
            start=start.isoformat(),
            end=(end + timedelta(days=3)).isoformat(),
            progress=False,
            auto_adjust=True,
        )
        if df is None or df.empty:
            return None
        close = df["Close"]
        # yfinance may return a single-column DataFrame; squeeze to Series.
        if isinstance(close, pd.DataFrame):
            close = close.iloc[:, 0]
        close = close.dropna()
        return close if not close.empty else None
    except Exception:
        return None


def get_benchmark(start: date,
                  end: date,
                  starting_capital: float = config.STARTING_CAPITAL
                  ) -> BenchmarkResult:
    """Build the SPY buy-and-hold comparison for the given window."""
    close = _fetch_spy(start, end)

    if close is not None and len(close) >= 2:
        start_price = float(close.iloc[0])
        end_price = float(close.iloc[-1])
        shares = starting_capital / start_price
        equity = (close * shares).rename("SPY_buy_hold")
        total_return = (end_price / start_price) - 1.0
        return BenchmarkResult(
            ticker=config.BENCHMARK_TICKER,
            start_date=close.index[0].date(),
            end_date=close.index[-1].date(),
            start_price=start_price,
            end_price=end_price,
            total_return_pct=total_return,
            ending_value=starting_capital * (1 + total_return),
            equity=equity,
            source="yfinance",
        )

    # --- fallback: use manual prices from config -------------------------
    start_price = config.BENCHMARK_FALLBACK_START_PRICE
    end_price = config.BENCHMARK_FALLBACK_END_PRICE
    total_return = (end_price / start_price) - 1.0
    # Build a straight-line buy-and-hold equity series across business days so
    # the equity chart still shows a benchmark line when offline.
    bdays = pd.date_range(start=start, end=end, freq="B")
    if len(bdays) >= 2:
        prices = pd.Series(
            [start_price + (end_price - start_price) * i / (len(bdays) - 1)
             for i in range(len(bdays))],
            index=bdays)
        shares = starting_capital / start_price
        fallback_equity = (prices * shares).rename("SPY_buy_hold")
    else:
        fallback_equity = None
    return BenchmarkResult(
        ticker=config.BENCHMARK_TICKER,
        start_date=start,
        end_date=end,
        start_price=start_price,
        end_price=end_price,
        total_return_pct=total_return,
        ending_value=starting_capital * (1 + total_return),
        equity=fallback_equity,
        source="fallback (manual prices)",
    )

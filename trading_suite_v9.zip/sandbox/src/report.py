"""
Report generator.

Renders the full analytics bundle into (a) a clean console summary and
(b) a Markdown report (report.md) with metric tables, per-sleeve breakdown,
a full trade log, and embedded chart images — ready to paste into the
assignment write-up.
"""
from __future__ import annotations

import os
from datetime import date

import config
from src.analytics import FullAnalytics, Metrics
from src.benchmark import BenchmarkResult


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------
def _money(x: float) -> str:
    return f"${x:,.2f}"


def _pct(x: float) -> str:
    return f"{x*100:+.2f}%"


def _fmt_pf(pf: float) -> str:
    return "∞" if pf == float("inf") else f"{pf:.2f}"


# ---------------------------------------------------------------------------
# Console summary
# ---------------------------------------------------------------------------
def console_summary(a: FullAnalytics, b: BenchmarkResult | None = None) -> str:
    m = a.overall
    r = a.risk
    L = []
    add = L.append
    add("=" * 66)
    add("           PAPER TRADING PERFORMANCE SUMMARY")
    add("=" * 66)
    add(f"  Starting capital     : {_money(a.starting_capital)}")
    add(f"  Ending capital       : {_money(a.ending_capital)}")
    add(f"  Net P/L              : {_money(m.net_pnl)}  ({_pct(m.total_return_pct)})")
    if b is not None:
        alpha = m.total_return_pct - b.total_return_pct
        add(f"  {b.ticker} buy & hold     : {_pct(b.total_return_pct)}"
            f"   -> Alpha vs market: {_pct(alpha)}  [{b.source}]")
    add("-" * 66)
    add(f"  Trades               : {m.n_trades}  "
        f"(W {m.wins} / L {m.losses} / BE {m.breakeven})")
    add(f"  Win rate             : {m.win_rate*100:.1f}%")
    add(f"  Profit factor        : {_fmt_pf(m.profit_factor)}")
    add(f"  Expectancy / trade   : {_money(m.expectancy_dollars)}  "
        f"({m.expectancy_r:+.2f}R)")
    add(f"  Avg win / avg loss   : {_money(m.avg_win)} / {_money(m.avg_loss)}")
    add(f"  Largest win / loss   : {_money(m.largest_win)} / {_money(m.largest_loss)}")
    add(f"  Avg R-multiple       : {m.avg_r:+.2f}R   (total {m.total_r:+.1f}R)")
    add(f"  Avg holding period   : {m.avg_hold_days:.1f} days")
    add(f"  Max consec W / L     : {m.max_consec_wins} / {m.max_consec_losses}")
    add("-" * 66)
    add(f"  Max drawdown         : {_pct(a.max_drawdown_pct)}  "
        f"({_money(a.max_drawdown_dollars)})")
    add(f"  Return / Max-DD      : {r.return_to_maxdd:.2f}x  "
        f"(period return ÷ max drawdown)")
    add(f"  Sharpe ratio (ann.)  : {r.sharpe:.2f}")
    add(f"  Sortino ratio (ann.) : {r.sortino:.2f}")
    if r.short_sample:
        add(f"  NOTE: only {r.n_days} trading days — annualised Sharpe/Sortino")
        add( "        are illustrative, not statistically robust. Lead with")
        add( "        return, win rate, profit factor and Return/Max-DD.")
    add("=" * 66)
    add("  P/L by sleeve:")
    for s, sm in a.by_sleeve.items():
        name = config.SLEEVES.get(s, {}).get("name", s)
        add(f"    {s:<16} {name:<38} {_money(sm.net_pnl):>12}  "
            f"({sm.n_trades} trades, {sm.win_rate*100:.0f}% win)")
    add("=" * 66)
    return "\n".join(L)


# ---------------------------------------------------------------------------
# Markdown report
# ---------------------------------------------------------------------------
def _metrics_table(m: Metrics) -> str:
    rows = [
        ("Net P/L", _money(m.net_pnl)),
        ("Total return", _pct(m.total_return_pct)),
        ("Trades (W/L/BE)", f"{m.n_trades} ({m.wins}/{m.losses}/{m.breakeven})"),
        ("Win rate", f"{m.win_rate*100:.1f}%"),
        ("Profit factor", _fmt_pf(m.profit_factor)),
        ("Expectancy / trade", f"{_money(m.expectancy_dollars)} ({m.expectancy_r:+.2f}R)"),
        ("Average win", _money(m.avg_win)),
        ("Average loss", _money(m.avg_loss)),
        ("Largest win", _money(m.largest_win)),
        ("Largest loss", _money(m.largest_loss)),
        ("Average R-multiple", f"{m.avg_r:+.2f}R"),
        ("Total R", f"{m.total_r:+.1f}R"),
        ("Average hold (days)", f"{m.avg_hold_days:.1f}"),
        ("Max consecutive wins", str(m.max_consec_wins)),
        ("Max consecutive losses", str(m.max_consec_losses)),
    ]
    out = ["| Metric | Value |", "|---|---|"]
    out += [f"| {k} | {v} |" for k, v in rows]
    return "\n".join(out)


def markdown_report(a: FullAnalytics,
                    b: BenchmarkResult | None,
                    chart_paths: list[str]) -> str:
    m = a.overall
    r = a.risk
    lines: list[str] = []
    add = lines.append

    add("# Paper Trading Performance Report")
    add("")
    add(f"*Generated {date.today().isoformat()} · Account currency: "
        f"{config.CURRENCY}*")
    add("")

    # --- headline -------------------------------------------------------
    add("## 1. Headline results")
    add("")
    add(f"- **Starting capital:** {_money(a.starting_capital)}")
    add(f"- **Ending capital:** {_money(a.ending_capital)}")
    add(f"- **Net P/L:** {_money(m.net_pnl)} (**{_pct(m.total_return_pct)}**)")
    if b is not None:
        alpha = m.total_return_pct - b.total_return_pct
        add(f"- **{b.ticker} buy & hold over same window:** {_pct(b.total_return_pct)} "
            f"(data: {b.source})")
        add(f"- **Alpha vs market:** {_pct(alpha)}")
    add(f"- **Max drawdown:** {_pct(a.max_drawdown_pct)} "
        f"({_money(a.max_drawdown_dollars)})")
    add(f"- **Return / Max-Drawdown:** {r.return_to_maxdd:.2f}x")
    add(f"- **Sharpe / Sortino (annualised):** {r.sharpe:.2f} / {r.sortino:.2f}")
    add("")

    # --- risk framing note ---------------------------------------------
    add("> **Objective:** capital preservation with steady, risk-adjusted "
        "returns. Every trade was sized to risk a fixed "
        f"{config.RISK_PER_TRADE_PCT*100:.1f}% of capital "
        f"(≈{_money(config.STARTING_CAPITAL*config.RISK_PER_TRADE_PCT)}), "
        "with a minimum planned reward:risk of "
        f"{config.MIN_REWARD_RISK:.0f}:1.")
    add("")

    # --- full metrics ---------------------------------------------------
    add("## 2. Full performance metrics")
    add("")
    add(_metrics_table(m))
    add("")
    add("### Risk-adjusted ratios")
    add("")
    add("| Ratio | Value | Interpretation |")
    add("|---|---|---|")
    add(f"| Return / Max-DD | {r.return_to_maxdd:.2f}x | period return ÷ worst drawdown (robust) |")
    add(f"| Sharpe (annualised) | {r.sharpe:.2f} | return per unit of total volatility |")
    add(f"| Sortino (annualised) | {r.sortino:.2f} | return per unit of *downside* volatility |")
    add(f"| Annualised volatility | {_pct(r.annualised_volatility)} | daily σ × √252 |")
    add(f"| Trading days in sample | {r.n_days} | length of the test window |")
    add("")
    if r.short_sample:
        add(f"> **Caveat:** the sample is only {r.n_days} trading days. Annualised "
            "Sharpe/Sortino are shown for completeness but are *not* statistically "
            "robust over such a short window — they scale a ~2-week result up to a "
            "full year. The primary, defensible metrics here are the **period return, "
            "win rate, profit factor, expectancy, and Return/Max-Drawdown**.")
        add("")

    # --- sleeve breakdown ----------------------------------------------
    add("## 3. Performance by strategy sleeve")
    add("")
    add("| Sleeve | Strategy | Trades | Win % | Net P/L | Avg R |")
    add("|---|---|---|---|---|---|")
    for s, sm in a.by_sleeve.items():
        name = config.SLEEVES.get(s, {}).get("name", s)
        add(f"| {s} | {name} | {sm.n_trades} | {sm.win_rate*100:.0f}% | "
            f"{_money(sm.net_pnl)} | {sm.avg_r:+.2f}R |")
    add("")

    # --- long vs short --------------------------------------------------
    if a.by_direction:
        add("## 4. Long vs short")
        add("")
        add("| Direction | Trades | Win % | Net P/L | Avg R |")
        add("|---|---|---|---|---|")
        for d, dm in a.by_direction.items():
            add(f"| {d} | {dm.n_trades} | {dm.win_rate*100:.0f}% | "
                f"{_money(dm.net_pnl)} | {dm.avg_r:+.2f}R |")
        add("")

    # --- charts ---------------------------------------------------------
    add("## 5. Charts")
    add("")
    for p in chart_paths:
        # report.md and the PNGs live in the same directory (OUTPUT_DIR), so
        # reference charts by basename for portable rendering (e.g. on GitHub).
        base = os.path.basename(p)
        title = os.path.splitext(base)[0].replace("_", " ").title()
        add(f"### {title}")
        add(f"![{title}]({base})")
        add("")

    # --- full trade log -------------------------------------------------
    add("## 6. Full trade log")
    add("")
    add("| # | Ticker | Sleeve | Dir | Entry date | Entry | Stop | Target | "
        "Qty | Exit date | Exit | Hold | Risk $ | P/L $ | P/L % | R | Catalyst | Exit reason |")
    add("|" + "---|" * 19)
    for t in a.trades:
        row = t.as_row()
        add(f"| {row['id']} | {row['ticker']} | {row['sleeve']} | "
            f"{row['direction']} | {row['entry_date']} | {row['entry']} | "
            f"{row['stop']} | {row['target']} | {row['qty']} | "
            f"{row['exit_date']} | {row['exit']} | {row['hold_days']} | "
            f"{row['risk_$']} | {row['pnl_$']} | {row['pnl_%']} | {row['R']} | "
            f"{row['catalyst']} | {row['exit_reason']} |")
    add("")

    add("---")
    add("*Methodology notes: P/L is realised on the exit date; the equity "
        "curve marks the account per business day. Sharpe/Sortino use daily "
        f"returns annualised by √{config.TRADING_DAYS_PER_YEAR} with a "
        f"{config.RISK_FREE_ANNUAL*100:.0f}% risk-free rate. R-multiple = "
        "realised P/L ÷ initial planned risk. Prices are from a paper-trading "
        "simulation and may reflect delayed data.*")
    return "\n".join(lines)


def write_markdown_report(a: FullAnalytics,
                          b: BenchmarkResult | None,
                          chart_paths: list[str],
                          path: str | None = None) -> str:
    path = path or os.path.join(config.OUTPUT_DIR, "report.md")
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(markdown_report(a, b, chart_paths))
    return path

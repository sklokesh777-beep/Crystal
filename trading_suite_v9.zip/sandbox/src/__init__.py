"""Paper-trading analytics package."""

"""
Short-selling backtest runner — a SEPARATE model dedicated to shorts.

Mirrors run_backtest.py but for the short side:
  * short-friendly regime gate (only short when SPY is BELOW its 200-SMA),
  * daily borrow cost on the short's market value,
  * stops sit ABOVE entry, P/L = (entry - exit).

Examples
--------
  python run_short.py                         # ShortBreakdown, S&P 500, ~15y
  python run_short.py --compare               # all short strategies
  python run_short.py --strategy shortrsi2 --oos-split 2019-01-01
  python run_short.py --strategy shortbreakdown --trailing-stop
  python run_short.py --no-regime             # short in any regime (usually worse)
"""
from __future__ import annotations

import argparse
import os
from datetime import date

import pandas as pd

from backtest import data as datamod
from backtest import indicators as ind
from backtest import report as rpt
from backtest import universe as uni
from backtest.engine import BacktestResult
from backtest.metrics import equity_metrics, trade_metrics, spy_benchmark
from shortsell.engine import ShortBacktester
from shortsell.strategies import build_short_strategy, SHORT_STRATEGIES

SHORT_STRATS = list(SHORT_STRATEGIES)          # shortrsi2, shortbollinger, shortbreakdown
SHORT_OUTPUT = os.path.join("output", "short")


def short_regime(data: dict, trend: int = 200):
    """Short-friendly gate: SPY BELOW its 200-SMA (risk-off)."""
    if "SPY" not in data:
        return None
    close = data["SPY"]["Close"]
    return (close < ind.sma(close, trend)).fillna(False)


def slice_result(res, start, end, suffix):
    eq = res.equity.loc[start:end]
    inv = res.invested_pct.loc[start:end]
    init = float(eq.iloc[0]) if len(eq) else res.initial_capital
    lo, hi = pd.Timestamp(start), pd.Timestamp(end)
    trades = [t for t in res.trades if lo <= t.entry_date <= hi]
    return BacktestResult(eq, inv, trades, init,
                          f"{res.strategy_name} [{suffix}]", res.universe)


def parse_args():
    p = argparse.ArgumentParser(description="Short-selling backtest.")
    p.add_argument("--strategy", default="shortbreakdown", choices=SHORT_STRATS)
    p.add_argument("--tickers", nargs="+", default=None)
    p.add_argument("--curated", action="store_true")
    p.add_argument("--sp500", action="store_true")
    p.add_argument("--start", default="2010-01-01")
    p.add_argument("--end", default=None)
    p.add_argument("--capital", type=float, default=100_000.0)
    p.add_argument("--max-positions", type=int, default=10)
    p.add_argument("--position-size", type=float, default=0.10)
    p.add_argument("--commission", type=float, default=1.0)
    p.add_argument("--slippage-bps", type=float, default=5.0)
    p.add_argument("--borrow-rate", type=float, default=0.01,
                   help="Annual borrow cost on short market value (default 1%%).")
    p.add_argument("--trailing-stop", action="store_true")
    p.add_argument("--rsi-entry", type=float, default=None)
    p.add_argument("--max-hold", type=int, default=None)
    p.add_argument("--stop-atr", type=float, default=None)
    p.add_argument("--no-regime", action="store_true")
    p.add_argument("--no-cache", action="store_true")
    p.add_argument("--compare", action="store_true")
    p.add_argument("--oos-split", default=None)
    return p.parse_args()


def _make_bt(args, strat):
    return ShortBacktester(
        strategy=strat, initial_capital=args.capital,
        max_positions=args.max_positions, position_size_pct=args.position_size,
        commission_per_trade=args.commission, slippage_bps=args.slippage_bps,
        borrow_annual=args.borrow_rate, trailing_stop=args.trailing_stop)


def _overrides(args):
    skw = {}
    if args.rsi_entry is not None:
        skw["rsi_entry"] = args.rsi_entry
    if args.max_hold is not None:
        skw["max_hold_days"] = args.max_hold
    if args.stop_atr is not None:
        skw["stop_atr_mult"] = args.stop_atr
    return skw


def short_markdown(res, em, tm, bench, charts) -> str:
    def pct(x): return f"{x*100:+.2f}%"
    L = [f"# SHORT-SELLING Backtest — {res.strategy_name}", "",
         f"*Window {res.equity.index[0].date()} to {res.equity.index[-1].date()} "
         f"({em.years:.1f}y) · {len(res.universe)} symbols · SHORT side only*", "",
         "## Headline", "",
         f"- **Total return:** {pct(em.total_return)}",
         f"- **CAGR:** {pct(em.cagr)}",
         f"- **Win rate:** {tm.win_rate*100:.1f}%  ·  **Profit factor:** "
         f"{'inf' if tm.profit_factor==float('inf') else round(tm.profit_factor,2)}",
         f"- **Max drawdown:** {pct(em.max_drawdown)}",
         f"- **Trades:** {tm.n_trades}  ·  **Avg hold:** {tm.avg_hold_days:.1f}d",
         ""]
    for c in charts:
        b = os.path.basename(c)
        L += [f"### {os.path.splitext(b)[0].replace('_',' ').title()}",
              f"![{b}]({b})", ""]
    L += ["## Honest caveats — shorting is HARD (read this)", "",
          "- **Structural headwind:** stocks drift UP over the long run, so a "
          "short book fights gravity. 2010-2026 was a strong bull market — expect "
          "shorts to lag or lose on the whole.",
          "- **Borrow cost:** shorts pay a daily borrow fee (modelled here); "
          "hard-to-borrow names can cost far more than the ~1% default.",
          "- **Asymmetric risk:** a long can only fall to zero, but a short's loss "
          "is theoretically UNLIMITED (short squeezes). The ATR stop caps this in "
          "the model, but real squeezes can gap through stops.",
          "- **Regime matters most:** shorts are gated to when SPY is below its "
          "200-SMA (risk-off). Turning that off (`--no-regime`) usually makes it "
          "worse. Survivorship bias and 'not investment advice' caveats from the "
          "long model apply here too."]
    return "\n".join(L)


def main():
    args = parse_args()
    end = args.end or date.today().isoformat()

    if args.tickers:
        tickers = [t.upper() for t in args.tickers]
    elif args.curated:
        tickers = list(datamod.DEFAULT_UNIVERSE)
        print(f"Using curated basket: {len(tickers)} names")
    else:
        tickers, _ = uni.get_sp500()
        print(f"Using FULL S&P 500 universe: {len(tickers)} names (default)")
    if "SPY" not in tickers:
        tickers.append("SPY")

    print(f"Loading {len(tickers)} tickers {args.start} -> {end} ...")
    data = datamod.get_data(tickers, args.start, end, use_cache=not args.no_cache)
    print(f"Loaded {len(data)} tickers.\n")

    regime = None if args.no_regime else short_regime(data)
    if regime is not None:
        print(f"Short-friendly regime: ON (SPY BELOW 200-SMA). "
              f"Short-OK on {regime.mean()*100:.0f}% of days.")
    else:
        print("Regime gate: OFF (shorting in all regimes).")
    print(f"Borrow cost: {args.borrow_rate*100:.1f}%/yr" +
          ("  | Trailing stop: ON" if args.trailing_stop else "") + "\n")

    rpt.OUTPUT_DIR = SHORT_OUTPUT  # redirect charts/report to output/short

    if args.compare:
        results = []
        for sname in SHORT_STRATS:
            strat = build_short_strategy(sname)
            print(f"Running {strat.name} ...")
            r = _make_bt(args, strat).run(data, market_ok=regime)
            results.append((r, equity_metrics(r), trade_metrics(r.trades)))
        bench = spy_benchmark(args.capital, results[0][0].equity.index[0],
                              results[0][0].equity.index[-1], data)
        print("\n" + "=" * 79)
        print("   SHORT-STRATEGY COMPARISON")
        print("=" * 79)
        print(rpt.comparison_table(results, bench))
        print("=" * 79)
        os.makedirs(SHORT_OUTPUT, exist_ok=True)
        print(f"\nComparison chart: {rpt.plot_comparison(results, bench)}")
        return 0

    strat = build_short_strategy(args.strategy, **_overrides(args))
    print(f"Running SHORT backtest: {strat.name} ...")
    res = _make_bt(args, strat).run(data, market_ok=regime)
    em, tm = equity_metrics(res), trade_metrics(res.trades)
    bench = spy_benchmark(args.capital, res.equity.index[0],
                          res.equity.index[-1], data)
    print()
    print(rpt.console_summary(res, em, tm, bench))
    print()

    if args.oos_split:
        for sub in (slice_result(res, res.equity.index[0], args.oos_split, "in-sample"),
                    slice_result(res, args.oos_split, res.equity.index[-1], "out-of-sample")):
            sem, stm = equity_metrics(sub), trade_metrics(sub.trades)
            print(f"  {sub.strategy_name:<26} Return {sem.total_return*100:+6.1f}%  "
                  f"CAGR {sem.cagr*100:+5.1f}%  Win {stm.win_rate*100:4.1f}%  "
                  f"PF {stm.profit_factor:4.2f}  MaxDD {sem.max_drawdown*100:5.1f}%  "
                  f"Trades {stm.n_trades}")
        print()

    os.makedirs(SHORT_OUTPUT, exist_ok=True)
    charts = rpt.generate_charts(res, bench)
    md = rpt._safe_text_write(os.path.join(SHORT_OUTPUT, "report.md"),
                              short_markdown(res, em, tm, bench, charts))
    log = rpt.write_trade_log(res)
    print(f"Report: {md}\nTrades: {log}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""
Central configuration for the paper-trading analytics tool.

Everything the grader/professor cares about (capital, risk rules, benchmark,
strategy sleeves) is declared here so it is transparent and easy to defend in
the write-up.
"""
from __future__ import annotations

# ----------------------------------------------------------------------------
# Account
# ----------------------------------------------------------------------------
STARTING_CAPITAL: float = 100_000.00          # USD paper account
CURRENCY: str = "USD"

# ----------------------------------------------------------------------------
# Risk management rules (the core of the grade)
# ----------------------------------------------------------------------------
RISK_PER_TRADE_PCT: float = 0.01              # 1% of capital risked per swing trade
RISK_PER_TRADE_PCT_OVERNIGHT: float = 0.005   # 0.5% for overnight ("BTST-equivalent") trades
MIN_REWARD_RISK: float = 2.0                  # target reward:risk of at least 2:1
MAX_POSITION_PCT: float = 0.10                # <= 10% of capital in one stock
MAX_SECTOR_PCT: float = 0.25                  # <= 25% of capital in one sector
MAX_DEPLOYED_PCT: float = 0.70                # <= 70% of capital deployed at once

# ----------------------------------------------------------------------------
# Benchmark & risk-free rate
# ----------------------------------------------------------------------------
BENCHMARK_TICKER: str = "SPY"                 # S&P 500 ETF
RISK_FREE_ANNUAL: float = 0.04                # ~4% annual risk-free (US T-bill proxy)
TRADING_DAYS_PER_YEAR: int = 252

# Manual fallback used only if live SPY data cannot be fetched (offline).
# Update these to the real SPY close on your start/end dates if needed.
BENCHMARK_FALLBACK_START_PRICE: float = 620.0
BENCHMARK_FALLBACK_END_PRICE: float = 632.0

# ----------------------------------------------------------------------------
# Strategy sleeves (capital allocation) — must match labels used in the journal
# ----------------------------------------------------------------------------
SLEEVES: dict[str, dict] = {
    "A_EARNINGS":       {"name": "Post-earnings drift swing", "capital": 25_000, "risk_pct": 0.01},
    "B_REL_STRENGTH":   {"name": "Relative strength / sector rotation", "capital": 25_000, "risk_pct": 0.01},
    "C_MEAN_REVERSION": {"name": "Mean reversion (RSI-2 oversold)", "capital": 15_000, "risk_pct": 0.01},
    "D_PAIRS":          {"name": "Market-neutral pairs", "capital": 20_000, "risk_pct": 0.01},
    "E_OVERNIGHT":      {"name": "Overnight momentum (BTST-equivalent)", "capital": 15_000, "risk_pct": 0.005},
}

# ----------------------------------------------------------------------------
# Paths
# ----------------------------------------------------------------------------
DATA_DIR: str = "data"
OUTPUT_DIR: str = "output"
DEFAULT_TRADES_FILE: str = "data/sample_trades.csv"
TEMPLATE_FILE: str = "data/trades_template.csv"

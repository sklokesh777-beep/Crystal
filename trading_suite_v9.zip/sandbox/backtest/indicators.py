"""
Technical indicators (vectorised pandas).

All functions take/return pandas Series aligned to the price index. RSI and ATR
use Wilder's smoothing, the standard used by Connors' RSI-2 research.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def sma(series: pd.Series, period: int) -> pd.Series:
    return series.rolling(period, min_periods=period).mean()


def ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False, min_periods=period).mean()


def rsi(series: pd.Series, period: int = 2) -> pd.Series:
    """Wilder's RSI. Period 2 is the Connors mean-reversion classic."""
    delta = series.diff()
    gain = delta.clip(lower=0.0)
    loss = -delta.clip(upper=0.0)
    avg_gain = gain.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()
    avg_loss = loss.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()
    rs = avg_gain / avg_loss.replace(0.0, np.nan)
    out = 100.0 - (100.0 / (1.0 + rs))
    # When avg_loss is 0 (no down moves), RSI is 100.
    out = out.fillna(100.0)
    return out


def atr(high: pd.Series, low: pd.Series, close: pd.Series,
        period: int = 14) -> pd.Series:
    """Average True Range (Wilder)."""
    prev_close = close.shift(1)
    tr = pd.concat([
        (high - low).abs(),
        (high - prev_close).abs(),
        (low - prev_close).abs(),
    ], axis=1).max(axis=1)
    return tr.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()


def bollinger(series: pd.Series, period: int = 20, num_std: float = 2.0):
    """Return (middle, upper, lower) Bollinger Bands."""
    mid = series.rolling(period, min_periods=period).mean()
    sd = series.rolling(period, min_periods=period).std(ddof=0)
    upper = mid + num_std * sd
    lower = mid - num_std * sd
    return mid, upper, lower



# ---------------------------------------------------------------------------
# Extended indicator suite
# ---------------------------------------------------------------------------
def macd(series: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    """Return (macd_line, signal_line, histogram)."""
    macd_line = ema(series, fast) - ema(series, slow)
    signal_line = macd_line.ewm(span=signal, adjust=False,
                                min_periods=signal).mean()
    hist = macd_line - signal_line
    return macd_line, signal_line, hist


def adx(high: pd.Series, low: pd.Series, close: pd.Series,
        period: int = 14):
    """Wilder ADX with directional indicators. Return (adx, +DI, -DI)."""
    up = high.diff()
    down = -low.diff()
    plus_dm = ((up > down) & (up > 0)) * up.clip(lower=0)
    minus_dm = ((down > up) & (down > 0)) * down.clip(lower=0)

    prev_close = close.shift(1)
    tr = pd.concat([(high - low).abs(),
                    (high - prev_close).abs(),
                    (low - prev_close).abs()], axis=1).max(axis=1)

    atr_ = tr.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()
    plus_di = 100 * plus_dm.ewm(alpha=1.0 / period, adjust=False,
                                min_periods=period).mean() / atr_
    minus_di = 100 * minus_dm.ewm(alpha=1.0 / period, adjust=False,
                                  min_periods=period).mean() / atr_
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
    adx_ = dx.ewm(alpha=1.0 / period, adjust=False, min_periods=period).mean()
    return adx_, plus_di, minus_di


def stochastic(high: pd.Series, low: pd.Series, close: pd.Series,
               k_period: int = 14, d_period: int = 3):
    """Return (%K, %D) stochastic oscillator."""
    lowest = low.rolling(k_period, min_periods=k_period).min()
    highest = high.rolling(k_period, min_periods=k_period).max()
    k = 100 * (close - lowest) / (highest - lowest).replace(0, np.nan)
    d = k.rolling(d_period, min_periods=d_period).mean()
    return k, d


def obv(close: pd.Series, volume: pd.Series) -> pd.Series:
    """On-Balance Volume."""
    direction = pd.Series(0, index=close.index)
    direction[close > close.shift(1)] = 1
    direction[close < close.shift(1)] = -1
    return (direction * volume).cumsum()


def roc(series: pd.Series, period: int = 63) -> pd.Series:
    """Rate of change (%) over `period` bars (63 ~ 3 trading months)."""
    return (series / series.shift(period) - 1.0) * 100.0


def percent_b(series: pd.Series, period: int = 20, num_std: float = 2.0) -> pd.Series:
    """Bollinger %B: 0 = lower band, 1 = upper band."""
    mid, upper, lower = bollinger(series, period, num_std)
    return (series - lower) / (upper - lower).replace(0, np.nan)


def sma_slope(series: pd.Series, period: int = 50, lookback: int = 20) -> pd.Series:
    """Normalised slope of an SMA (rising/falling trend), in % over lookback."""
    s = sma(series, period)
    return (s / s.shift(lookback) - 1.0) * 100.0



# ---------------------------------------------------------------------------
# v9 sprint indicators (short-hold swing / breakout toolkit)
# ---------------------------------------------------------------------------
def donchian_high(high: pd.Series, period: int = 20) -> pd.Series:
    """Highest high over the prior `period` bars (shifted 1 = no look-ahead)."""
    return high.rolling(period, min_periods=period).max().shift(1)


def donchian_low(low: pd.Series, period: int = 20) -> pd.Series:
    """Lowest low over the prior `period` bars (shifted 1)."""
    return low.rolling(period, min_periods=period).min().shift(1)


def rvol(volume: pd.Series, period: int = 20) -> pd.Series:
    """Relative volume: today's volume / its `period`-day average."""
    avg = volume.rolling(period, min_periods=period).mean()
    return volume / avg.replace(0, np.nan)


def supertrend(high: pd.Series, low: pd.Series, close: pd.Series,
               period: int = 10, multiplier: float = 3.0):
    """
    Supertrend. Returns (supertrend_line, direction) where direction is +1
    (uptrend) or -1 (downtrend). Used here as a TREND FILTER / trailing stop,
    not a standalone entry (it whipsaws in chop — hence the ADX/SMA gates).
    """
    atr_ = atr(high, low, close, period)
    hl2 = (high + low) / 2.0
    upper = hl2 + multiplier * atr_
    lower = hl2 - multiplier * atr_

    st = pd.Series(index=close.index, dtype=float)
    dirn = pd.Series(index=close.index, dtype=float)
    prev_st = np.nan
    prev_dir = 1
    for i in range(len(close)):
        c = close.iat[i]
        ub, lb = upper.iat[i], lower.iat[i]
        if np.isnan(ub) or np.isnan(lb):
            st.iat[i] = np.nan
            dirn.iat[i] = prev_dir
            continue
        if np.isnan(prev_st):
            prev_st = lb
            prev_dir = 1
        # carry the tighter band
        if prev_dir == 1:
            lb = max(lb, prev_st)
        else:
            ub = min(ub, prev_st)
        if prev_dir == 1 and c < lb:
            prev_dir = -1
            prev_st = ub
        elif prev_dir == -1 and c > ub:
            prev_dir = 1
            prev_st = lb
        else:
            prev_st = lb if prev_dir == 1 else ub
        st.iat[i] = prev_st
        dirn.iat[i] = prev_dir
    return st, dirn


def chandelier_long(high: pd.Series, low: pd.Series, close: pd.Series,
                    period: int = 22, multiplier: float = 3.0) -> pd.Series:
    """
    Chandelier exit for longs: highest-high(period) - multiplier*ATR(period).
    A volatility-based trailing stop that locks gains faster than a time stop.
    """
    atr_ = atr(high, low, close, period)
    hh = high.rolling(period, min_periods=period).max()
    return hh - multiplier * atr_

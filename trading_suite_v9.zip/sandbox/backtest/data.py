"""
Historical data loader with local caching.

Downloads adjusted daily OHLCV for a basket of tickers via yfinance and caches
each ticker to data/cache/<TICKER>.csv. Subsequent runs load from cache (fast,
and works offline), only downloading tickers that are missing or don't cover
the requested date range.
"""
from __future__ import annotations

import os
from datetime import date, datetime
from typing import Dict, List

import pandas as pd

CACHE_DIR = os.path.join("data", "cache")
_OHLCV = ["Open", "High", "Low", "Close", "Volume"]


def _cache_path(ticker: str) -> str:
    return os.path.join(CACHE_DIR, f"{ticker.upper()}.csv")


def _load_cached(ticker: str, start: str, end: str) -> pd.DataFrame | None:
    path = _cache_path(ticker)
    if not os.path.exists(path):
        return None
    try:
        df = pd.read_csv(path, index_col=0, parse_dates=True)
    except Exception:
        return None
    if df.empty or not set(_OHLCV).issubset(df.columns):
        return None
    # Ensure the cache covers the requested window (with a small tolerance).
    if df.index.min() > pd.Timestamp(start) + pd.Timedelta(days=7):
        return None
    if df.index.max() < pd.Timestamp(end) - pd.Timedelta(days=10):
        return None
    return df.loc[start:end]


def _download_one(ticker: str, start: str, end: str) -> pd.DataFrame | None:
    import yfinance as yf
    try:
        df = yf.download(ticker, start=start, end=end, progress=False,
                         auto_adjust=True)
    except Exception as exc:
        print(f"  ! download failed for {ticker}: {exc}")
        return None
    if df is None or df.empty:
        return None
    # yfinance may return MultiIndex columns for a single ticker; flatten.
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df = df[[c for c in _OHLCV if c in df.columns]].dropna()
    return df if not df.empty else None


def _download_batch(tickers: List[str], start: str, end: str,
                    chunk_size: int = 100) -> Dict[str, pd.DataFrame]:
    """Download many tickers efficiently (threaded, chunked) and cache each."""
    import yfinance as yf
    out: Dict[str, pd.DataFrame] = {}
    for k in range(0, len(tickers), chunk_size):
        chunk = tickers[k:k + chunk_size]
        print(f"  downloading batch {k // chunk_size + 1} "
              f"({len(chunk)} tickers) ...")
        try:
            raw = yf.download(chunk, start=start, end=end, progress=False,
                              auto_adjust=True, group_by="ticker", threads=True)
        except Exception as exc:
            print(f"  ! batch download error: {exc}")
            raw = None
        if raw is None or raw.empty:
            continue
        for t in chunk:
            try:
                if isinstance(raw.columns, pd.MultiIndex):
                    if t not in raw.columns.get_level_values(0):
                        continue
                    df = raw[t]
                else:
                    df = raw  # single-ticker fallback
                df = df[[c for c in _OHLCV if c in df.columns]].dropna()
            except Exception:
                continue
            if df is None or df.empty:
                continue
            df.to_csv(_cache_path(t))
            out[t] = df.loc[start:end]
    return out


def get_data(tickers: List[str],
             start: str,
             end: str,
             use_cache: bool = True) -> Dict[str, pd.DataFrame]:
    """
    Return {ticker: DataFrame[Open,High,Low,Close,Volume]} indexed by date.

    Loads cached tickers first, then batch-downloads whatever is missing.
    Scales to hundreds of tickers.
    """
    os.makedirs(CACHE_DIR, exist_ok=True)
    out: Dict[str, pd.DataFrame] = {}
    to_download: List[str] = []

    for t in tickers:
        t = t.upper()
        df = _load_cached(t, start, end) if use_cache else None
        if df is not None:
            out[t] = df
        else:
            to_download.append(t)

    if to_download:
        print(f"  {len(out)} cached, downloading {len(to_download)} tickers ...")
        downloaded = _download_batch(to_download, start, end)
        out.update(downloaded)
        missing = set(to_download) - set(downloaded)
        if missing:
            print(f"  ! no data for {len(missing)} tickers "
                  f"(e.g. {sorted(list(missing))[:6]})")

    if not out:
        raise RuntimeError("No data could be loaded for any ticker.")
    return out


# A curated default universe: liquid US large-caps across sectors + core ETFs.
DEFAULT_UNIVERSE = [
    # mega-cap tech
    "AAPL", "MSFT", "NVDA", "GOOGL", "AMZN", "META", "AVGO", "ORCL",
    # financials
    "JPM", "BAC", "V", "MA",
    # healthcare / staples (defensive, good for mean reversion)
    "JNJ", "UNH", "LLY", "PG", "KO", "PEP", "WMT", "HD", "COST",
    # energy / industrials
    "XOM", "CVX", "CAT", "HON",
    # core ETFs
    "SPY", "QQQ",
]

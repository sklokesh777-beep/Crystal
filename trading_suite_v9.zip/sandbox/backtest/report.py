"""
Backtest reporting: console summary, charts, and a Markdown report.
"""
from __future__ import annotations

import os
from datetime import date

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np
import pandas as pd

from backtest.engine import BacktestResult
from backtest.metrics import (EquityMetrics, TradeMetrics, Benchmark,
                              equity_metrics, trade_metrics, score_bucket_stats)

OUTPUT_DIR = os.path.join("output", "backtest")

plt.rcParams.update({
    "figure.figsize": (11, 6), "figure.dpi": 130, "axes.grid": True,
    "grid.alpha": 0.3, "font.size": 11, "axes.titlesize": 14,
    "axes.titleweight": "bold",
})
_BLUE, _GREY, _RED, _GREEN = "#2166ac", "#888888", "#d73027", "#1a9850"


def _pct(x): return f"{x*100:+.2f}%"
def _money(x): return f"${x:,.0f}"
def _pf(x): return "inf" if x == float("inf") else f"{x:.2f}"


# ---------------------------------------------------------------------------
def console_summary(res: BacktestResult, em: EquityMetrics, tm: TradeMetrics,
                    bench: Benchmark | None) -> str:
    L, add = [], lambda s: L.append(s)
    add("=" * 68)
    add(f"   BACKTEST RESULTS — {res.strategy_name}  "
        f"({res.equity.index[0].date()} to {res.equity.index[-1].date()})")
    add("=" * 68)
    add(f"  Universe             : {len(res.universe)} symbols")
    add(f"  Initial capital      : {_money(res.initial_capital)}")
    add(f"  Final equity         : {_money(res.equity.iloc[-1])}")
    add(f"  Total return         : {_pct(em.total_return)}  over {em.years:.1f} yrs")
    add(f"  CAGR                 : {_pct(em.cagr)}")
    if bench:
        add(f"  SPY buy & hold CAGR  : {_pct(bench.cagr)}  "
            f"(total {_pct(bench.total_return)})")
        add(f"  -> CAGR vs SPY       : {_pct(em.cagr - bench.cagr)}")
    add("-" * 68)
    add(f"  Trades               : {tm.n_trades}  (W {tm.wins} / L {tm.losses})")
    add(f"  WIN RATE             : {tm.win_rate*100:.1f}%")
    add(f"  Profit factor        : {_pf(tm.profit_factor)}")
    add(f"  Expectancy / trade   : {_money(tm.expectancy)}  ({tm.avg_r:+.2f}R)")
    add(f"  Avg win / avg loss   : {_money(tm.avg_win)} / {_money(tm.avg_loss)}")
    add(f"  Best / worst trade   : {_money(tm.best)} / {_money(tm.worst)}")
    add(f"  Avg holding period   : {tm.avg_hold_days:.1f} days")
    add(f"  Exit reasons         : {tm.exit_breakdown}")
    add("-" * 68)
    add(f"  Max drawdown         : {_pct(em.max_drawdown)}")
    if bench:
        add(f"  SPY max drawdown     : {_pct(bench.max_drawdown)}")
    add(f"  Annualised vol       : {_pct(em.volatility)}")
    add(f"  Sharpe / Sortino     : {em.sharpe:.2f} / {em.sortino:.2f}")
    add(f"  Calmar (CAGR/MaxDD)  : {em.calmar:.2f}")
    add(f"  Avg exposure         : {em.avg_exposure*100:.1f}% of capital invested")
    if getattr(res, "realized_avg_corr", None) is not None and \
            res.realized_avg_corr == res.realized_avg_corr:  # not NaN
        add(f"  Realized diversification: avg pairwise corr of held names "
            f"= {res.realized_avg_corr:.2f}")
    if getattr(res, "skipped_correlation", 0):
        add(f"  Entries skipped (correlation control): {res.skipped_correlation}")
    buckets = score_bucket_stats(res.trades)
    if buckets:
        add("-" * 68)
        add("  WIN RATE BY CONFLUENCE SCORE (does the indicator score help?)")
        add(f"    {'Score':<10}{'Trades':>8}{'WinRate':>10}{'AvgR':>8}")
        for b in buckets:
            add(f"    {b['bucket']:<10}{b['n']:>8}{b['win_rate']*100:>9.1f}%"
                f"{b['avg_r']:>8.2f}")
    add("=" * 68)
    return "\n".join(L)


# ---------------------------------------------------------------------------
def _ensure_out():
    os.makedirs(OUTPUT_DIR, exist_ok=True)


def _p(name): return os.path.join(OUTPUT_DIR, name)


def _alt(path: str) -> str:
    import time
    root, ext = os.path.splitext(path)
    return f"{root}_{int(time.time())}{ext}"


def _safe_savefig(fig, out: str) -> str:
    """Save a figure; if the file is locked (open in a viewer), save a copy."""
    try:
        fig.savefig(out)
        return out
    except PermissionError:
        alt = _alt(out)
        fig.savefig(alt)
        print(f"  ! {out} is open/locked — saved chart to {alt} instead.")
        return alt


def _safe_text_write(path: str, text: str) -> str:
    try:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(text)
        return path
    except PermissionError:
        alt = _alt(path)
        with open(alt, "w", encoding="utf-8") as fh:
            fh.write(text)
        print(f"  ! {path} is open/locked — wrote to {alt} instead.")
        return alt


def _safe_df_write(df, path: str) -> str:
    try:
        df.to_csv(path, index=False)
        return path
    except PermissionError:
        alt = _alt(path)
        df.to_csv(alt, index=False)
        print(f"  ! {path} is open/locked (close it in Excel) — "
              f"wrote to {alt} instead.")
        return alt


def plot_equity(res: BacktestResult, bench: Benchmark | None) -> str:
    _ensure_out()
    fig, ax = plt.subplots()
    ax.plot(res.equity.index, res.equity.values, color=_BLUE, lw=2,
            label=f"{res.strategy_name} strategy")
    if bench is not None and bench.equity is not None:
        b = bench.equity.reindex(res.equity.index).ffill()
        ax.plot(b.index, b.values, color=_GREY, lw=1.8, ls="--",
                label="SPY buy & hold")
    ax.set_yscale("log")
    ax.set_title("Equity Curve (log scale) — Strategy vs SPY")
    ax.set_ylabel("Portfolio value ($, log)")
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"${x:,.0f}"))
    ax.legend()
    fig.tight_layout(); out = _p("equity_curve.png"); out = _safe_savefig(fig, out); plt.close(fig)
    return out


def plot_drawdown(res: BacktestResult) -> str:
    _ensure_out()
    peak = res.equity.cummax()
    dd = (res.equity - peak) / peak * 100
    fig, ax = plt.subplots()
    ax.fill_between(dd.index, dd.values, 0, color=_RED, alpha=0.35)
    ax.plot(dd.index, dd.values, color=_RED, lw=1)
    ax.set_title("Drawdown (Underwater) Curve")
    ax.set_ylabel("Drawdown (%)")
    fig.tight_layout(); out = _p("drawdown.png"); out = _safe_savefig(fig, out); plt.close(fig)
    return out


def plot_yearly_returns(res: BacktestResult) -> str:
    _ensure_out()
    yearly = res.equity.resample("YE").last().pct_change()
    # first year: from initial capital
    first = res.equity.resample("YE").last().iloc[0] / res.initial_capital - 1
    yearly.iloc[0] = first
    yearly = yearly.dropna()
    years = [d.year for d in yearly.index]
    colors = [_GREEN if v >= 0 else _RED for v in yearly.values]
    fig, ax = plt.subplots()
    ax.bar(years, yearly.values * 100, color=colors, alpha=0.85)
    ax.axhline(0, color="black", lw=0.8)
    ax.set_title("Calendar-Year Returns")
    ax.set_ylabel("Return (%)")
    for x, v in zip(years, yearly.values * 100):
        ax.annotate(f"{v:.0f}%", (x, v), ha="center",
                    va="bottom" if v >= 0 else "top", fontsize=8)
    fig.tight_layout(); out = _p("yearly_returns.png"); out = _safe_savefig(fig, out); plt.close(fig)
    return out


def plot_trade_pnl(res: BacktestResult) -> str:
    _ensure_out()
    pnls = [t.pnl for t in res.trades]
    fig, ax = plt.subplots()
    ax.hist(pnls, bins=40, color=_BLUE, alpha=0.8, edgecolor="white")
    ax.axvline(0, color="black", lw=1)
    ax.axvline(float(np.mean(pnls)), color=_GREEN, lw=2, ls="--",
               label=f"Mean = ${np.mean(pnls):,.0f}")
    ax.set_title("Distribution of Trade P/L")
    ax.set_xlabel("Profit / Loss per trade ($)")
    ax.set_ylabel("Number of trades")
    ax.legend()
    fig.tight_layout(); out = _p("trade_pnl.png"); out = _safe_savefig(fig, out); plt.close(fig)
    return out


def generate_charts(res: BacktestResult, bench: Benchmark | None) -> list:
    return [plot_equity(res, bench), plot_drawdown(res),
            plot_yearly_returns(res), plot_trade_pnl(res)]


# ---------------------------------------------------------------------------
def markdown_report(res: BacktestResult, em: EquityMetrics, tm: TradeMetrics,
                    bench: Benchmark | None, charts: list) -> str:
    L, add = [], lambda s: L.append(s)
    add(f"# Backtest Report — {res.strategy_name}")
    add("")
    add(f"*Window: {res.equity.index[0].date()} to {res.equity.index[-1].date()} "
        f"({em.years:.1f} years) · {len(res.universe)} symbols · "
        f"generated {date.today().isoformat()}*")
    add("")
    add("## Headline")
    add("")
    add(f"- **Total return:** {_pct(em.total_return)} "
        f"({_money(res.initial_capital)} -> {_money(res.equity.iloc[-1])})")
    add(f"- **CAGR:** {_pct(em.cagr)}")
    if bench:
        add(f"- **SPY buy & hold CAGR:** {_pct(bench.cagr)} "
            f"-> **edge {_pct(em.cagr - bench.cagr)}**")
    add(f"- **Win rate:** {tm.win_rate*100:.1f}%  ·  **Profit factor:** {_pf(tm.profit_factor)}")
    add(f"- **Max drawdown:** {_pct(em.max_drawdown)}"
        + (f"  (SPY: {_pct(bench.max_drawdown)})" if bench else ""))
    add(f"- **Sharpe / Sortino / Calmar:** {em.sharpe:.2f} / {em.sortino:.2f} / {em.calmar:.2f}")
    add(f"- **Trades:** {tm.n_trades}  ·  **Avg hold:** {tm.avg_hold_days:.1f} days  "
        f"·  **Avg exposure:** {em.avg_exposure*100:.0f}%")
    add("")
    add("## Metric tables")
    add("")
    add("| Return / risk | Value |")
    add("|---|---|")
    add(f"| Total return | {_pct(em.total_return)} |")
    add(f"| CAGR | {_pct(em.cagr)} |")
    add(f"| Max drawdown | {_pct(em.max_drawdown)} |")
    add(f"| Annualised volatility | {_pct(em.volatility)} |")
    add(f"| Sharpe | {em.sharpe:.2f} |")
    add(f"| Sortino | {em.sortino:.2f} |")
    add(f"| Calmar (CAGR/MaxDD) | {em.calmar:.2f} |")
    add(f"| Avg exposure | {em.avg_exposure*100:.1f}% |")
    add("")
    add("| Trade stats | Value |")
    add("|---|---|")
    add(f"| Trades | {tm.n_trades} (W {tm.wins} / L {tm.losses}) |")
    add(f"| Win rate | {tm.win_rate*100:.1f}% |")
    add(f"| Profit factor | {_pf(tm.profit_factor)} |")
    add(f"| Expectancy / trade | {_money(tm.expectancy)} ({tm.avg_r:+.2f}R) |")
    add(f"| Avg win / avg loss | {_money(tm.avg_win)} / {_money(tm.avg_loss)} |")
    add(f"| Best / worst | {_money(tm.best)} / {_money(tm.worst)} |")
    add(f"| Avg holding days | {tm.avg_hold_days:.1f} |")
    add(f"| Exit reasons | {tm.exit_breakdown} |")
    add("")
    buckets = score_bucket_stats(res.trades)
    if buckets:
        add("## Does the multi-indicator confluence score help? (honest test)")
        add("")
        add("Win rate and average R-multiple grouped by the entry confluence "
            "score. If higher buckets win more often / earn more R, the score "
            "adds predictive value; if flat, it does not.")
        add("")
        add("| Score bucket | Trades | Win rate | Avg R |")
        add("|---|---|---|---|")
        for b in buckets:
            add(f"| {b['bucket']} | {b['n']} | {b['win_rate']*100:.1f}% | "
                f"{b['avg_r']:+.2f} |")
        add("")
    add("## Charts")
    add("")
    for c in charts:
        base = os.path.basename(c)
        title = os.path.splitext(base)[0].replace("_", " ").title()
        add(f"### {title}")
        add(f"![{title}]({base})")
        add("")
    add("## Honest caveats (read before quoting these numbers)")
    add("")
    add("- **Survivorship bias:** the default universe is *today's* large-caps "
        "(NVDA, AAPL, etc.). They were selected *because* they succeeded, which "
        "inflates historical results. A rigorous test would use a point-in-time "
        "index membership that includes names that later failed.")
    add("- **Bull-market regime:** 2010-2024 was one of the strongest bull runs "
        "in history. Trend-following looks exceptional here; mean-reversion "
        "lags buy-and-hold because it sits in cash much of the time.")
    add("- **No look-ahead, but idealised fills:** stops/exits assume you get "
        "the modelled price; real fills can be worse around gaps.")
    add("- **Past performance does not guarantee future results.** This is an "
        "educational backtest, **not investment advice.**")
    add("")
    add("---")
    add("*Backtest assumptions: signals read at each bar's close and filled at "
        "the next bar's open (no look-ahead); per-trade commission and slippage "
        "applied to every fill; ATR-based protective stop and a max-holding "
        "time stop bound each trade's risk. Prices are split/dividend-adjusted.*")
    return "\n".join(L)


def write_report(res, em, tm, bench, charts) -> str:
    _ensure_out()
    return _safe_text_write(_p("report.md"),
                            markdown_report(res, em, tm, bench, charts))


def plot_comparison(results: list, bench: Benchmark | None) -> str:
    """Overlay every strategy's equity curve (+ SPY) on one log-scale chart."""
    _ensure_out()
    fig, ax = plt.subplots()
    palette = ["#2166ac", "#1a9850", "#d97706", "#762a83", "#c51b7d"]
    for k, (res, em, tm) in enumerate(results):
        ax.plot(res.equity.index, res.equity.values,
                color=palette[k % len(palette)], lw=1.8,
                label=f"{res.strategy_name} (CAGR {em.cagr*100:.1f}%, "
                      f"win {tm.win_rate*100:.0f}%)")
    if bench is not None and bench.equity is not None:
        ax.plot(bench.equity.index, bench.equity.values, color="#888888",
                lw=1.8, ls="--", label=f"SPY buy & hold (CAGR {bench.cagr*100:.1f}%)")
    ax.set_yscale("log")
    ax.set_title("Strategy Comparison — Equity Curves (log scale)")
    ax.set_ylabel("Portfolio value ($, log)")
    ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f"${x:,.0f}"))
    ax.legend(fontsize=9)
    fig.tight_layout(); out = _p("comparison.png"); out = _safe_savefig(fig, out); plt.close(fig)
    return out


def comparison_table(results: list, bench: Benchmark | None) -> str:
    """Console + markdown comparison table across strategies."""
    lines = []
    lines.append(f"{'Strategy':<12}{'WinRate':>9}{'CAGR':>9}{'vsSPY':>9}"
                 f"{'MaxDD':>9}{'PF':>7}{'Sharpe':>8}{'Trades':>8}")
    lines.append("-" * 79)
    for res, em, tm in results:
        vs = em.cagr - bench.cagr if bench else 0.0
        pf = "inf" if tm.profit_factor == float("inf") else f"{tm.profit_factor:.2f}"
        lines.append(
            f"{res.strategy_name:<12}{tm.win_rate*100:>8.1f}%{em.cagr*100:>8.1f}%"
            f"{vs*100:>+8.1f}%{em.max_drawdown*100:>8.1f}%{pf:>7}"
            f"{em.sharpe:>8.2f}{tm.n_trades:>8}")
    if bench:
        lines.append("-" * 79)
        lines.append(f"{'SPY B&H':<12}{'—':>9}{bench.cagr*100:>8.1f}%{'—':>9}"
                     f"{bench.max_drawdown*100:>8.1f}%{'—':>7}{'—':>8}{'—':>8}")
    return "\n".join(lines)


def write_trade_log(res: BacktestResult) -> str:
    _ensure_out()
    rows = [{
        "symbol": t.symbol, "entry_date": t.entry_date.date(),
        "entry_price": round(t.entry_price, 2), "exit_date": t.exit_date.date(),
        "exit_price": round(t.exit_price, 2), "shares": t.shares,
        "hold_days": t.holding_days, "pnl": round(t.pnl, 2),
        "pnl_pct": round(t.pnl_pct * 100, 2), "r_multiple": round(t.r_multiple, 2),
        "exit_reason": t.exit_reason,
    } for t in res.trades]
    return _safe_df_write(pd.DataFrame(rows), _p("trades.csv"))

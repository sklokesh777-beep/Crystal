"""
Trading universe: the current S&P 500 constituents (~500 names), with sectors.

Fetched from Wikipedia (with a browser-like User-Agent, since the default
urllib agent is blocked) and cached to data/universe/sp500.csv. A hardcoded
fallback of large, liquid names is used if the fetch fails so the tool still
runs offline.

IMPORTANT — survivorship bias: this is *today's* index membership. Companies
that were dropped/delisted over 2010-2026 are not included, which inflates
historical backtest results. This is disclosed in every report.
"""
from __future__ import annotations

import io
import os
from typing import List, Tuple

import pandas as pd

UNIVERSE_DIR = os.path.join("data", "universe")
SP500_CACHE = os.path.join(UNIVERSE_DIR, "sp500.csv")
WIKI_URL = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
_HEADERS = {"User-Agent": "Mozilla/5.0 (educational research; backtester)"}

# Minimal, liquid fallback across sectors if the network/scrape fails.
FALLBACK = [
    "AAPL", "MSFT", "NVDA", "GOOGL", "AMZN", "META", "AVGO", "ORCL", "ADBE",
    "CRM", "AMD", "INTC", "CSCO", "QCOM", "TXN", "JPM", "BAC", "WFC", "GS",
    "MS", "V", "MA", "AXP", "BLK", "JNJ", "UNH", "LLY", "PFE", "MRK", "ABBV",
    "TMO", "ABT", "PG", "KO", "PEP", "COST", "WMT", "HD", "MCD", "NKE", "SBUX",
    "XOM", "CVX", "COP", "SLB", "CAT", "HON", "GE", "BA", "UPS", "LMT",
]


def _normalise(sym: str) -> str:
    # yfinance uses '-' where the index uses '.', e.g. BRK.B -> BRK-B
    return str(sym).strip().upper().replace(".", "-")


def _fetch_from_wikipedia() -> pd.DataFrame | None:
    try:
        import requests
        resp = requests.get(WIKI_URL, headers=_HEADERS, timeout=30)
        resp.raise_for_status()
        tables = pd.read_html(io.StringIO(resp.text))
    except Exception as exc:
        print(f"  ! could not fetch S&P 500 list from Wikipedia: {exc}")
        return None
    df = tables[0]
    if "Symbol" not in df.columns:
        return None
    out = pd.DataFrame({
        "symbol": [_normalise(s) for s in df["Symbol"]],
        "name": df.get("Security", pd.Series([""] * len(df))),
        "sector": df.get("GICS Sector", pd.Series([""] * len(df))),
    })
    return out.drop_duplicates("symbol").reset_index(drop=True)


def get_sp500(use_cache: bool = True,
              refresh: bool = False) -> Tuple[List[str], dict]:
    """
    Return (symbols, sector_map).

    symbols: list of ~500 tickers (yfinance format).
    sector_map: {symbol: GICS sector}.
    """
    os.makedirs(UNIVERSE_DIR, exist_ok=True)

    df = None
    if use_cache and not refresh and os.path.exists(SP500_CACHE):
        try:
            df = pd.read_csv(SP500_CACHE)
        except Exception:
            df = None

    if df is None:
        df = _fetch_from_wikipedia()
        if df is not None:
            df.to_csv(SP500_CACHE, index=False)

    if df is None or df.empty:
        print("  ! using hardcoded fallback universe")
        return list(FALLBACK), {s: "Unknown" for s in FALLBACK}

    symbols = df["symbol"].tolist()
    sector_map = dict(zip(df["symbol"], df.get("sector", ["Unknown"] * len(df))))
    return symbols, sector_map


_SP_EXTRA_URLS = {
    400: "https://en.wikipedia.org/wiki/List_of_S%26P_400_companies",
    600: "https://en.wikipedia.org/wiki/List_of_S%26P_600_companies",
}


def _fetch_sp_symbols(url: str) -> list:
    """Fetch the Symbol column from any S&P constituents Wikipedia page."""
    try:
        import requests
        resp = requests.get(url, headers=_HEADERS, timeout=30)
        resp.raise_for_status()
        tables = pd.read_html(io.StringIO(resp.text))
    except Exception as exc:
        print(f"  ! could not fetch {url}: {exc}")
        return []
    for t in tables:
        symcol = next((c for c in t.columns if "Symbol" in str(c)), None)
        if symcol is not None:
            return [_normalise(s) for s in t[symcol].tolist()]
    return []


def get_expanded(target: int = 1000, use_cache: bool = True) -> list:
    """
    A ~`target`-name universe = S&P 500 (large) + S&P 400 (mid) + S&P 600
    (small), deduped in that order and truncated to `target`. Cached.

    NOTE: the added mid/small-caps are less liquid and noisier than the S&P 500
    — see README Part 9 for the honest before/after showing this dilutes, not
    improves, the edge.
    """
    os.makedirs(UNIVERSE_DIR, exist_ok=True)
    cache = os.path.join(UNIVERSE_DIR, f"expanded_{target}.csv")
    if use_cache and os.path.exists(cache):
        try:
            return pd.read_csv(cache)["symbol"].tolist()
        except Exception:
            pass
    sp500, _ = get_sp500()
    mid = _fetch_sp_symbols(_SP_EXTRA_URLS[400])
    small = _fetch_sp_symbols(_SP_EXTRA_URLS[600])
    combined, seen = [], set()
    for s in list(sp500) + mid + small:
        if s and s not in seen:
            seen.add(s)
            combined.append(s)
    if len(combined) < 100:      # fetch failed badly -> fall back
        combined = list(sp500)
    out = combined[:target] if target else combined
    pd.DataFrame({"symbol": out}).to_csv(cache, index=False)
    return out


if __name__ == "__main__":
    syms, sectors = get_sp500(refresh=True)
    print(f"Loaded {len(syms)} symbols")
    print("Sample:", syms[:10])
    # sector counts
    from collections import Counter
    for sec, n in Counter(sectors.values()).most_common():
        print(f"  {sec:<28} {n}")

"""
Performance metrics for a backtest result.

Split into (a) equity-curve metrics (CAGR, drawdown, Sharpe, Sortino, Calmar,
volatility, exposure) and (b) trade-level metrics (win rate, profit factor,
expectancy, average R, holding period). Also builds a SPY buy-and-hold
benchmark over the identical window for an apples-to-apples comparison.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import numpy as np
import pandas as pd

from backtest.engine import BacktestResult, Trade

TRADING_DAYS = 252


def _safe_div(a, b, default=0.0):
    return a / b if b else default


@dataclass
class EquityMetrics:
    total_return: float
    cagr: float
    max_drawdown: float
    volatility: float
    sharpe: float
    sortino: float
    calmar: float
    avg_exposure: float
    years: float


@dataclass
class TradeMetrics:
    n_trades: int
    wins: int
    losses: int
    win_rate: float
    avg_win: float
    avg_loss: float
    profit_factor: float
    expectancy: float
    avg_r: float
    avg_hold_days: float
    best: float
    worst: float
    exit_breakdown: dict


@dataclass
class Benchmark:
    ticker: str
    total_return: float
    cagr: float
    max_drawdown: float
    equity: Optional[pd.Series]


def _max_drawdown(equity: pd.Series) -> float:
    peak = equity.cummax()
    dd = (equity - peak) / peak
    return float(dd.min()) if len(dd) else 0.0


def equity_metrics(res: BacktestResult,
                   risk_free_annual: float = 0.04) -> EquityMetrics:
    eq = res.equity
    rets = eq.pct_change().dropna()
    years = max((eq.index[-1] - eq.index[0]).days / 365.25, 1e-9)

    total_return = eq.iloc[-1] / res.initial_capital - 1.0
    cagr = (eq.iloc[-1] / res.initial_capital) ** (1.0 / years) - 1.0
    mdd = _max_drawdown(eq)
    vol = float(rets.std(ddof=1) * np.sqrt(TRADING_DAYS)) if len(rets) > 1 else 0.0

    rf_daily = risk_free_annual / TRADING_DAYS
    excess = rets - rf_daily
    std = rets.std(ddof=1)
    downside = np.sqrt(np.mean(np.square(np.minimum(0.0, rets - rf_daily)))) \
        if len(rets) else 0.0
    sharpe = _safe_div(excess.mean(), std) * np.sqrt(TRADING_DAYS) if std else 0.0
    sortino = _safe_div(excess.mean(), downside) * np.sqrt(TRADING_DAYS) \
        if downside else 0.0
    calmar = _safe_div(cagr, abs(mdd)) if mdd else 0.0

    return EquityMetrics(
        total_return=float(total_return),
        cagr=float(cagr),
        max_drawdown=float(mdd),
        volatility=float(vol),
        sharpe=float(sharpe),
        sortino=float(sortino),
        calmar=float(calmar),
        avg_exposure=float(res.invested_pct.mean()),
        years=float(years),
    )


def trade_metrics(trades: List[Trade]) -> TradeMetrics:
    n = len(trades)
    if n == 0:
        return TradeMetrics(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, {})
    pnls = np.array([t.pnl for t in trades])
    wins = pnls[pnls > 0]
    losses = pnls[pnls < 0]
    rs = np.array([t.r_multiple for t in trades])
    rs = rs[np.isfinite(rs)]

    exit_breakdown: dict = {}
    for t in trades:
        exit_breakdown[t.exit_reason] = exit_breakdown.get(t.exit_reason, 0) + 1

    gross_win = float(wins.sum())
    gross_loss = float(losses.sum())  # negative

    return TradeMetrics(
        n_trades=n,
        wins=int((pnls > 0).sum()),
        losses=int((pnls < 0).sum()),
        win_rate=float((pnls > 0).mean()),
        avg_win=float(wins.mean()) if len(wins) else 0.0,
        avg_loss=float(losses.mean()) if len(losses) else 0.0,
        profit_factor=_safe_div(gross_win, abs(gross_loss),
                                default=float("inf") if gross_win else 0.0),
        expectancy=float(pnls.mean()),
        avg_r=float(rs.mean()) if len(rs) else 0.0,
        avg_hold_days=float(np.mean([t.holding_days for t in trades])),
        best=float(pnls.max()),
        worst=float(pnls.min()),
        exit_breakdown=exit_breakdown,
    )


def score_bucket_stats(trades: List[Trade],
                       edges=(0, 40, 55, 70, 85, 101)) -> list:
    """
    Win rate / avg-R by entry confluence-score bucket. This is the HONEST test
    of whether the multi-indicator score actually predicts better trades — if
    higher buckets show higher win rate / avg-R, the score adds value; if not,
    it doesn't (and we say so).
    """
    rows = []
    scored = [t for t in trades if t.entry_score == t.entry_score]  # not NaN
    if not scored:
        return rows
    for lo, hi in zip(edges[:-1], edges[1:]):
        bucket = [t for t in scored if lo <= t.entry_score < hi]
        if not bucket:
            rows.append({"bucket": f"{lo}-{hi-1}", "n": 0, "win_rate": 0.0,
                         "avg_r": 0.0, "avg_pnl": 0.0})
            continue
        pnls = np.array([t.pnl for t in bucket])
        rs = np.array([t.r_multiple for t in bucket])
        rs = rs[np.isfinite(rs)]
        rows.append({
            "bucket": f"{lo}-{hi-1}",
            "n": len(bucket),
            "win_rate": float((pnls > 0).mean()),
            "avg_r": float(rs.mean()) if len(rs) else 0.0,
            "avg_pnl": float(pnls.mean()),
        })
    return rows


def spy_benchmark(initial_capital: float,
                  start: pd.Timestamp,
                  end: pd.Timestamp,
                  data: dict) -> Optional[Benchmark]:
    """Buy-and-hold SPY over the same window (uses SPY from the data dict)."""
    if "SPY" not in data:
        return None
    close = data["SPY"]["Close"].loc[start:end].dropna()
    if len(close) < 2:
        return None
    shares = initial_capital / close.iloc[0]
    equity = close * shares
    total_return = close.iloc[-1] / close.iloc[0] - 1.0
    years = max((close.index[-1] - close.index[0]).days / 365.25, 1e-9)
    cagr = (1 + total_return) ** (1.0 / years) - 1.0
    return Benchmark(
        ticker="SPY",
        total_return=float(total_return),
        cagr=float(cagr),
        max_drawdown=_max_drawdown(equity),
        equity=equity.rename("SPY_buy_hold"),
    )

"""
Technical analysis + confluence scoring.

This module is the single source of truth for:

  * `quality_score(df)`  - a vectorised 0-100 "confluence" score computed per
    bar from many indicators (trend, momentum, MACD, ADX, volume, extension).
    Used to RANK which oversold names to buy and to filter weak setups.
  * `snapshot(df)`       - the latest value of every indicator for a symbol.
  * `classify_trend(df)` - a plain-English trend label.
  * `summary(ticker,df)` - a written technical read for a human.

Design principle: indicators are *context and confirmation*, not magic. Whether
the score actually improves results is proven by the backtest's
"win rate by score bucket" table — not assumed.
"""
from __future__ import annotations

from typing import Dict

import numpy as np
import pandas as pd

from backtest import indicators as ind


def _clip01(s):
    return np.clip(s, 0.0, 1.0)


def quality_score(df: pd.DataFrame) -> pd.Series:
    """
    0-100 'buy-the-dip quality' score per bar (higher = healthier context for
    a long). Combines long/medium trend, momentum, MACD, ADX trend strength,
    volume participation, and an over-extension penalty. Uses only information
    available up to each bar (no look-ahead).
    """
    close, high, low, vol = df["Close"], df["High"], df["Low"], df["Volume"]
    sma50 = ind.sma(close, 50)
    sma200 = ind.sma(close, 200)
    roc63 = ind.roc(close, 63)
    _, _, macd_hist = ind.macd(close)
    adx_, _, _ = ind.adx(high, low, close, 14)
    vol_sma = ind.sma(vol, 20)
    slope50 = ind.sma_slope(close, 50, 20)
    ext = close / sma200                      # extension above the 200-SMA

    score = (
        20.0 * (close > sma200).astype(float)
        + 15.0 * (sma50 > sma200).astype(float)
        + 15.0 * _clip01(roc63 / 20.0)
        + 10.0 * (macd_hist > 0).astype(float)
        + 10.0 * _clip01((adx_ - 15.0) / 25.0)
        + 10.0 * (vol > vol_sma).astype(float)
        + 10.0 * _clip01(slope50 / 10.0)
        + 10.0 * (1.0 - _clip01((ext - 1.0) / 0.5))
    )
    return score.fillna(0.0).clip(0, 100)


def snapshot(df: pd.DataFrame) -> Dict[str, float]:
    """Latest value of the full indicator suite for a symbol."""
    close, high, low, vol = df["Close"], df["High"], df["Low"], df["Volume"]
    macd_line, macd_sig, macd_hist = ind.macd(close)
    adx_, pdi, mdi = ind.adx(high, low, close, 14)
    k, d = ind.stochastic(high, low, close)
    last = -1

    def g(s):
        try:
            v = float(s.iloc[last])
            return v if np.isfinite(v) else float("nan")
        except Exception:
            return float("nan")

    return {
        "close": g(close),
        "sma20": g(ind.sma(close, 20)),
        "sma50": g(ind.sma(close, 50)),
        "sma200": g(ind.sma(close, 200)),
        "ema21": g(ind.ema(close, 21)),
        "rsi2": g(ind.rsi(close, 2)),
        "rsi14": g(ind.rsi(close, 14)),
        "macd": g(macd_line),
        "macd_signal": g(macd_sig),
        "macd_hist": g(macd_hist),
        "adx": g(adx_),
        "plus_di": g(pdi),
        "minus_di": g(mdi),
        "stoch_k": g(k),
        "stoch_d": g(d),
        "atr14": g(ind.atr(high, low, close, 14)),
        "pct_b": g(ind.percent_b(close)),
        "roc63": g(ind.roc(close, 63)),
        "roc126": g(ind.roc(close, 126)),
        "score": g(quality_score(df)),
    }


def classify_trend(df: pd.DataFrame) -> str:
    s = snapshot(df)
    c, s50, s200, adx = s["close"], s["sma50"], s["sma200"], s["adx"]
    if any(np.isnan(x) for x in (c, s50, s200)):
        return "insufficient history"
    strong = (not np.isnan(adx)) and adx >= 25
    if c > s50 > s200:
        return "strong uptrend" if strong else "uptrend"
    if c < s50 < s200:
        return "strong downtrend" if strong else "downtrend"
    if c > s200:
        return "uptrend (choppy)"
    if c < s200:
        return "downtrend (choppy)"
    return "range / transition"


def summary(ticker: str, df: pd.DataFrame) -> str:
    s = snapshot(df)
    trend = classify_trend(df)
    lines = [f"Technical read — {ticker.upper()}",
             f"  Trend            : {trend}",
             f"  Price / SMA50 / SMA200 : {s['close']:.2f} / {s['sma50']:.2f} / {s['sma200']:.2f}",
             f"  RSI(2) / RSI(14) : {s['rsi2']:.1f} / {s['rsi14']:.1f}"
             + ("   [RSI2 oversold]" if s['rsi2'] < 10 else
                "   [RSI2 overbought]" if s['rsi2'] > 90 else ""),
             f"  MACD hist        : {s['macd_hist']:+.2f}"
             + ("  (momentum up)" if s['macd_hist'] > 0 else "  (momentum down)"),
             f"  ADX (+DI/-DI)    : {s['adx']:.1f} ({s['plus_di']:.0f}/{s['minus_di']:.0f})"
             + ("  [trending]" if s['adx'] >= 25 else "  [weak/range]"),
             f"  Stochastic %K/%D : {s['stoch_k']:.0f} / {s['stoch_d']:.0f}",
             f"  Bollinger %B     : {s['pct_b']:.2f}"
             + ("  (below lower band)" if s['pct_b'] < 0 else
                "  (above upper band)" if s['pct_b'] > 1 else ""),
             f"  Momentum 3m/6m   : {s['roc63']:+.1f}% / {s['roc126']:+.1f}%",
             f"  ATR(14)          : {s['atr14']:.2f}",
             f"  CONFLUENCE SCORE : {s['score']:.0f}/100",
             ]
    return "\n".join(lines)

"""
Monte Carlo window validation — the RIGHT lens for a 10-day sprint.

A 15-year CAGR tells you nothing about "can I complete >=60 round trips and
finish profitable inside ONE arbitrary 10-trading-day window." So instead of a
single long-run number, we:

  1. Prepare every symbol's signals ONCE on the full history.
  2. Sample many random 10-trading-day windows (default 250, from 2015 on).
  3. Simulate the EXACT live config in each window (fresh $100k, N concurrent
     long positions, short holds, ATR stop + take-profit + time stop, and a
     forced close of anything still open on the last day — because at the
     July-31 deadline you WOULD close everything, and those count as completed
     round trips).
  4. Report the DISTRIBUTION: trades completed, win rate, return, worst/best
     window, and the % of windows that hit >=60 trades AND finished profitable.

No look-ahead: a signal at bar t's close fills at bar t+1's open; the first
window day's entries use the prior (pre-window) day's signal, exactly like
scanning Friday's close to trade Monday's open.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

import numpy as np
import pandas as pd

from backtest.engine import _SymbolData
from backtest.strategies import Strategy


def _last_close(sd: _SymbolData, day) -> float:
    j = sd.pos_of.get(day)
    if j is not None and np.isfinite(sd.c[j]):
        return sd.c[j]
    idx = sd.dates.searchsorted(day, side="right") - 1
    return sd.c[idx] if 0 <= idx < len(sd.c) else 0.0


def simulate_window(sym: Dict[str, _SymbolData], gdates: pd.DatetimeIndex,
                    s: int, wlen: int, strat: Strategy, N: int,
                    pos_pct: float, capital: float,
                    commission: float, slip: float) -> dict:
    """Simulate one 10-day window. Returns trades completed / win rate / return."""
    stop_mult = strat.stop_atr_mult
    max_hold = strat.max_hold_days
    tpr = getattr(strat, "take_profit_r", 0.0)
    end_i = s + wlen - 1

    cash = capital
    positions: Dict[str, dict] = {}
    pnls: List[float] = []

    for i in range(s, end_i + 1):
        today = gdates[i]
        prev = gdates[i - 1]

        # ---- exits ----
        for t in list(positions.keys()):
            p = positions[t]
            sd = sym[t]
            j = sd.pos_of.get(today)
            if j is None:
                continue
            p["bars"] += 1
            o, lo, hi = sd.o[j], sd.l[j], sd.h[j]
            fill = None
            if p["stop"] > 0 and lo <= p["stop"]:
                fill = min(o, p["stop"]) * (1 - slip)
            elif p["target"] > 0 and hi >= p["target"]:
                fill = max(o, p["target"])
            else:
                pj = sd.pos_of.get(prev)
                if pj is not None and sd.exit[pj]:
                    fill = o * (1 - slip)
                elif p["bars"] >= max_hold:
                    fill = o * (1 - slip)
            if fill is not None:
                cash += fill * p["shares"] - commission
                pnls.append((fill - p["entry"]) * p["shares"])
                del positions[t]

        # ---- entries (never on the last day -> would be same-day/intraday) ----
        if len(positions) < N and i < end_i:
            cands = []
            for t, sd in sym.items():
                if t in positions:
                    continue
                pj = sd.pos_of.get(prev)
                j = sd.pos_of.get(today)
                if pj is None or j is None:
                    continue
                if sd.entry[pj] and np.isfinite(sd.o[j]) and sd.o[j] > 0:
                    cands.append((sd.rank[pj], t))
            cands.sort(key=lambda x: (np.inf if np.isnan(x[0]) else x[0]))
            mtm = cash + sum(positions[t]["shares"] * _last_close(sym[t], today)
                             for t in positions)
            for _, t in cands:
                if len(positions) >= N:
                    break
                sd = sym[t]
                j = sd.pos_of[today]
                raw = sd.o[j]
                price = raw * (1 + slip)
                atrv = sd.atr[j]
                if not (stop_mult > 0 and np.isfinite(atrv)):
                    continue
                stop = raw - stop_mult * atrv
                if stop <= 0 or stop >= price:
                    continue
                target = price + tpr * (price - stop) if tpr > 0 else 0.0
                shares = int((mtm * pos_pct) // price)
                cost = shares * price + commission
                if shares <= 0 or cost > cash:
                    continue
                cash -= cost
                positions[t] = {"entry": price, "shares": shares, "stop": stop,
                                "target": target, "bars": 0}

    # ---- forced close at the deadline (last day's close) ----
    lastday = gdates[end_i]
    for t, p in positions.items():
        c = _last_close(sym[t], lastday)
        cash += c * p["shares"] - commission
        pnls.append((c - p["entry"]) * p["shares"])

    n = len(pnls)
    wins = sum(1 for x in pnls if x > 0)
    return {"n": n, "win_rate": wins / n if n else 0.0,
            "ret": cash / capital - 1.0}


@dataclass
class MonteCarloResult:
    strategy: str
    N: int
    n_windows: int
    window_len: int
    trades: np.ndarray
    win_rates: np.ndarray
    rets: np.ndarray
    spy_rets: np.ndarray

    def summary(self) -> str:
        t, r, w, spy = self.trades, self.rets, self.win_rates, self.spy_rets
        pct = lambda a, q: np.percentile(a, q)
        hit60 = float((t >= 60).mean())
        prof = float((r > 0).mean())
        both = float(((t >= 60) & (r > 0)).mean())
        beat_spy = float((r > spy).mean())
        L = []
        add = L.append
        add(f"  Strategy / N concurrent : {self.strategy} / {self.N}")
        add(f"  Windows tested          : {self.n_windows} random "
            f"{self.window_len}-trading-day windows")
        add("  " + "-" * 60)
        add("  TRADES COMPLETED per window")
        add(f"    min / p10 / median / p90 / max : "
            f"{int(t.min())} / {int(pct(t,10))} / {int(np.median(t))} / "
            f"{int(pct(t,90))} / {int(t.max())}")
        add(f"    % of windows reaching >=60     : {hit60*100:.0f}%")
        add("  RETURN per window (net, after costs)")
        add(f"    min / p10 / median / p90 / max : "
            f"{r.min()*100:+.1f}% / {pct(r,10)*100:+.1f}% / "
            f"{np.median(r)*100:+.1f}% / {pct(r,90)*100:+.1f}% / {r.max()*100:+.1f}%")
        add(f"    % of windows profitable        : {prof*100:.0f}%")
        add(f"    % beating SPY that window      : {beat_spy*100:.0f}%")
        add(f"    median SPY return / window     : {np.median(spy)*100:+.1f}%")
        add("  COMBINED")
        add(f"    % windows with >=60 trades AND profit : {both*100:.0f}%")
        add(f"    median win rate                       : {np.median(w)*100:.0f}%")
        return "\n".join(L)


def run_montecarlo(strat: Strategy, data: Dict[str, pd.DataFrame], *,
                   n_windows: int = 250, window_len: int = 10, N: int = 18,
                   pos_pct: float = None, capital: float = 100_000.0,
                   commission: float = 1.0, slippage_bps: float = 5.0,
                   sample_from: str = "2015-01-01", seed: int = 42,
                   verbose: bool = True) -> MonteCarloResult:
    if pos_pct is None:
        pos_pct = 1.0 / N                      # ~equal-weight across N slots
    slip = slippage_bps / 10_000.0

    if verbose:
        print(f"  preparing signals for {len(data)} symbols (once) ...")
    sym: Dict[str, _SymbolData] = {t: _SymbolData(strat.prepare(df))
                                   for t, df in data.items()}
    gdates = pd.DatetimeIndex(sorted(set().union(*[set(s.dates)
                                                   for s in sym.values()])))
    spy_close = data["SPY"]["Close"] if "SPY" in data else None

    lo = gdates.searchsorted(pd.Timestamp(sample_from))
    hi = len(gdates) - window_len - 1
    rng = np.random.default_rng(seed)
    starts = rng.integers(lo, hi, size=n_windows)

    trades, wrs, rets, spy_rets = [], [], [], []
    for k, s in enumerate(starts):
        res = simulate_window(sym, gdates, int(s), window_len, strat, N,
                              pos_pct, capital, commission, slip)
        trades.append(res["n"]); wrs.append(res["win_rate"]); rets.append(res["ret"])
        if spy_close is not None:
            d0, d1 = gdates[int(s)], gdates[int(s) + window_len - 1]
            try:
                p0 = spy_close.asof(d0); p1 = spy_close.asof(d1)
                spy_rets.append(p1 / p0 - 1.0)
            except Exception:
                spy_rets.append(0.0)
        else:
            spy_rets.append(0.0)
        if verbose and (k + 1) % 50 == 0:
            print(f"    ... {k+1}/{n_windows} windows")

    return MonteCarloResult(strat.name, N, n_windows, window_len,
                            np.array(trades), np.array(wrs), np.array(rets),
                            np.array(spy_rets))

"""
Portfolio backtest engine.

Event-driven, multi-symbol, long-only swing backtester designed to avoid the
classic backtesting traps:

  * No look-ahead: signals are read at bar t's CLOSE and orders fill at bar
    t+1's OPEN.
  * Realistic frictions: per-trade commission + slippage on every fill.
  * Bounded risk: an optional ATR-based protective stop caps each loss, plus a
    max-holding-period time stop.
  * Capital constraints: a maximum number of concurrent positions and a fixed
    fraction of equity per position, so the portfolio can't over-allocate.

Optional risk-adjusted upgrades (all OFF by default — see README Part 7):
  * trailing_stop            - ratchet the ATR stop up, never down.
  * score_weighted_sizing    - scale risk 0.5%..1.5% by confluence-score
                               percentile within the day's candidate set.
  * max_correlation          - skip an entry that is >threshold correlated with
                               2+ currently-held names (diversification control).
  * exposure_multiplier      - a per-date [0,1] multiplier on position size
                               (graduated regime filter).

Execution priority each day: process exits first (free up cash), then rank and
open new entries with whatever cash/slots remain.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

import config
from backtest.strategies import Strategy


# ---------------------------------------------------------------------------
@dataclass
class Trade:
    symbol: str
    strategy: str
    entry_date: pd.Timestamp
    entry_price: float
    exit_date: pd.Timestamp
    exit_price: float
    shares: int
    stop_price: float          # the stop that was active at exit (may trail)
    exit_reason: str
    entry_score: float = float("nan")
    initial_stop: float = float("nan")  # stop at entry, used for R-multiple

    @property
    def pnl(self) -> float:
        return (self.exit_price - self.entry_price) * self.shares

    @property
    def pnl_pct(self) -> float:
        return (self.exit_price / self.entry_price) - 1.0 if self.entry_price else 0.0

    @property
    def holding_days(self) -> int:
        return (self.exit_date - self.entry_date).days

    @property
    def r_multiple(self) -> float:
        # R is measured against the INITIAL risk taken at entry, not a trailed
        # stop (which can sit above entry and would make the denominator
        # meaningless).
        base = self.initial_stop if np.isfinite(self.initial_stop) else self.stop_price
        risk = (self.entry_price - base) * self.shares
        return self.pnl / risk if risk > 0 else np.nan


@dataclass
class Position:
    symbol: str
    entry_date: pd.Timestamp
    entry_price: float
    shares: int
    stop_price: float
    initial_stop: float = float("nan")
    entry_score: float = float("nan")
    target_price: float = 0.0
    bars_held: int = 0


class _SymbolData:
    """Fast, array-based view of a prepared symbol frame."""

    __slots__ = ("dates", "o", "h", "l", "c", "entry", "exit", "rank",
                 "atr", "score", "pos_of", "ret")

    def __init__(self, df: pd.DataFrame):
        self.dates = df.index
        self.o = df["Open"].to_numpy(dtype=float)
        self.h = df["High"].to_numpy(dtype=float)
        self.l = df["Low"].to_numpy(dtype=float)
        self.c = df["Close"].to_numpy(dtype=float)
        self.entry = df["entry"].fillna(False).to_numpy(dtype=bool)
        self.exit = df["exit"].fillna(False).to_numpy(dtype=bool)
        self.rank = df["rank"].to_numpy(dtype=float)
        self.atr = df["atr"].to_numpy(dtype=float)
        self.score = (df["score"].to_numpy(dtype=float) if "score" in df.columns
                      else np.full(len(df), np.nan))
        self.pos_of = {d: i for i, d in enumerate(df.index)}
        # daily returns for correlation control (Feature 3)
        self.ret = df["Close"].pct_change()


@dataclass
class BacktestResult:
    equity: pd.Series          # daily portfolio value
    invested_pct: pd.Series    # fraction of equity deployed each day
    trades: List[Trade]
    initial_capital: float
    strategy_name: str
    universe: List[str]
    skipped_correlation: int = 0      # entries dropped by correlation control
    realized_avg_corr: float = float("nan")  # avg pairwise corr of held names


class PortfolioBacktester:
    def __init__(self,
                 strategy: Strategy,
                 initial_capital: float = 100_000.0,
                 max_positions: int = 10,
                 position_size_pct: float = 0.10,
                 commission_per_trade: float = 1.0,
                 slippage_bps: float = 5.0,
                 # ---- opt-in risk-adjusted upgrades (default OFF) ----
                 trailing_stop: bool = False,
                 score_weighted_sizing: bool = False,
                 risk_lo: float = 0.005,
                 risk_hi: float = 0.015,
                 max_correlation: Optional[float] = None,
                 corr_lookback: int = 60,
                 max_position_pct: float = config.MAX_POSITION_PCT):
        self.strategy = strategy
        self.initial_capital = initial_capital
        self.max_positions = max_positions
        self.position_size_pct = position_size_pct
        self.commission = commission_per_trade
        self.slip = slippage_bps / 10_000.0
        self.trailing_stop = trailing_stop
        self.score_weighted_sizing = score_weighted_sizing
        self.risk_lo = risk_lo
        self.risk_hi = risk_hi
        self.max_correlation = max_correlation
        self.corr_lookback = corr_lookback
        self.max_position_pct = max_position_pct

    # -- helpers ------------------------------------------------------------
    def _buy_price(self, raw: float) -> float:
        return raw * (1.0 + self.slip)

    def _sell_price(self, raw: float) -> float:
        return raw * (1.0 - self.slip)

    def _corr(self, a: _SymbolData, b: _SymbolData, prev, window: int) -> float:
        ra = a.ret.loc[:prev].tail(window)
        rb = b.ret.loc[:prev].tail(window)
        j = pd.concat([ra, rb], axis=1, join="inner").dropna()
        if len(j) < max(20, window // 2):
            return 0.0
        c = j.iloc[:, 0].corr(j.iloc[:, 1])
        return 0.0 if pd.isna(c) else float(c)

    # -- main loop ----------------------------------------------------------
    def run(self, data: Dict[str, pd.DataFrame],
            market_ok: "pd.Series | None" = None,
            spy_returns: "pd.Series | None" = None,
            exposure_multiplier: "pd.Series | None" = None) -> BacktestResult:
        # Binary market-regime gate {date -> bool} (legacy default behaviour).
        regime = None
        if market_ok is not None:
            regime = {pd.Timestamp(d): bool(v) for d, v in market_ok.items()}

        # Graduated regime exposure multiplier {date -> [0,1]} (Feature 4).
        expo = None
        if exposure_multiplier is not None:
            expo = {pd.Timestamp(d): float(v) for d, v in exposure_multiplier.items()}

        # Optional SPY cash overlay.
        spy_ret = None
        if spy_returns is not None:
            spy_ret = {pd.Timestamp(d): float(v) for d, v in spy_returns.items()}

        # Prepare indicators/signals per symbol.
        sym: Dict[str, _SymbolData] = {}
        for t, df in data.items():
            prepared = self.strategy.prepare(df)
            sym[t] = _SymbolData(prepared)

        all_dates = sorted(set().union(*[set(s.dates) for s in sym.values()]))
        all_dates = pd.DatetimeIndex(all_dates)

        cash = self.initial_capital
        positions: Dict[str, Position] = {}
        trades: List[Trade] = []
        eq_dates, eq_vals, inv_vals = [], [], []
        skipped_corr = 0
        div_samples: List[float] = []

        for i in range(1, len(all_dates)):
            today = all_dates[i]
            prev = all_dates[i - 1]

            # ---- 0. SPY overlay: grow idle cash as if parked in SPY -----
            if spy_ret is not None and cash > 0:
                cash *= (1.0 + spy_ret.get(today, 0.0))

            # ---- 1. EXITS (execute at today's open / stop) --------------
            for t in list(positions.keys()):
                p = positions[t]
                sd = sym[t]
                j = sd.pos_of.get(today)
                if j is None:
                    continue  # no bar for this symbol today; hold
                p.bars_held += 1

                # Feature 1: ratchet the trailing stop UP using the last
                # completed bar (prev) — never look-ahead, never loosen.
                if self.trailing_stop and p.initial_stop > 0:
                    pj = sd.pos_of.get(prev)
                    if pj is not None and np.isfinite(sd.atr[pj]):
                        trail = sd.c[pj] - self.strategy.stop_atr_mult * sd.atr[pj]
                        if trail > p.stop_price:
                            p.stop_price = trail

                open_px = sd.o[j]
                low_px = sd.l[j]
                high_px = sd.h[j]
                exit_reason = None
                fill = None

                if p.stop_price > 0 and low_px <= p.stop_price:
                    # Stop takes priority (conservative: assume the bad side
                    # of a day that touched both stop and target).
                    fill = self._sell_price(min(open_px, p.stop_price))
                    exit_reason = "stop"
                elif p.target_price > 0 and high_px >= p.target_price:
                    # Take-profit is a resting limit — filled at target, or at
                    # the open if the bar gapped above it (favourable).
                    fill = max(open_px, p.target_price)
                    exit_reason = "target"
                else:
                    pj = sd.pos_of.get(prev)
                    signalled = pj is not None and sd.exit[pj]
                    timed_out = p.bars_held >= self.strategy.max_hold_days
                    if signalled:
                        fill, exit_reason = self._sell_price(open_px), "signal"
                    elif timed_out:
                        fill, exit_reason = self._sell_price(open_px), "time"

                if exit_reason:
                    cash += fill * p.shares - self.commission
                    trades.append(Trade(
                        symbol=t, strategy=self.strategy.name,
                        entry_date=p.entry_date, entry_price=p.entry_price,
                        exit_date=today, exit_price=fill, shares=p.shares,
                        stop_price=p.stop_price, exit_reason=exit_reason,
                        entry_score=p.entry_score, initial_stop=p.initial_stop))
                    del positions[t]

            # ---- 2. ENTRIES (rank candidates, fill at today's open) -----
            # Graduated exposure multiplier (Feature 4) or binary gate.
            mult = 1.0
            if expo is not None:
                mult = expo.get(prev, 1.0)
            market_healthy = True if regime is None else regime.get(prev, True)

            if market_healthy and mult > 0 and len(positions) < self.max_positions:
                candidates = []
                for t, sd in sym.items():
                    if t in positions:
                        continue
                    pj = sd.pos_of.get(prev)
                    j = sd.pos_of.get(today)
                    if pj is None or j is None:
                        continue
                    if sd.entry[pj] and np.isfinite(sd.o[j]) and sd.o[j] > 0:
                        candidates.append((sd.rank[pj], t))
                candidates.sort(key=lambda x: (np.inf if np.isnan(x[0]) else x[0]))

                # Feature 2: percentile of each candidate's score within the day.
                pct_of = {}
                if self.score_weighted_sizing and candidates:
                    cand_scores = []
                    for _, t in candidates:
                        pj = sym[t].pos_of.get(prev)
                        sc = sym[t].score[pj] if pj is not None else np.nan
                        cand_scores.append(sc)
                    arr = np.array([s if np.isfinite(s) else np.nan
                                    for s in cand_scores])
                    finite = arr[np.isfinite(arr)]
                    n = len(candidates)
                    for k, (_, t) in enumerate(candidates):
                        s = arr[k]
                        if not np.isfinite(s) or len(finite) < 2:
                            pct_of[t] = 0.5
                        else:
                            pct_of[t] = float((finite < s).mean())

                mtm = cash + sum(
                    positions[t].shares * self._last_close(sym[t], today)
                    for t in positions)

                for _, t in candidates:
                    if len(positions) >= self.max_positions:
                        break
                    sd = sym[t]
                    j = sd.pos_of[today]
                    raw_open = sd.o[j]
                    price = self._buy_price(raw_open)
                    atr_val = sd.atr[j]
                    has_stop = (self.strategy.stop_atr_mult > 0 and
                                np.isfinite(atr_val))
                    stop = (raw_open - self.strategy.stop_atr_mult * atr_val
                            if has_stop else 0.0)

                    # Feature 3: correlation control — skip if too correlated
                    # with 2+ held names.
                    if self.max_correlation is not None and positions:
                        high = 0
                        for o in positions:
                            if self._corr(sd, sym[o], prev,
                                          self.corr_lookback) > self.max_correlation:
                                high += 1
                                if high >= 2:
                                    break
                        if high >= 2:
                            skipped_corr += 1
                            continue

                    # ---- position sizing ----
                    if self.score_weighted_sizing and has_stop and stop < raw_open:
                        # risk-based: 0.5%..1.5% by score percentile * regime mult
                        risk_pct = (self.risk_lo +
                                    (self.risk_hi - self.risk_lo) * pct_of.get(t, 0.5))
                        risk_pct *= mult
                        dollar_risk = mtm * risk_pct
                        shares = int(dollar_risk // (price - stop))
                        cap_shares = int((mtm * self.max_position_pct) // price)
                        shares = min(shares, cap_shares)
                    else:
                        target_value = mtm * self.position_size_pct * mult
                        shares = int(target_value // price)

                    cost = shares * price + self.commission
                    if shares <= 0 or cost > cash:
                        continue
                    cash -= cost
                    pj = sd.pos_of.get(prev)
                    entry_score = sd.score[pj] if pj is not None else float("nan")
                    tpr = getattr(self.strategy, "take_profit_r", 0.0)
                    target_price = (price + tpr * (price - stop)
                                    if tpr > 0 and has_stop and stop < price
                                    else 0.0)
                    positions[t] = Position(
                        symbol=t, entry_date=today, entry_price=price,
                        shares=shares, stop_price=stop, initial_stop=stop,
                        entry_score=entry_score, target_price=target_price)

            # ---- 3. MARK TO MARKET at today's close ---------------------
            invested = 0.0
            for t, p in positions.items():
                invested += p.shares * self._last_close(sym[t], today)
            equity = cash + invested
            eq_dates.append(today)
            eq_vals.append(equity)
            inv_vals.append(invested / equity if equity > 0 else 0.0)

            # realized diversification sample (every 10 trading days)
            if len(positions) >= 2 and i % 10 == 0:
                names = list(positions.keys())
                cs = []
                for a in range(len(names)):
                    for b in range(a + 1, len(names)):
                        cs.append(self._corr(sym[names[a]], sym[names[b]],
                                             today, self.corr_lookback))
                if cs:
                    div_samples.append(float(np.mean(cs)))

        equity_series = pd.Series(eq_vals, index=pd.DatetimeIndex(eq_dates),
                                  name="equity")
        invested_series = pd.Series(inv_vals, index=pd.DatetimeIndex(eq_dates),
                                    name="invested_pct")
        return BacktestResult(
            equity=equity_series,
            invested_pct=invested_series,
            trades=trades,
            initial_capital=self.initial_capital,
            strategy_name=self.strategy.name,
            universe=list(data.keys()),
            skipped_correlation=skipped_corr,
            realized_avg_corr=(float(np.mean(div_samples))
                               if div_samples else float("nan")),
        )

    @staticmethod
    def _last_close(sd: _SymbolData, day: pd.Timestamp) -> float:
        """Close for `day`; if the symbol has no bar that day, use the last
        available close up to that day (carry the mark forward)."""
        j = sd.pos_of.get(day)
        if j is not None and np.isfinite(sd.c[j]):
            return sd.c[j]
        idx = sd.dates.searchsorted(day, side="right") - 1
        if 0 <= idx < len(sd.c):
            return sd.c[idx]
        return 0.0

"""
Strategy framework + three proven, well-documented strategies.

Each strategy's `prepare(df)` returns the price frame augmented with the
columns the engine needs:

    entry   : bool  - a long-entry signal is present at this bar's close
    exit    : bool  - a long-exit signal is present at this bar's close
    rank    : float - priority when capital is limited (LOWER = take first)
    atr     : float - ATR(14), used by the engine to place a protective stop

The engine reads a signal at bar t's close and executes at bar t+1's open, so
there is no look-ahead bias.

Strategies
----------
1. RSI2  - Connors-style RSI(2) mean reversion. Buy quality names that are
   deeply oversold *inside an uptrend*, sell the bounce. Historically a very
   high win rate (bounded upside, quick exits).
2. Bollinger - buy a close below the lower band in an uptrend, exit at the mid
   band. Another high-win-rate mean-reversion approach.
3. SMACross - 50/200 trend following. Lower win rate but rides big trends;
   included as an honest comparison baseline.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from backtest import indicators as ind
from backtest import analysis as ta


class Strategy:
    name: str = "base"
    # sensible defaults; overridden per strategy
    max_hold_days: int = 10
    stop_atr_mult: float = 3.0   # protective stop = entry - mult * ATR (0 = none)
    take_profit_r: float = 0.0   # take-profit at N x initial risk (0 = off)

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError


# ---------------------------------------------------------------------------
@dataclass
class RSI2(Strategy):
    trend_period: int = 200
    exit_sma: int = 5
    rsi_period: int = 2
    rsi_entry: float = 10.0        # deeply oversold
    rsi_exit: float = 65.0
    max_hold_days: int = 10
    stop_atr_mult: float = 3.0
    min_dollar_volume: float = 1e7  # liquidity filter: >= $10M/day avg (20d)
    min_down_days: int = 2          # require a genuine multi-day pullback
    min_score: float = 0.0          # confluence-score gate (0 = off)
    rank_by: str = "score"          # "score" (quality) or "rsi" (most oversold)
    name: str = "RSI2"

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        close = out["Close"]
        out["trend"] = ind.sma(close, self.trend_period)
        out["exit_ma"] = ind.sma(close, self.exit_sma)
        out["rsi"] = ind.rsi(close, self.rsi_period)
        out["atr"] = ind.atr(out["High"], out["Low"], close, 14)
        # Full multi-indicator confluence score (0-100) — see analysis.py.
        out["score"] = ta.quality_score(out)

        # --- proven win-rate filters ------------------------------------
        # (1) liquidity: only trade names with real average dollar volume.
        dollar_vol = (close * out["Volume"]).rolling(20, min_periods=20).mean()
        liquid = dollar_vol >= self.min_dollar_volume
        # (2) multi-day pullback: N consecutive lower closes (Connors idea).
        down = close < close.shift(1)
        down_streak = down
        for k in range(1, self.min_down_days):
            down_streak = down_streak & down.shift(k).fillna(False)
        pullback = down_streak if self.min_down_days > 0 else True
        # (3) optional confluence gate.
        score_ok = out["score"] >= self.min_score if self.min_score > 0 else True

        out["entry"] = ((close > out["trend"]) &
                        (out["rsi"] < self.rsi_entry) &
                        liquid & pullback & score_ok)
        # Exit the bounce: back above the short MA, or RSI recovered.
        out["exit"] = (close > out["exit_ma"]) | (out["rsi"] > self.rsi_exit)
        # Ranking when capital is scarce: by confluence score (best context
        # first) or by most-oversold. Lower rank value = taken first.
        out["rank"] = -out["score"] if self.rank_by == "score" else out["rsi"]
        return out


# ---------------------------------------------------------------------------
@dataclass
class Bollinger(Strategy):
    trend_period: int = 200
    bb_period: int = 20
    bb_std: float = 2.0
    max_hold_days: int = 10
    stop_atr_mult: float = 3.0
    name: str = "Bollinger"

    min_dollar_volume: float = 1e7

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        close = out["Close"]
        mid, upper, lower = ind.bollinger(close, self.bb_period, self.bb_std)
        out["trend"] = ind.sma(close, self.trend_period)
        out["bb_mid"], out["bb_low"] = mid, lower
        out["atr"] = ind.atr(out["High"], out["Low"], close, 14)
        dollar_vol = (close * out["Volume"]).rolling(20, min_periods=20).mean()
        liquid = dollar_vol >= self.min_dollar_volume

        out["entry"] = (close > out["trend"]) & (close < lower) & liquid
        out["exit"] = close >= mid
        # More stretched below the band = higher priority.
        std = (mid - lower) / self.bb_std
        out["rank"] = (close - mid) / std.replace(0.0, np.nan)
        return out


# ---------------------------------------------------------------------------
@dataclass
class SMACross(Strategy):
    fast: int = 50
    slow: int = 200
    max_hold_days: int = 400     # trend trades can run for many months
    stop_atr_mult: float = 0.0   # no hard stop; exit is the cross-down
    name: str = "SMACross"

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        close = out["Close"]
        fast = ind.sma(close, self.fast)
        slow = ind.sma(close, self.slow)
        out["atr"] = ind.atr(out["High"], out["Low"], close, 14)

        above = fast > slow
        out["entry"] = above & (~above.shift(1).fillna(False))   # golden cross
        out["exit"] = (~above) & (above.shift(1).fillna(False))   # death cross
        out["rank"] = -(fast / slow)   # strongest trend first
        return out


# ---------------------------------------------------------------------------
@dataclass
class TrendPullback(Strategy):
    """
    Hybrid: buy shallow pullbacks in *strong-uptrend leaders*, sell the bounce.

    This deliberately combines the two edges we found in earlier tests:
      * trend following's *direction* (only trade names in confirmed uptrends
        with positive 6-month momentum), and
      * mean reversion's *timing* (enter on a short-term oversold dip).

    The thesis: dips in leaders resolve upward more reliably than dips in the
    average stock, so this should lift win rate AND returns versus plain RSI-2
    on the full universe. Whether it actually does is proven by the backtest.
    """
    trend_period: int = 200
    align_fast: int = 50            # require SMA50 > SMA200 (uptrend structure)
    mom_period: int = 126           # ~6-month momentum must be positive
    rsi_period: int = 4             # slightly slower RSI than the pure MR RSI(2)
    rsi_entry: float = 25.0         # a shallow pullback, not a crash
    rsi_exit: float = 55.0
    exit_sma: int = 10
    max_hold_days: int = 12
    stop_atr_mult: float = 2.5
    min_dollar_volume: float = 1e7
    min_score: float = 0.0
    rank_by: str = "score"
    # Feature 5 (opt-in): only take the pullback if 14-day ATR% is below this
    # fraction of its own 20-day average ATR% (i.e. volatility is CONTRACTING).
    # 0.0 = filter disabled (default). 0.90 = require ATR% < 90% of its 20d avg.
    vol_contract_max: float = 0.0
    name: str = "TrendPullback"

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        close = out["Close"]
        sma_slow = ind.sma(close, self.trend_period)
        sma_fast = ind.sma(close, self.align_fast)
        out["trend"] = sma_slow
        out["exit_ma"] = ind.sma(close, self.exit_sma)
        out["rsi"] = ind.rsi(close, self.rsi_period)
        out["atr"] = ind.atr(out["High"], out["Low"], close, 14)
        out["score"] = ta.quality_score(out)
        mom = ind.roc(close, self.mom_period)
        dollar_vol = (close * out["Volume"]).rolling(20, min_periods=20).mean()

        leader = (close > sma_slow) & (sma_fast > sma_slow) & (mom > 0)
        liquid = dollar_vol >= self.min_dollar_volume
        dip = out["rsi"] < self.rsi_entry
        score_ok = out["score"] >= self.min_score if self.min_score > 0 else True

        # Feature 5: volatility-contraction filter (opt-in).
        if self.vol_contract_max > 0:
            atr_pct = out["atr"] / close
            atr_pct_avg = atr_pct.rolling(20, min_periods=20).mean()
            contracting = atr_pct < (self.vol_contract_max * atr_pct_avg)
        else:
            contracting = True

        out["entry"] = leader & liquid & dip & score_ok & contracting
        out["exit"] = (close > out["exit_ma"]) | (out["rsi"] > self.rsi_exit)
        out["rank"] = -out["score"] if self.rank_by == "score" else out["rsi"]
        return out


# ---------------------------------------------------------------------------
@dataclass
class DonchianBreakout(Strategy):
    """
    v9 momentum-sprint: buy an N-bar breakout with a volume surge, only in an
    uptrend and only when a real trend exists (ADX). Exit fast via an
    ATR/Chandelier trail + a take-profit + a short time stop. Designed for
    2-4 day holds and enough daily signals to fill many concurrent slots.

    Indicator roles (each justified, not stacked blindly):
      * Donchian(N) breakout  = the entry trigger (price makes a new N-bar high)
      * RVOL >= 1.3           = volume confirmation (avoid low-conviction pokes)
      * close > SMA200        = long-only trend gate
      * ADX(14) > adx_min     = only trending names (Supertrend/breakouts whipsaw
                                in chop without this)
      * liquidity floor       = executable in paper trading
    """
    breakout_n: int = 20
    exit_n: int = 10
    trend_period: int = 200
    adx_min: float = 20.0
    rvol_min: float = 1.3
    max_hold_days: int = 6
    stop_atr_mult: float = 2.5
    take_profit_r: float = 2.5
    min_dollar_volume: float = 1e7
    name: str = "DonchianBreakout"

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        close, high, low, vol = out["Close"], out["High"], out["Low"], out["Volume"]
        out["trend"] = ind.sma(close, self.trend_period)
        out["atr"] = ind.atr(high, low, close, 14)
        out["score"] = ta.quality_score(out)
        dhigh = ind.donchian_high(high, self.breakout_n)
        dlow = ind.donchian_low(low, self.exit_n)
        rv = ind.rvol(vol, 20)
        adx_, _, _ = ind.adx(high, low, close, 14)
        dollar_vol = (close * vol).rolling(20, min_periods=20).mean()
        liquid = dollar_vol >= self.min_dollar_volume

        out["entry"] = ((close > dhigh) & (rv >= self.rvol_min) &
                        (close > out["trend"]) & (adx_ > self.adx_min) & liquid)
        # Fallback discretionary exit (trail/TP/time usually fire first).
        out["exit"] = close < dlow
        out["rank"] = -rv                      # strongest volume breakout first
        return out


STRATEGIES = {
    "rsi2": RSI2,
    "bollinger": Bollinger,
    "smacross": SMACross,
    "trendpullback": TrendPullback,
    "donchian": DonchianBreakout,
}


def build_strategy(name: str, **kwargs) -> Strategy:
    key = name.lower()
    if key not in STRATEGIES:
        raise ValueError(f"Unknown strategy '{name}'. "
                         f"Choose from {list(STRATEGIES)}.")
    return STRATEGIES[key](**kwargs)

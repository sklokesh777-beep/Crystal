"""
Earnings + news awareness (LIVE / current-decision use).

These functions pull *current* information from yfinance to support real-time
trade decisions in the paper-trading assignment:

  * next_earnings_date / in_earnings_blackout - avoid holding a swing position
    into an earnings report (a coin-flip gap risk).
  * recent_earnings_surprises - see how a name has reacted historically.
  * get_news - latest headlines + a naive keyword sentiment tag.

HONESTY NOTE
------------
This is for LIVE decisions, not historical backtesting. Reliable, point-in-time
news sentiment and exact earnings dates for 500 names across 15 years are NOT
available for free, so they are deliberately **excluded from the backtest** to
avoid look-ahead bias / fabricated results. Using them live (to skip earnings
and read the news) is exactly how a disciplined trader would operate.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import List, Optional

import pandas as pd


# --- Earnings --------------------------------------------------------------
def _earnings_frame(ticker: str, limit: int = 16) -> Optional[pd.DataFrame]:
    try:
        import yfinance as yf
        ed = yf.Ticker(ticker).get_earnings_dates(limit=limit)
    except Exception:
        return None
    if ed is None or len(ed) == 0:
        return None
    # index is tz-aware Timestamps
    ed = ed.copy()
    ed.index = pd.to_datetime(ed.index, utc=True)
    return ed


def next_earnings_date(ticker: str,
                       as_of: Optional[date] = None) -> Optional[date]:
    """Next scheduled earnings date on/after `as_of` (today if None)."""
    ed = _earnings_frame(ticker)
    if ed is None:
        return None
    as_of = as_of or date.today()
    cutoff = pd.Timestamp(as_of, tz="UTC")
    future = ed.index[ed.index >= cutoff]
    if len(future) == 0:
        return None
    return future.min().date()


def days_to_earnings(ticker: str,
                     as_of: Optional[date] = None) -> Optional[int]:
    nxt = next_earnings_date(ticker, as_of)
    if nxt is None:
        return None
    return (nxt - (as_of or date.today())).days


def in_earnings_blackout(ticker: str,
                         as_of: Optional[date] = None,
                         window_days: int = 5) -> bool:
    """True if earnings fall within `window_days` ahead — i.e. avoid new swings."""
    d = days_to_earnings(ticker, as_of)
    return d is not None and 0 <= d <= window_days


def recent_earnings_surprises(ticker: str, n: int = 4) -> List[dict]:
    ed = _earnings_frame(ticker)
    if ed is None:
        return []
    past = ed[ed.index <= pd.Timestamp.now(tz="UTC")].sort_index(ascending=False)
    out = []
    for ts, row in past.head(n).iterrows():
        out.append({
            "date": ts.date().isoformat(),
            "eps_estimate": row.get("EPS Estimate"),
            "reported_eps": row.get("Reported EPS"),
            "surprise_pct": row.get("Surprise(%)"),
        })
    return out


# --- News ------------------------------------------------------------------
_POS = {"beat", "beats", "surge", "surges", "jumps", "soars", "record",
        "upgrade", "upgraded", "raises", "strong", "growth", "wins", "rally",
        "outperform", "buy", "tops", "gains", "bullish", "boost"}
_NEG = {"miss", "misses", "falls", "plunges", "drops", "cuts", "downgrade",
        "downgraded", "lawsuit", "probe", "recall", "weak", "warns", "warning",
        "slump", "loss", "bearish", "sinks", "halts", "delays", "fraud"}


@dataclass
class NewsItem:
    title: str
    publisher: str
    published: str
    url: str
    sentiment: str   # "positive" / "negative" / "neutral"


def _tag_sentiment(title: str) -> str:
    words = {w.strip(".,!?:;'\"").lower() for w in title.split()}
    pos = len(words & _POS)
    neg = len(words & _NEG)
    if pos > neg:
        return "positive"
    if neg > pos:
        return "negative"
    return "neutral"


def get_news(ticker: str, max_items: int = 5) -> List[NewsItem]:
    """Latest headlines for a ticker with a naive keyword sentiment tag."""
    try:
        import yfinance as yf
        raw = yf.Ticker(ticker).news or []
    except Exception:
        return []
    items: List[NewsItem] = []
    for it in raw[:max_items]:
        c = it.get("content", it) or {}
        title = c.get("title") or ""
        if not title:
            continue
        provider = (c.get("provider") or {}).get("displayName", "") \
            if isinstance(c.get("provider"), dict) else ""
        pub = c.get("pubDate") or c.get("displayTime") or ""
        url = ""
        for k in ("canonicalUrl", "clickThroughUrl"):
            v = c.get(k)
            if isinstance(v, dict) and v.get("url"):
                url = v["url"]
                break
        items.append(NewsItem(
            title=title, publisher=provider, published=str(pub)[:10],
            url=url, sentiment=_tag_sentiment(title)))
    return items


def news_sentiment_score(ticker: str, max_items: int = 8) -> float:
    """Net sentiment across recent headlines in [-1, 1]. 0 if none/unknown."""
    items = get_news(ticker, max_items)
    if not items:
        return 0.0
    score = sum(1 if i.sentiment == "positive" else
                -1 if i.sentiment == "negative" else 0 for i in items)
    return score / len(items)

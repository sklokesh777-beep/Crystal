# Paper Trading Analytics

A trade-journaling and performance-analytics tool for a **US-market swing /
overnight paper-trading assignment** ($100,000 simulated capital, ≥60 trades,
executed in **TradingView Paper Trading**).

You place trades in TradingView, log them in a CSV, and this tool produces the
full performance picture your instructor wants: position sizing from a 1%-risk
rule, win rate, profit factor, expectancy, R-multiples, max drawdown, Sharpe /
Sortino, an SPY benchmark comparison, charts, and a ready-to-paste Markdown
report.

---

## Why this fits the assignment

| Requirement | How the tool supports it |
|---|---|
| $100,000 capital | `STARTING_CAPITAL` in `config.py` |
| ≥ 60 trades | journal + sample dataset of 60 trades |
| Swing (2–14 days) + overnight | per-trade holding period is computed and shown |
| Avoid losses / risk control | 1%-risk position sizing, stops, R-multiples, drawdown |
| Impress with strategy | 5 documented strategy "sleeves" + per-sleeve breakdown |
| Beat the market | SPY buy-and-hold benchmark + alpha |

---

## Setup

```bash
# from the project root
python3.11 -m venv .venv          # any Python 3.10+ works
source .venv/bin/activate         # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

---

## Usage

### 1. Size a trade before you take it (1% risk rule)

```bash
python main.py size --ticker NVDA --dir LONG --entry 168 --stop 162 --target 184
```

Outputs the share count that risks exactly 1% of capital, the notional
exposure, the reward:risk ratio, and a warning if the position breaches the
10%-of-capital cap.

### 2. Create your own blank journal

```bash
python main.py template --out data/my_trades.csv
```

Fill one row per **closed** trade. Columns:

```
trade_id, ticker, sleeve, direction, entry_date, entry_price, stop_price,
target_price, quantity, exit_date, exit_price, commission, catalyst,
exit_reason, notes
```

- `sleeve` is one of: `A_EARNINGS`, `B_REL_STRENGTH`, `C_MEAN_REVERSION`,
  `D_PAIRS`, `E_OVERNIGHT` (defined in `config.py`).
- `direction` is `LONG` or `SHORT`.
- dates accept `YYYY-MM-DD` (and a few common variants).

### 3. Run the full analytics + report

```bash
python main.py report --file data/my_trades.csv
```

(Omit `--file` to run the built-in 60-trade sample.) This prints a console
summary and writes to `output/`:

- `report.md` — full Markdown report (headline results, metric tables,
  per-sleeve and long/short breakdowns, charts, and the complete trade log)
- `equity_curve.png`, `drawdown.png`, `sleeve_pnl.png`,
  `r_distribution.png`, `cumulative_r.png`

Flags: `--no-benchmark` (skip SPY fetch), `--no-charts` (skip images).

---

## The 5 strategy sleeves

| Sleeve | Strategy | Capital |
|---|---|---|
| A | Post-earnings drift swing | $25k |
| B | Relative strength / sector rotation | $25k |
| C | Mean reversion (RSI-2 oversold) | $15k |
| D | Market-neutral pairs (long + short) | $20k |
| E | Overnight momentum ("buy today, sell tomorrow") | $15k |

Edit allocations, risk %, benchmark, and the risk-free rate in `config.py`.

---

## Workflow with TradingView

1. Connect the **Paper Trading** broker in TradingView; set the starting
   balance to $100,000 and a realistic commission.
2. Use bracket orders (drag Take-Profit / Stop-Loss onto the chart) so exits
   are automatic.
3. When a trade closes, copy its details into your CSV (one row per trade).
4. Run `python main.py report --file data/my_trades.csv`.
5. Paste `output/report.md` and the charts into your write-up.

---

## Regenerating the sample data

```bash
python scripts/make_sample_data.py    # rewrites data/sample_trades.csv
```

---

## Methodology notes (for the write-up)

- **Position size** = `(capital × risk%) ÷ |entry − stop|`, capped so no single
  name exceeds 10% of capital.
- **R-multiple** = realised P/L ÷ initial planned risk (1R = the amount risked).
- **Equity curve** books realised P/L on each trade's exit date over a
  business-day calendar.
- **Sharpe / Sortino** use daily returns annualised by √252 with a configurable
  risk-free rate. Over a ~2-week sample these annualised figures are shown for
  completeness but are **not statistically robust** — lead with period return,
  win rate, profit factor, expectancy, and Return/Max-Drawdown.
- **Benchmark**: SPY buy-and-hold over the same window (live via `yfinance`,
  with a manual-price fallback in `config.py` when offline).

*This tool is for an educational paper-trading simulation. It is not investment
advice.*



---

# Part 2 — Advanced Backtesting Engine

A second, standalone tool (`run_backtest.py` + the `backtest/` package) that
pulls **10–15 years of real US market data** (via yfinance) and backtests
proven swing-trading strategies across a basket of liquid large-caps, with an
SPY buy-and-hold benchmark. Use it to *justify* the strategies you run in the
paper-trading assignment.

## Quick start

```bash
source .venv/bin/activate          # same venv as Part 1
python run_backtest.py             # default: RSI-2 mean reversion, ~15 years

# compare all three strategies side by side (+ overlay chart)
python run_backtest.py --compare --start 2010-01-01 --end 2024-12-31

# pick a strategy / window / knobs
python run_backtest.py --strategy smacross --start 2010-01-01 --end 2024-12-31
python run_backtest.py --strategy rsi2 --rsi-entry 15 --max-positions 6 --position-size 0.16
python run_backtest.py --tickers AAPL MSFT NVDA JPM XOM SPY QQQ
```

Outputs go to `output/backtest/`: `report.md`, `trades.csv`, and charts
(equity curve vs SPY, drawdown, calendar-year returns, trade-P/L distribution,
and a `comparison.png` in `--compare` mode).

## The three strategies

| Key | Strategy | Style | Best for |
|---|---|---|---|
| `rsi2` | Connors RSI-2 mean reversion | Buy deep oversold in an uptrend, sell the bounce | **High win rate + many trades + low drawdown** — ideal for the 2-week / 60-trade assignment |
| `bollinger` | Lower-band mean reversion | Buy below lower Bollinger band, exit at mid | Alternative mean reversion |
| `smacross` | 50/200 golden-cross trend following | Ride long trends | **Highest long-term profit**, beat the market historically, but bigger drawdowns and few trades |

## What the 2010–2024 backtest showed (real data)

| Strategy | Win rate | CAGR | vs SPY | Max DD | Profit factor | Trades |
|---|---|---|---|---|---|---|
| RSI-2 | 66% | +5.1% | −8.5% | **−13.7%** | 1.28 | 2,947 |
| Bollinger | 62% | +3.7% | −10.0% | −17.7% | 1.32 | 1,128 |
| SMA trend | **71%** | **+23.4%** | **+9.7%** | −28.1% | **8.15** | 125 |
| SPY buy & hold | — | +13.7% | — | −33.7% | — | — |

**Takeaways (defensible in your write-up):**
- **Mean reversion (RSI-2)** delivers a high win rate and roughly **one-third the drawdown of the market** — great risk control, and it produces the many swing trades the assignment needs. It lags buy-and-hold on total return mainly because it sits in cash much of the time (low exposure).
- **Trend following (SMA cross)** *beat* the market with a 71% win rate and a profit factor of 8 — but with larger drawdowns and only ~8 trades/year (a long-horizon strategy, not a 2-week sprint).

## Important honesty caveats (in the report too)

- **Survivorship bias:** the default universe is *today's* winners (NVDA, AAPL…), which inflates historical results. A fully rigorous test would use point-in-time index membership.
- **Regime:** 2010–2024 was an exceptional bull market; trend following looks unusually strong in it.
- **Past performance does not guarantee future results.** This is an educational backtest, not investment advice.

## How the engine avoids common backtest traps

- **No look-ahead:** signals are read at each bar's *close* and filled at the *next* bar's open.
- **Realistic frictions:** commission + slippage on every fill.
- **Bounded risk:** ATR-based protective stop + max-holding time stop on every trade.
- **Capital limits:** max concurrent positions and a fixed fraction of equity per position.



---

# Part 3 — Upgrades: 500-stock universe, factor filters, earnings/news & live scanner

This round added serious depth. Everything runs on **real data through 2026-07-15**.

## New capabilities

1. **~500-stock S&P 500 universe** (`--sp500`) — auto-fetched from Wikipedia and cached (`backtest/universe.py`).
2. **Proven win-rate filters** (backtestable, no look-ahead):
   - **Market-regime gate** — only take long mean-reversion entries when SPY is above its 200-day SMA.
   - **Liquidity filter** — skip names below ~$10M/day average dollar volume.
   - **Multi-day oversold confirmation** — require consecutive down days (a genuine pullback, not one red bar).
3. **Earnings + news awareness** (`backtest/fundamentals.py`) — next-earnings date, an earnings blackout, recent surprise history, and latest headlines with a simple sentiment tag.
4. **Live daily scanner** (`scan_live.py`) — the tool you actually run each morning:
   ```bash
   python scan_live.py --sp500 --top 15 --earnings-window 5
   ```
   Pulls the latest data, computes today's signals, shows the market regime, **sizes each trade at 1% risk**, flags names reporting earnings soon, attaches news, and saves a ranked watchlist to `output/live/`.

## What the 2010–2026 backtests actually showed (real data)

**Curated 26 quality large-caps:**

| Strategy | Win rate | CAGR | vs SPY | Max DD | Profit factor |
|---|---|---|---|---|---|
| RSI-2 mean reversion | **66%** | +4.4% | −9.7% | **−14.7%** | 1.30 |
| Bollinger | 61% | +3.1% | −11.0% | −11.4% | 1.31 |
| SMA trend | 65% | **+20.5%** | **+6.3%** | −28.4% | 4.91 |

**Full S&P 500 (~500 names):**

| Strategy | Win rate | CAGR | vs SPY | Max DD | Profit factor |
|---|---|---|---|---|---|
| RSI-2 mean reversion | 62% | +1.3% | −12.8% | −28.8% | 1.04 |
| Bollinger | 57% | +6.8% | −7.3% | −24.5% | 1.15 |
| SMA trend | 51% | **+34.3%** | **+20.2%** | −43.4% | 6.60 |
| **SPY buy & hold** | — | +14.1% | — | −33.7% | — |

## The honest conclusions (this is the real value — put it in your write-up)

1. **High win rate and high profit pull in opposite directions.** Mean reversion (RSI-2) gave the *highest win rate* (62–66%) but the *lowest profit*. Trend following gave the *highest profit* (beat the market by +20% CAGR) but a *lower win rate* and much deeper drawdowns. You cannot maximise both at once — you choose which you value.
2. **A bigger universe did NOT help.** Expanding from 26 quality names to all 500 produced *more* trades but *lower quality* ones — RSI-2's profit factor fell to ~1.0 (barely break-even). **Quality of universe beats quantity.**
3. **"No losses" is not achievable.** Every strategy had losing trades and real drawdowns. What you *can* engineer is *smaller* drawdowns: the filtered RSI-2 kept its worst drop to −14.7% versus the market's −33.7%. That "lose less, recover faster" story is the honest, gradeable win.
4. **For your 2-week / 60-trade assignment:** use **RSI-2 mean reversion on a curated basket of liquid large-caps** — it delivers the high win rate, the many swing signals, and the low drawdown the assignment rewards. Use `scan_live.py` daily to pick the setups, and skip anything reporting earnings inside your holding window.

## Honesty about news/earnings (important for your defense)

News and earnings are used **live only**, to inform *current* decisions — they are deliberately **excluded from the 15-year backtest**. Reliable point-in-time news sentiment and exact earnings dates for 500 names over 15 years are not freely available; faking them would introduce look-ahead bias and produce dishonest results. Being explicit about this boundary is exactly what a rigorous analyst does.

## New commands summary

```bash
# 500-stock backtest, full window
python run_backtest.py --sp500 --start 2010-01-01 --end 2026-07-15

# compare all strategies on the S&P 500
python run_backtest.py --sp500 --compare --start 2010-01-01 --end 2026-07-15

# turn the market-regime filter off (to see its effect)
python run_backtest.py --sp500 --no-regime

# live scanner with earnings + news
python scan_live.py --sp500 --top 15 --skip-earnings
```

*All results are educational backtests on today's index membership (survivorship-biased) during an exceptional bull market. Past performance does not guarantee future results. Not investment advice.*



---

# Part 4 — Full indicator suite, confluence scoring & chart analysis

Added a complete technical-indicator layer and, critically, a **test of whether
it actually helps** (rather than assuming more indicators = more accuracy).

## Indicators added (`backtest/indicators.py`)

SMA, EMA, RSI (Wilder), ATR (Wilder), Bollinger Bands + **%B**, **MACD**
(line/signal/histogram), **ADX with +DI/-DI** (Wilder), **Stochastic** (%K/%D),
**OBV**, **ROC / momentum** (3m & 6m), and SMA slope.

## Confluence quality score (`backtest/analysis.py`)

A single 0–100 score blends many indicators into one "how healthy is the setup"
number: long-term trend (price vs SMA200), trend alignment (SMA50 vs SMA200),
3-month momentum, MACD histogram, ADX trend strength, volume participation,
50-SMA slope, and an over-extension penalty. It's the one source of truth used
by both the scanner and the backtest.

## Chart analysis for any ticker (`analyze_ticker.py`)

```bash
python analyze_ticker.py AAPL NVDA JPM
```
Prints a written technical read (trend label, RSI, MACD, ADX, stochastic, %B,
momentum, confluence score) and saves a **5-panel annotated chart** (price +
SMA20/50/200 + Bollinger, volume, RSI, MACD, ADX) to `output/analysis/`.

## The honest validation — does the score improve win rate?

I ranked all 8,319 S&P 500 mean-reversion trades by their entry confluence
score and measured the win rate in each bucket:

| Score bucket | Trades | Win rate |
|---|---|---|
| 40–54 | 626 | 62.1% |
| 55–69 | 3,531 | 62.9% |
| 70–84 | 3,714 | 62.7% |
| 85–100 | 427 | 61.4% |

**Finding (this is the valuable, honest part):**
- **The multi-indicator score did NOT raise the per-trade win rate** — it's flat
  at ~62% across every bucket, and the highest-scoring trades actually won
  slightly *less*. So "add more indicators to boost accuracy" **did not hold up**
  in testing. This is a well-known reality: stacking indicators mostly adds
  correlated noise, not edge.
- **But** using the score to decide *which* signals to prioritise when capital
  is limited lifted CAGR from ~1.3% to ~4.8% (same win rate, better selection).
  So the indicators help *allocation*, not *hit-rate*.

The tool now **proves this to you with data** instead of assuming it. Being able
to show your professor "I tested whether more indicators helped, and here's the
evidence that they didn't move win rate" is far more impressive than a black box
that claims a magic edge.

## Live scanner now shows the score

`scan_live.py` ranks candidates by confluence score and displays it alongside
RSI-2, price, ATR stop, position size, earnings countdown, and news.

*Reminder: indicators describe the past and present; they don't guarantee the
future. Educational use only — not investment advice.*



---

# Part 5 — FINAL: S&P 500 default, hybrid strategy, cash overlay & out-of-sample

This is the definitive version. Defaults now run the **full S&P 500** over
**2010 → today** on real data.

## What changed

- **Default universe is the full S&P 500** (`run_backtest.py` with no flags).
  Use `--curated` for the small quality basket.
- **New hybrid strategy `trendpullback`** (now the default) — buys shallow
  pullbacks *only in strong-uptrend leaders* (price > SMA200, SMA50 > SMA200,
  positive 6-month momentum). Combines trend direction with mean-reversion
  timing.
- **`--spy-overlay`** — parks idle cash in SPY to remove "cash drag."
- **`--oos-split DATE`** — reports in-sample vs out-of-sample sub-periods to
  test whether the edge is consistent across regimes.

## Final results — full S&P 500, 2010–2026 (real data)

| Strategy | Win rate | CAGR | vs SPY | Max DD | Profit factor | Trades |
|---|---|---|---|---|---|---|
| RSI-2 | 63% | +5.3% | −8.9% | −26.5% | 1.10 | 8,320 |
| Bollinger | 57% | +6.7% | −7.4% | −24.5% | 1.15 | 3,683 |
| **TrendPullback** (hybrid) | **64%** | +5.5% | −8.7% | −34.0% | 1.09 | 5,797 |
| SMA trend | 51% | **+34.1%** | **+19.9%** | −43.4% | **6.60** | 140 |
| **SPY buy & hold** | — | +14.1% | — | −33.7% | — | — |

**With `--spy-overlay` (idle cash parked in SPY):** mean-reversion CAGRs roughly
doubled (RSI-2 5.3%→10.4%, Bollinger 6.7%→12.5%, TrendPullback 5.5%→9.6%) — but
max drawdowns deepened to ~−39% (idle cash is now exposed to crashes too). A
genuine return-for-risk trade-off.

**Out-of-sample (TrendPullback, split 2019-01-01):**

| Sub-period | Return | CAGR | Win rate | Max DD |
|---|---|---|---|---|
| In-sample 2010–2018 | +80.3% | +6.8% | 65.0% | −14.8% |
| Out-of-sample 2019–2026 | +30.7% | +3.6% | 63.6% | −34.5% |

The **win rate stayed consistent (65% → 64%)** out of sample — the hit-rate edge
is robust — but returns and drawdown were regime-dependent (2020/2022 bears).

## The definitive, honest conclusions

1. **New hybrid raised the win rate to the highest of all (64%)** and is
   consistent out of sample — but it still didn't beat buy-and-hold on return.
2. **Over 2010–2026, no high-win-rate mean-reversion approach beat SPY** on
   total return, even with the cash overlay. Only **trend following** beat the
   market (+34% CAGR) — at a 51% win rate and a −43% drawdown.
3. **The win-rate ↔ profit trade-off is real and unavoidable.** You optimise for
   one at the expense of the other. High win rate = mean reversion; high profit =
   trend following.
4. **The confluence indicator score does not improve win rate** (flat ~64% across
   score buckets) — it only helps *selection* when capital is limited.
5. **For your paper-trading assignment (2 weeks, ≥60 trades):** `trendpullback`
   or `rsi2` are ideal — 63–64% win rate, many signals, and (with the regime
   filter + curated names) shallow drawdowns. Long-horizon CAGR lagging SPY is a
   cash-drag/bull-market artifact and is irrelevant to an actively-deployed
   two-week sprint. Use `scan_live.py` daily and skip earnings within your window.

## Final command cheat-sheet

```bash
python run_backtest.py                              # S&P 500, TrendPullback, 15yr
python run_backtest.py --compare                    # all 4 strategies on the 500
python run_backtest.py --compare --spy-overlay      # + idle cash parked in SPY
python run_backtest.py --strategy trendpullback --oos-split 2019-01-01
python scan_live.py --sp500 --top 15 --skip-earnings
python analyze_ticker.py AAPL NVDA JPM
```

*Educational backtests on today's (survivorship-biased) index membership during
an exceptional bull market. Past performance does not guarantee future results.
Not investment advice.*



---

# Part 6 — Trade Calculator (`trade_calc.py`)

Turns a trade idea into exact, risk-controlled order parameters. Two modes.

## Manual mode — you supply the numbers

```bash
python trade_calc.py --entry 232.50 --stop 226 --target 245
python trade_calc.py --entry 100 --stop 96 --rr 2.5      # target derived from R:R
python trade_calc.py --entry 118 --stop 122 --rr 2.5     # SHORT (stop above entry)
```

## Auto / live mode — give it a ticker

Pulls the latest price and ATR(14) from the model, derives an **ATR-based stop**
and an **R-based target**, and prints the full technical read (trend, RSI, MACD,
ADX, confluence score) plus the next earnings date:

```bash
python trade_calc.py --ticker AAPL
python trade_calc.py --ticker XOM --direction short --rr 2.5 --atr-mult 2.5
```

## What it outputs

- **Shares to buy/short** — sized so the stop-loss risks exactly 1% of capital
  (`--risk`), capped at 10% of capital per name (`--max-position`).
- **Entry, stop, target** with the % move to each.
- **Max loss** if the stop hits ($ and % of capital) and the resulting account value.
- **Reward:risk ratio** and a warning if it's below 2:1.
- **Profit at target** ($, % of capital, % on the position) and the resulting account value.
- **Breakeven price** (covers round-trip commission).
- An **R-multiple table** (1R / 2R / 3R / your target) with the price and profit at each.

## Key options

```
--capital 100000     account size (default from config.py)
--risk 0.01          fraction of capital risked per trade (1%)
--rr 2.0             reward:risk used to derive the target
--atr-mult 2.5       auto mode: stop = entry -/+ atr_mult * ATR(14)
--commission 1       per-side commission ($)
--max-position 0.10  cap on any single position
--shares 50          override the calculated share count
--direction short    for short trades (manual mode also infers SHORT if stop>entry)
```

*Educational tool. Position sizing and stops manage risk; they don't guarantee
outcomes. Not investment advice.*



---

# Part 7 — Risk-adjusted upgrades (honest before/after)

Seven upgrades were added, **all opt-in via flags (defaults unchanged)**. Each was
validated by rerunning the *real* backtest on the full S&P 500 (2010→2026-07-15,
TrendPullback). As in Parts 1–6, what did **not** work is reported as plainly as
what did.

**Baseline (TrendPullback, S&P 500, no flags):**
CAGR **+5.33%**, win **64.4%**, PF **1.09**, avg win **$484** / avg loss **$801**,
max drawdown **−34.5%**, Sharpe **0.16**. (SPY buy & hold: +14.1% CAGR, −33.7% DD.)

| # | Upgrade (flag) | CAGR | Win | PF | Max DD | Verdict |
|---|---|---|---|---|---|---|
| — | Baseline | +5.33% | 64.4% | 1.09 | −34.5% | reference |
| 1 | Trailing ATR stop (`--trailing-stop`) | +5.13% | 63.7% | 1.09 | **−31.9%** | mild win: cuts DD ~2.6pts + avg loss $801→$753, small return/win cost |
| 2 | Score-weighted sizing (`--score-weighted-sizing`) | +5.34% | 64.4% | 1.09 | −35.7% | **no effect** (slightly worse DD) |
| 3 | Correlation control (`--max-correlation 0.7`) | +5.27% | 64.5% | 1.08 | −33.3% | small DD help; 563 entries skipped |
| 4 | Graduated regime (`--graduated-regime`) | +4.37% | 64.5% | 1.09 | **−28.8%** | **best DD cut (−5.7pts)** + far less whipsaw, at ~1% CAGR cost |
| 5 | Vol-contraction (`--vol-contraction`) | −0.06% | 65.3% | 1.01 | −20.6% | **backfired** on S&P 500 (see below) |

### 1. Trailing ATR stop — *modestly helpful for risk*
Ratchets the stop up each bar (never down), measured against the initial stop for
R. It **reduced max drawdown (−34.5% → −31.9%) and shrank the average loss
($801 → $753)**, but slightly lowered win rate (64.4% → 63.7%) and CAGR — because
trailing exits some bounces early, which is exactly what a mean-reversion trade
does *not* want. Net: a small risk improvement, not a return improvement.

### 2. Score-weighted sizing — *did nothing (as predicted)*
Scaling risk 0.5%–1.5% by the entry's confluence-score percentile changed CAGR by
+0.01pt and win rate by 0.0pt. **This directly confirms the Part 4/6 finding that
the confluence score does not predict win rate** — so sizing by it cannot add
edge. We left the finding standing rather than pretending otherwise.

### 3. Correlation control — *small, honest diversification benefit*
Skipping entries >0.7 correlated with 2+ held names skipped **563 trades** and cut
max drawdown modestly (−34.5% → −33.3%). Realized average pairwise correlation of
held names was already low (**0.28**) — the strategy naturally picks scattered
names, so there wasn't much concentration to fix.

### 4. Graduated regime filter — *the best risk upgrade*
Replacing the binary SPY-200-SMA on/off gate with a continuous exposure multiplier
(from SPY's distance-from-200-SMA and its 20-day slope) **cut max drawdown the most
(−34.5% → −28.8%)** and slashed regime whipsaw — the binary gate flips **79** times
over 15 years; the graduated version has only **23** on/off transitions. The cost
is ~1% CAGR (it holds less in weak tapes). This is a genuine risk-adjusted win.

### 5. Volatility-contraction filter — *worked on curated, FAILED on the S&P 500*
This is the most important honest result. On the **curated 26-name basket** the
filter looked great — win rate **65% → 76%**, PF **1.14 → 1.38**. But on the **full
S&P 500** it barely moved win rate (64.4% → 65.3%), collapsed profit factor to
**1.01**, and flattened CAGR to **≈0%** (trades 5,789 → 1,745). It reduced drawdown
(−20.6%) simply by trading far less. **A filter that shines on a hand-picked basket
did not generalise to the broad universe** — a fresh confirmation of the Part 3/5
"quality-of-universe beats quantity, and small-sample wins don't always scale"
finding. It is off by default for this reason.

### 6. Walk-forward validation (`python -m backtest.walkforward`)
Rolling 3-year train / 1-year test, grid-searching `rsi_entry`, `stop_atr_mult`,
`max_hold_days` (curated universe for tractability; full-S&P grid = hundreds of
runs). **In-sample optimisation averaged +6.0% CAGR; stitched out-of-sample
delivered +4.9%** — a 1.1-point "optimisation shrinkage." Crucially, the
**out-of-sample win rate held at ~68.7%** (near the untuned ~64%), and the 2022
bear-market window still lost (−11%, 42% win). Takeaway: **the edge is structural
(the setup), not the specific parameters** — and optimisation always looks better
in-sample than it pays out live. Full per-window table is appended to
`output/backtest/report.md`.

### 7. Stress-tested transaction costs (`--stress-costs`)
| Costs | CAGR | vs SPY | PF | Max DD | Profitable trades |
|---|---|---|---|---|---|
| 1× | +5.3% | −8.8% | 1.09 | −34.5% | 3,726 / 5,789 |
| 2× | +1.2% | −12.9% | 1.04 | −39.3% | 3,695 / 5,813 |
| 3× | −2.9% | −17.0% | 1.00 | −58.4% | 3,642 / 5,836 |

**The edge is fragile to costs.** At 2× assumed commission+slippage the CAGR falls
to ~1%; at 3× it turns negative and drawdown balloons. Since the full S&P 500
includes less-liquid names whose real slippage can exceed the dollar-volume filter's
assumption, this is a genuine risk — the strategy's thin per-trade edge (avg
+$25/trade) does not have much cushion.

## Part 7 — the honest bottom line
- The upgrades that **helped risk** (drawdown/whipsaw) were the **graduated regime
  filter** and, mildly, the **trailing stop** and **correlation control** — each at
  a small cost to return.
- **Score-weighted sizing did nothing** and **vol-contraction backfired on the broad
  universe** — both *reinforce*, not overturn, the earlier findings (confluence score
  doesn't predict win rate; small-sample wins don't generalise).
- Walk-forward shows real **optimisation shrinkage** but a **persistent ~64–69% win
  rate**, and cost-stress shows the edge is **thin and cost-sensitive**.
- **None of these upgrades made the strategy beat SPY buy-and-hold on return.** The
  Part 1–6 conclusions stand: high win rate ≠ high profit; risk control is where the
  real, defensible value is; and past, survivorship-biased, bull-market results are
  not guarantees. *Educational backtest — not investment advice.*



---

# Part 8 — Dedicated SHORT-SELLING model (separate)

A standalone short-side model that mirrors the long suite. It reuses the shared
data / indicators / metrics / charts but has its own strategies and a
short-correct engine. **It is fully separate — none of the long-side defaults
change.**

## Files
- `shortsell/strategies.py` — `ShortRSI2`, `ShortBollinger`, `ShortBreakdown` +
  a `short_quality_score` (the mirror confluence score).
- `shortsell/engine.py` — `ShortBacktester`: sells short at next open, stop sits
  **above** entry (hit when the day's HIGH ≥ stop), P/L = (entry − exit), a daily
  **borrow cost** on the short's market value, and an optional trailing stop that
  ratchets **down**.
- `run_short.py` — CLI runner (writes to `output/short/`).
- `scan_short.py` — live daily short scanner (`output/short_live/`).

## Commands
```bash
python run_short.py                       # ShortBreakdown, S&P 500, ~15y
python run_short.py --compare             # all 3 short strategies
python run_short.py --strategy shortrsi2 --oos-split 2019-01-01
python run_short.py --strategy shortbreakdown --trailing-stop
python scan_short.py --sp500 --top 15 --skip-earnings
```
Key rules: shorts are **gated to a short-friendly regime (SPY BELOW its 200-SMA)**
by default — the opposite of the long gate. Use `--no-regime` to short in any
tape (usually worse). Trade-sizing keeps the 1%-risk stop, but the stop is placed
*above* entry.

## Real results — full S&P 500, 2010→2026 (short side only)

| Strategy | Win rate | CAGR | vs SPY | Max DD | Profit factor |
|---|---|---|---|---|---|
| ShortRSI2 | 54.9% | **−4.0%** | −18.1% | −57.2% | 0.78 |
| ShortBollinger | 46.8% | −2.0% | −16.1% | −36.1% | 0.84 |
| ShortBreakdown | 53.8% | −4.3% | −18.4% | −56.3% | 0.75 |
| SPY buy & hold | — | +14.1% | — | −33.7% | — |

## The honest conclusion (this is the whole point)
**Every short strategy lost money over 2010–2026**, even with a ~55% win rate.
Why: profit factor is **below 1.0** — the winners are small but the losers are
big, because a short that goes wrong (a squeeze / gap-up) can run against you
hard, while a short that works can only fall to zero. Add the structural up-drift
of the market and the borrow cost, and the short side is a **losing proposition in
a bull market** — which 2010–2026 overwhelmingly was.

**What shorting is actually useful for** is not standalone profit but **hedging**:
a small short sleeve can cushion a long book during the ~15% of days the market is
risk-off. Run standalone, it bleeds. This model exists so you can *show that with
real evidence* rather than assume shorts are symmetric to longs — they are not.

*Unlimited-loss risk (squeezes), borrow costs, survivorship bias, bull-market
sample, and "past performance ≠ future / not investment advice" all apply.*



---

# Part 9 — Does a ~1000-stock universe help? (tested — NO)

Requested test: expand from the S&P 500 to a ~1000-name universe (S&P 500 large
+ S&P 400 mid + top 100 S&P 600 small) and compare, same RSI-2 strategy,
2010→2026. Enable with `python run_backtest.py --sp1000 --strategy rsi2`.

| Universe | Win rate | CAGR | vs SPY | Max DD | Profit factor | Sharpe | Trades |
|---|---|---|---|---|---|---|---|
| S&P 500 (~500) | 62.7% | **+5.32%** | −8.8% | **−27.8%** | **1.10** | **0.16** | 8,332 |
| Expanded (~1000) | 61.6% | **+1.16%** | −13.0% | **−34.7%** | **1.03** | **−0.10** | 8,665 |

**Result: the bigger universe made everything worse.** CAGR was nearly quartered
(5.3% → 1.2%), profit factor fell to ~breakeven (1.10 → 1.03), max drawdown got
*deeper* (−27.8% → −34.7%), and Sharpe went negative. Only the trade count rose.

**Why:** the extra ~500 mid/small-caps are less liquid and noisier, so they add
mostly low-quality "oversold for a bad reason" signals (falling knives) that
dilute the edge — the same effect we saw going 26 → 500 (Part 3/5). More names
= more noise, not more alpha.

**Conclusion (consistent with the whole project):** quality of universe beats
quantity. Stick with the S&P 500 (or a curated large-cap basket). This is now
the *third* independent confirmation that "more" does not help this system —
bigger universe, more indicators (Part 6), and score-weighted sizing (Part 7)
all failed to add value. *Educational backtest — not investment advice.*



---

# Part 10 — v9 "Live Sprint": 60 trades in 10 days (the RIGHT validation)

The whole v8 project was measured as **15-year aggregate CAGR**. For this
assignment that is the wrong lens. What matters is: *can this plan realistically
complete ≥60 closed round-trips inside ONE arbitrary 10-trading-day window
(Mon Jul 20 – Fri Jul 31, 2026) and finish profitable?* v9 answers that with
**Monte-Carlo window sampling**, not a single long-run number.

## Flaws in v8 that v9 fixes
- **Wrong metric:** v8 reported 15-year averages. v9 adds `backtest/montecarlo.py`
  which samples 250 random 10-day windows and reports the *distribution* of
  trades-completed and return per window.
- **Holds too long:** TrendPullback's 12-day max hold can't turn over fast
  enough. The sprint config caps holds at **4 days** (exit on the RSI bounce,
  usually 1–3 days).
- **SMACross was useless here** (~9 trades/yr) — excluded from the sprint.
- **Confluence score** — v8 already proved it doesn't lift win rate; not
  re-litigated, not used to gate the sprint.
- **Shorting loses** — excluded; the sprint is **long-only**.
- **Sizing:** re-derived for many concurrent slots — **equal-weight = capital/N**
  (~$3,300–$5,500 each), which keeps per-trade risk tiny and total exposure ≤100%.

## Monte Carlo results — full S&P 500, 250 random 10-day windows (2015–2026)

**Strategy comparison (N=18):**
| Strategy | Median trades | % windows ≥60 | Median return | Win rate |
|---|---|---|---|---|
| **RSI-2 sprint** (buy oversold dips, 4-day hold) | **61** | 54% | +0.5% | 61% |
| Donchian breakout | 25 | **0%** | +0.0% | 50% |

→ Breakouts are **too rare** to hit 60 in 10 days. **RSI-2 mean reversion is the
only viable engine** (lots of daily oversold candidates across 500 names).

**Effect of N (concurrent positions) on RSI-2 sprint:**
| N | Median trades | % windows ≥60 | Median return | % profitable | % hit BOTH | Win rate |
|---|---|---|---|---|---|---|
| 18 | 61 | 54% | +0.5% | 57% | 30% | 61% |
| 24 | 78 | 80% | +0.4% | 59% | 44% | 62% |
| **28–30** | **~90** | **~88%** | +0.4% | 58% | ~47% | 62% |

**Key insight:** raising N sharply raises the chance of hitting 60 **with no cost
to win rate or return** (positions just get smaller/equal-weight). So the trade-
count problem is solved by *more concurrent positions*, not by lowering quality.

## RECOMMENDED LIVE CONFIGURATION
- **Strategy:** RSI-2 mean reversion, long-only — buy a liquid S&P 500 name that
  is oversold (RSI(2) < 15) **while above its 200-day average**; exit when it
  bounces back above its 5-day average (or after 4 days, or on the stop).
- **Universe:** full S&P 500 (need the breadth to fill the slots).
- **N = 28 concurrent positions**, equal-weight ≈ **$3,500 each** (10% single-name
  cap is naturally respected).
- **Stop:** ATR-based (~2.5×ATR below entry). **Never hold through earnings**
  (the scanner flags/【skips】any name reporting inside your hold window).

## The HONEST bottom line (say this in your write-up)
- **Hitting ≥60 trades is very achievable** at N=28 (~88% of historical 10-day
  windows cleared 60). ✅
- **Finishing net profitable is roughly a coin-flip with a slight edge** — median
  window ≈ +0.4%, ~58% of windows profitable, ~42% beat SPY, worst window ≈ −17%.
  A 10-day window is short, so single-window luck dominates — the Monte Carlo
  *proves* this, which is itself a mature, honest thing to present.
- Win rate is a dependable **~61–62%**. The strategy's job here is a **high hit
  rate with controlled risk**, not a big 10-day return.

## Judgment calls / assumptions I made (flagged, per your request)
1. **PEAD sleeve NOT backtested.** Free, reliable earnings dates for 500 names
   across 2015–2026 don't exist (yfinance gives ~6 yrs per ticker and rate-limits
   bulk calls). Building a 15-year PEAD backtest would require faked/incomplete
   data — against the honesty culture. The **defensive** earnings use (blackout)
   IS built and live. Treat PEAD as an optional, un-validated live idea only.
2. **Equal-weight (capital/N) sizing** chosen over 1%-risk sizing because with
   20–30 concurrent slots, risk-based sizing would over-deploy; equal-weight caps
   total exposure and keeps per-name risk small.
3. **Monte Carlo samples 2015–2026** (post-2015) so windows span varied regimes
   incl. 2018/2020/2022 selloffs — bad-luck windows are included (worst −17%).
4. **Survivorship bias** (today's S&P 500) still inflates results; real slippage
   on the least-liquid names may be worse than modelled.

## Your morning checklist — every trading day, Jul 20 → Jul 31
```
1) python scan_live.py --sprint --skip-earnings
      - reads your journal, prints "X/60 done, D days left, pace needed"
      - lists ~28 ranked oversold candidates, each already sized (~$3,500),
        with stop, and earnings flagged.
2) Place the top clean names in TradingView (skip any "SKIP-earnings").
      - buy at/near the open, set the stop, and a modest take-profit
        (or just exit when it bounces above the 5-day average).
3) python manage_positions.py
      - move a stop to breakeven once a trade is +1R; book bounces.
4) When a trade closes, add ONE row to data/my_trades.csv.
5) Watch the pace line: if you're behind, raise --n-positions (e.g. 30-35)
   or --top; if ahead, take only the highest-score setups.
Final day: close everything, then  python main.py report --file data/my_trades.csv
```

## Commands
```bash
python run_backtest.py --live-sprint --mc-windows 250 --n-positions 28   # validate
python scan_live.py --sprint --skip-earnings                              # daily
```
*Educational backtest on survivorship-biased data — not investment advice.*

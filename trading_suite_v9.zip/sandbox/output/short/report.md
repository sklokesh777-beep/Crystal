# SHORT-SELLING Backtest — ShortRSI2

*Window 2010-01-05 to 2026-07-14 (16.5y) · 504 symbols · SHORT side only*

## Headline

- **Total return:** -48.81%
- **CAGR:** -3.97%
- **Win rate:** 54.9%  ·  **Profit factor:** 0.78
- **Max drawdown:** -57.22%
- **Trades:** 1162  ·  **Avg hold:** 5.9d

### Equity Curve
![equity_curve.png](equity_curve.png)

### Drawdown
![drawdown.png](drawdown.png)

### Yearly Returns
![yearly_returns.png](yearly_returns.png)

### Trade Pnl
![trade_pnl.png](trade_pnl.png)

## Honest caveats — shorting is HARD (read this)

- **Structural headwind:** stocks drift UP over the long run, so a short book fights gravity. 2010-2026 was a strong bull market — expect shorts to lag or lose on the whole.
- **Borrow cost:** shorts pay a daily borrow fee (modelled here); hard-to-borrow names can cost far more than the ~1% default.
- **Asymmetric risk:** a long can only fall to zero, but a short's loss is theoretically UNLIMITED (short squeezes). The ATR stop caps this in the model, but real squeezes can gap through stops.
- **Regime matters most:** shorts are gated to when SPY is below its 200-SMA (risk-off). Turning that off (`--no-regime`) usually makes it worse. Survivorship bias and 'not investment advice' caveats from the long model apply here too.
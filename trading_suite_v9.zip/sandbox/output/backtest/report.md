# Backtest Report — RSI2

*Window: 2010-01-05 to 2026-07-15 (16.5 years) · 1001 symbols · generated 2026-07-17*

## Headline

- **Total return:** +20.92% ($100,000 -> $120,916)
- **CAGR:** +1.16%
- **SPY buy & hold CAGR:** +14.12% -> **edge -12.97%**
- **Win rate:** 61.6%  ·  **Profit factor:** 1.03
- **Max drawdown:** -34.71%  (SPY: -33.72%)
- **Sharpe / Sortino / Calmar:** -0.10 / -0.13 / 0.03
- **Trades:** 8665  ·  **Avg hold:** 5.3 days  ·  **Avg exposure:** 75%

## Metric tables

| Return / risk | Value |
|---|---|
| Total return | +20.92% |
| CAGR | +1.16% |
| Max drawdown | -34.71% |
| Annualised volatility | +16.01% |
| Sharpe | -0.10 |
| Sortino | -0.13 |
| Calmar (CAGR/MaxDD) | 0.03 |
| Avg exposure | 75.2% |

| Trade stats | Value |
|---|---|
| Trades | 8665 (W 5340 / L 3325) |
| Win rate | 61.6% |
| Profit factor | 1.03 |
| Expectancy / trade | $5 (+0.00R) |
| Avg win / avg loss | $239 / $-371 |
| Best / worst | $5,205 / $-5,148 |
| Avg holding days | 5.3 |
| Exit reasons | {'signal': 7828, 'stop': 764, 'time': 73} |

## Does the multi-indicator confluence score help? (honest test)

Win rate and average R-multiple grouped by the entry confluence score. If higher buckets win more often / earn more R, the score adds predictive value; if flat, it does not.

| Score bucket | Trades | Win rate | Avg R |
|---|---|---|---|
| 0-39 | 15 | 60.0% | -0.13 |
| 40-54 | 371 | 62.0% | -0.01 |
| 55-69 | 2890 | 62.2% | +0.00 |
| 70-84 | 4619 | 61.6% | +0.01 |
| 85-100 | 770 | 59.5% | -0.01 |

## Charts

### Equity Curve
![Equity Curve](equity_curve.png)

### Drawdown
![Drawdown](drawdown.png)

### Yearly Returns
![Yearly Returns](yearly_returns.png)

### Trade Pnl
![Trade Pnl](trade_pnl.png)

## Honest caveats (read before quoting these numbers)

- **Survivorship bias:** the default universe is *today's* large-caps (NVDA, AAPL, etc.). They were selected *because* they succeeded, which inflates historical results. A rigorous test would use a point-in-time index membership that includes names that later failed.
- **Bull-market regime:** 2010-2024 was one of the strongest bull runs in history. Trend-following looks exceptional here; mean-reversion lags buy-and-hold because it sits in cash much of the time.
- **No look-ahead, but idealised fills:** stops/exits assume you get the modelled price; real fills can be worse around gaps.
- **Past performance does not guarantee future results.** This is an educational backtest, **not investment advice.**

---
*Backtest assumptions: signals read at each bar's close and filled at the next bar's open (no look-ahead); per-trade commission and slippage applied to every fill; ATR-based protective stop and a max-holding time stop bound each trade's risk. Prices are split/dividend-adjusted.*
# Paper Trading Performance Report

*Generated 2026-07-16 · Account currency: USD*

## 1. Headline results

- **Starting capital:** $100,000.00
- **Ending capital:** $110,092.52
- **Net P/L:** $10,092.52 (**+10.09%**)
- **SPY buy & hold over same window:** +1.94% (data: fallback (manual prices))
- **Alpha vs market:** +8.16%
- **Max drawdown:** -2.06% ($-2,305.14)
- **Return / Max-Drawdown:** 4.91x
- **Sharpe / Sortino (annualised):** 7.33 / 17.91

> **Objective:** capital preservation with steady, risk-adjusted returns. Every trade was sized to risk a fixed 1.0% of capital (≈$1,000.00), with a minimum planned reward:risk of 2:1.

## 2. Full performance metrics

| Metric | Value |
|---|---|
| Net P/L | $10,092.52 |
| Total return | +10.09% |
| Trades (W/L/BE) | 60 (33/27/0) |
| Win rate | 55.0% |
| Profit factor | 1.52 |
| Expectancy / trade | $168.21 (+0.16R) |
| Average win | $892.42 |
| Average loss | $-716.93 |
| Largest win | $1,583.90 |
| Largest loss | $-1,050.62 |
| Average R-multiple | +0.16R |
| Total R | +9.5R |
| Average hold (days) | 4.7 |
| Max consecutive wins | 7 |
| Max consecutive losses | 4 |

### Risk-adjusted ratios

| Ratio | Value | Interpretation |
|---|---|---|
| Return / Max-DD | 4.91x | period return ÷ worst drawdown (robust) |
| Sharpe (annualised) | 7.33 | return per unit of total volatility |
| Sortino (annualised) | 17.91 | return per unit of *downside* volatility |
| Annualised volatility | +30.19% | daily σ × √252 |
| Trading days in sample | 11 | length of the test window |

> **Caveat:** the sample is only 11 trading days. Annualised Sharpe/Sortino are shown for completeness but are *not* statistically robust over such a short window — they scale a ~2-week result up to a full year. The primary, defensible metrics here are the **period return, win rate, profit factor, expectancy, and Return/Max-Drawdown**.

## 3. Performance by strategy sleeve

| Sleeve | Strategy | Trades | Win % | Net P/L | Avg R |
|---|---|---|---|---|---|
| A_EARNINGS | Post-earnings drift swing | 14 | 57% | $4,234.67 | +0.30R |
| B_REL_STRENGTH | Relative strength / sector rotation | 14 | 57% | $2,750.55 | +0.20R |
| C_MEAN_REVERSION | Mean reversion (RSI-2 oversold) | 12 | 58% | $1,912.48 | +0.16R |
| D_PAIRS | Market-neutral pairs | 10 | 60% | $1,791.12 | +0.18R |
| E_OVERNIGHT | Overnight momentum (BTST-equivalent) | 10 | 40% | $-596.30 | -0.12R |

## 4. Long vs short

| Direction | Trades | Win % | Net P/L | Avg R |
|---|---|---|---|---|
| LONG | 52 | 54% | $8,294.92 | +0.14R |
| SHORT | 8 | 62% | $1,797.60 | +0.27R |

## 5. Charts

## 6. Full trade log

| # | Ticker | Sleeve | Dir | Entry date | Entry | Stop | Target | Qty | Exit date | Exit | Hold | Risk $ | P/L $ | P/L % | R | Catalyst | Exit reason |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 51 | NVDA | E_OVERNIGHT | LONG | 2026-07-16 | 168.5 | 165.5 | 174.0 | 167.0 | 2026-07-17 | 171.51 | 1 | 501.0 | 501.67 | 1.78 | 1.0 | Closed at HOD on volume + AI catalyst | Sold into gap-up |
| 2 | BAC | A_EARNINGS | LONG | 2026-07-16 | 46.5 | 45.0 | 50.0 | 667.0 | 2026-07-20 | 45.15 | 4 | 1000.5 | -901.45 | -2.91 | -0.9 | Bank earnings beat, above opening range | Faded, stopped |
| 29 | AAPL | C_MEAN_REVERSION | LONG | 2026-07-16 | 232.5 | 226.0 | 245.0 | 154.0 | 2026-07-20 | 239.01 | 4 | 1001.0 | 1001.54 | 2.8 | 1.0 | RSI(2)<10, tag lower BB, above 200DMA | Reverted to 5-MA |
| 52 | TSLA | E_OVERNIGHT | LONG | 2026-07-17 | 320.0 | 313.0 | 334.0 | 71.0 | 2026-07-20 | 313.01 | 3 | 497.0 | -497.29 | -2.19 | -1.0 | Momentum close faded overnight | Stopped at open |
| 1 | JPM | A_EARNINGS | LONG | 2026-07-16 | 295.0 | 288.0 | 312.0 | 143.0 | 2026-07-21 | 304.81 | 5 | 1001.0 | 1401.83 | 3.32 | 1.4 | Q2 beat, guided NII higher, gap held | Trailed out below target |
| 30 | V | C_MEAN_REVERSION | LONG | 2026-07-17 | 355.0 | 347.0 | 371.0 | 125.0 | 2026-07-21 | 360.61 | 4 | 1000.0 | 700.25 | 1.58 | 0.7 | Oversold bounce | RSI back to 55 |
| 53 | AMD | E_OVERNIGHT | LONG | 2026-07-20 | 166.0 | 162.5 | 173.0 | 143.0 | 2026-07-21 | 169.16 | 1 | 500.5 | 450.88 | 1.9 | 0.9 | Breakout close, semis strength | Sold gap-up |
| 6 | PEP | A_EARNINGS | SHORT | 2026-07-16 | 145.0 | 149.0 | 136.0 | 250.0 | 2026-07-22 | 141.0 | 6 | 1000.0 | 999.0 | 2.76 | 1.0 | Volume miss, weak NA beverages | Covered into support |
| 18 | XOM | B_REL_STRENGTH | LONG | 2026-07-16 | 118.0 | 114.5 | 127.0 | 286.0 | 2026-07-22 | 122.2 | 6 | 1001.0 | 1200.2 | 3.56 | 1.2 | Energy leadership, oil bid | Partial exit |
| 41 | KO | D_PAIRS | LONG | 2026-07-16 | 70.0 | 68.6 | 73.0 | 714.0 | 2026-07-22 | 71.12 | 6 | 999.6 | 798.68 | 1.6 | 0.8 | Pair KO/PEP: long laggard KO | Ratio reverted |
| 42 | PEP | D_PAIRS | SHORT | 2026-07-16 | 145.0 | 148.0 | 139.0 | 333.0 | 2026-07-22 | 143.2 | 6 | 999.0 | 598.4 | 1.24 | 0.6 | Pair KO/PEP: short leader PEP | Ratio reverted |
| 4 | NFLX | A_EARNINGS | LONG | 2026-07-20 | 1250.0 | 1210.0 | 1340.0 | 25.0 | 2026-07-22 | 1210.04 | 2 | 1000.0 | -1000.0 | -3.2 | -1.0 | Subs beat but soft guide | Stopped on guidance |
| 31 | MA | C_MEAN_REVERSION | LONG | 2026-07-20 | 560.0 | 548.0 | 585.0 | 83.0 | 2026-07-22 | 550.41 | 2 | 996.0 | -796.97 | -1.71 | -0.8 | Bounce failed | Stopped |
| 54 | META | E_OVERNIGHT | LONG | 2026-07-21 | 722.0 | 710.0 | 745.0 | 42.0 | 2026-07-22 | 712.42 | 1 | 504.0 | -403.36 | -1.33 | -0.8 | Strong close top of range | Gapped down, stopped |
| 8 | JNJ | A_EARNINGS | LONG | 2026-07-16 | 162.0 | 158.0 | 172.0 | 250.0 | 2026-07-23 | 158.8 | 7 | 1000.0 | -801.0 | -1.98 | -0.8 | Pharma guide raise | Reversed, cut |
| 15 | NVDA | B_REL_STRENGTH | LONG | 2026-07-16 | 168.0 | 162.0 | 184.0 | 167.0 | 2026-07-23 | 175.81 | 7 | 1002.0 | 1303.27 | 4.65 | 1.3 | Fresh high, AI leadership, vol expansion | Trailed out |
| 3 | GS | A_EARNINGS | LONG | 2026-07-17 | 640.0 | 625.0 | 680.0 | 67.0 | 2026-07-23 | 662.51 | 6 | 1005.0 | 1507.17 | 3.51 | 1.5 | Trading revenue blowout | Trailed out |
| 17 | AVGO | B_REL_STRENGTH | LONG | 2026-07-17 | 285.0 | 276.0 | 310.0 | 111.0 | 2026-07-23 | 276.01 | 6 | 999.0 | -998.89 | -3.16 | -1.0 | Breakout failed on chip wobble | Full stop |
| 32 | COST | C_MEAN_REVERSION | LONG | 2026-07-20 | 985.0 | 965.0 | 1025.0 | 50.0 | 2026-07-23 | 1003.02 | 3 | 1000.0 | 900.0 | 1.83 | 0.9 | Pullback in uptrend | Reverted |
| 55 | XOM | E_OVERNIGHT | SHORT | 2026-07-22 | 120.5 | 123.5 | 115.0 | 167.0 | 2026-07-23 | 118.09 | 1 | 501.0 | 401.47 | 2.0 | 0.8 | Overbought into resistance, oil fade | Covered gap-down |
| 16 | MSFT | B_REL_STRENGTH | LONG | 2026-07-16 | 505.0 | 493.0 | 535.0 | 83.0 | 2026-07-24 | 520.61 | 8 | 996.0 | 1294.63 | 3.09 | 1.3 | Pullback to rising 20-EMA held | Trailed out |
| 5 | TSM | A_EARNINGS | LONG | 2026-07-17 | 420.0 | 408.0 | 450.0 | 83.0 | 2026-07-24 | 438.01 | 7 | 996.0 | 1493.83 | 4.29 | 1.5 | AI demand, raised capex outlook | Trailed out |
| 19 | CVX | B_REL_STRENGTH | LONG | 2026-07-17 | 155.0 | 150.5 | 166.0 | 222.0 | 2026-07-24 | 150.95 | 7 | 999.0 | -900.1 | -2.62 | -0.9 | Sector rotation into energy | Reversed, stopped |
| 7 | UAL | A_EARNINGS | LONG | 2026-07-20 | 92.0 | 88.5 | 100.0 | 286.0 | 2026-07-24 | 88.33 | 4 | 1001.0 | -1050.62 | -3.99 | -1.05 | Airline beat fade | Full stop |
| 21 | AMD | B_REL_STRENGTH | LONG | 2026-07-20 | 165.0 | 159.0 | 180.0 | 167.0 | 2026-07-24 | 159.31 | 4 | 1002.0 | -951.23 | -3.45 | -0.95 | Momentum stalled | Stopped |
| 33 | HD | C_MEAN_REVERSION | LONG | 2026-07-21 | 415.0 | 405.0 | 435.0 | 100.0 | 2026-07-24 | 408.01 | 3 | 1000.0 | -700.0 | -1.69 | -0.7 | Oversold, defensive retail | Cut early |
| 34 | PG | C_MEAN_REVERSION | LONG | 2026-07-21 | 168.0 | 164.0 | 176.0 | 250.0 | 2026-07-24 | 170.8 | 3 | 1000.0 | 699.0 | 1.66 | 0.7 | Lower BB tag, quality | Reverted |
| 35 | UNH | C_MEAN_REVERSION | LONG | 2026-07-22 | 310.0 | 301.0 | 328.0 | 111.0 | 2026-07-24 | 301.01 | 2 | 999.0 | -998.89 | -2.9 | -1.0 | Catch failed | Stopped |
| 56 | AAPL | E_OVERNIGHT | LONG | 2026-07-23 | 234.0 | 230.0 | 242.0 | 125.0 | 2026-07-24 | 230.41 | 1 | 500.0 | -449.75 | -1.54 | -0.9 | Overnight momentum stalled | Stopped |
| 9 | ASML | A_EARNINGS | LONG | 2026-07-20 | 780.0 | 758.0 | 840.0 | 45.0 | 2026-07-27 | 815.22 | 7 | 990.0 | 1583.9 | 4.51 | 1.6 | Bookings surge | Trailed out |
| 20 | SMH | B_REL_STRENGTH | LONG | 2026-07-20 | 285.0 | 278.0 | 302.0 | 143.0 | 2026-07-27 | 291.31 | 7 | 1001.0 | 901.33 | 2.21 | 0.9 | Semis relative strength | Momentum fade exit |
| 43 | BAC | D_PAIRS | LONG | 2026-07-20 | 46.5 | 45.6 | 48.5 | 1111.0 | 2026-07-27 | 47.04 | 7 | 999.9 | 598.94 | 1.16 | 0.6 | Pair JPM/BAC: long laggard BAC | Ratio reverted |
| 44 | JPM | D_PAIRS | SHORT | 2026-07-20 | 296.0 | 302.0 | 285.0 | 167.0 | 2026-07-27 | 299.59 | 7 | 1002.0 | -600.53 | -1.21 | -0.6 | Pair JPM/BAC: short leader JPM | Ratio widened, cut |
| 10 | IBM | A_EARNINGS | SHORT | 2026-07-22 | 285.0 | 292.0 | 270.0 | 143.0 | 2026-07-27 | 280.09 | 5 | 1001.0 | 701.13 | 1.72 | 0.7 | Software soft, gap-up faded | Covered early |
| 36 | WMT | C_MEAN_REVERSION | LONG | 2026-07-23 | 98.0 | 95.5 | 103.0 | 400.0 | 2026-07-27 | 100.0 | 4 | 1000.0 | 799.0 | 2.04 | 0.8 | Oversold, above 200DMA | Reverted |
| 57 | SMH | E_OVERNIGHT | LONG | 2026-07-24 | 288.0 | 283.0 | 297.0 | 100.0 | 2026-07-27 | 292.01 | 3 | 500.0 | 400.0 | 1.39 | 0.8 | ETF momentum close | Sold gap-up |
| 22 | GOOGL | B_REL_STRENGTH | LONG | 2026-07-21 | 195.0 | 189.0 | 210.0 | 167.0 | 2026-07-28 | 201.01 | 7 | 1002.0 | 1002.67 | 3.08 | 1.0 | Base breakout on volume | Trailed out |
| 23 | META | B_REL_STRENGTH | LONG | 2026-07-21 | 720.0 | 700.0 | 770.0 | 50.0 | 2026-07-28 | 736.02 | 7 | 1000.0 | 800.0 | 2.22 | 0.8 | Uptrend continuation | Pre-earnings trim |
| 45 | CVX | D_PAIRS | LONG | 2026-07-21 | 155.0 | 152.0 | 162.0 | 333.0 | 2026-07-28 | 156.5 | 7 | 999.0 | 498.5 | 0.97 | 0.5 | Pair XOM/CVX: long laggard CVX | Ratio reverted |
| 46 | XOM | D_PAIRS | SHORT | 2026-07-21 | 120.0 | 123.0 | 114.0 | 333.0 | 2026-07-28 | 117.6 | 7 | 999.0 | 798.2 | 2.0 | 0.8 | Pair XOM/CVX: short leader XOM | Ratio reverted |
| 11 | T | A_EARNINGS | LONG | 2026-07-23 | 29.5 | 28.6 | 31.5 | 1111.0 | 2026-07-28 | 28.69 | 5 | 999.9 | -900.91 | -2.75 | -0.9 | Subscriber beat | Faded, stopped |
| 37 | LLY | C_MEAN_REVERSION | LONG | 2026-07-23 | 780.0 | 762.0 | 815.0 | 56.0 | 2026-07-28 | 799.82 | 5 | 1008.0 | 1108.92 | 2.54 | 1.1 | Pharma pullback buy | Target near |
| 58 | GOOGL | E_OVERNIGHT | LONG | 2026-07-27 | 198.0 | 194.5 | 205.0 | 143.0 | 2026-07-28 | 195.56 | 1 | 500.5 | -349.92 | -1.24 | -0.7 | Fresh high into close pre-earnings drift | Gapped down, cut |
| 12 | LMT | A_EARNINGS | LONG | 2026-07-22 | 465.0 | 452.0 | 500.0 | 77.0 | 2026-07-29 | 479.31 | 7 | 1001.0 | 1100.87 | 3.07 | 1.1 | Defense backlog, buyback | Partial into strength |
| 24 | XLE | B_REL_STRENGTH | LONG | 2026-07-22 | 92.0 | 89.5 | 99.0 | 400.0 | 2026-07-29 | 90.0 | 7 | 1000.0 | -801.0 | -2.18 | -0.8 | Energy ETF momentum | Oil rolled over, cut |
| 25 | AMZN | B_REL_STRENGTH | LONG | 2026-07-22 | 225.0 | 218.0 | 242.0 | 143.0 | 2026-07-29 | 232.71 | 7 | 1001.0 | 1101.53 | 3.42 | 1.1 | Retail + cloud strength | Partial exit |
| 47 | MA | D_PAIRS | LONG | 2026-07-22 | 560.0 | 550.0 | 580.0 | 100.0 | 2026-07-29 | 555.01 | 7 | 1000.0 | -500.0 | -0.89 | -0.5 | Pair V/MA: long laggard MA | Small adverse, cut |
| 48 | V | D_PAIRS | SHORT | 2026-07-22 | 358.0 | 365.0 | 344.0 | 143.0 | 2026-07-29 | 361.49 | 7 | 1001.0 | -500.07 | -0.98 | -0.5 | Pair V/MA: short leader V | Small adverse, cut |
| 59 | AVGO | E_OVERNIGHT | LONG | 2026-07-28 | 292.0 | 287.0 | 302.0 | 100.0 | 2026-07-29 | 288.01 | 1 | 500.0 | -400.0 | -1.37 | -0.8 | Strong semis close | Reversed overnight |
| 26 | QQQ | B_REL_STRENGTH | LONG | 2026-07-23 | 555.0 | 544.0 | 578.0 | 91.0 | 2026-07-30 | 562.71 | 7 | 1001.0 | 700.61 | 1.39 | 0.7 | Index momentum, lower-vol proxy | Time exit |
| 27 | COP | B_REL_STRENGTH | LONG | 2026-07-23 | 108.0 | 104.5 | 117.0 | 286.0 | 2026-07-30 | 104.5 | 7 | 1001.0 | -1002.0 | -3.24 | -1.0 | Oil pulled back | Stopped |
| 49 | GOOGL | D_PAIRS | LONG | 2026-07-23 | 196.0 | 192.0 | 205.0 | 250.0 | 2026-07-30 | 198.8 | 7 | 1000.0 | 699.0 | 1.43 | 0.7 | Pair GOOGL/MSFT: long laggard GOOGL | Ratio reverted |
| 50 | MSFT | D_PAIRS | SHORT | 2026-07-23 | 508.0 | 518.0 | 488.0 | 100.0 | 2026-07-30 | 513.99 | 7 | 1000.0 | -600.0 | -1.18 | -0.6 | Pair GOOGL/MSFT: short leader MSFT | Ratio widened, cut |
| 13 | KO | A_EARNINGS | LONG | 2026-07-27 | 70.0 | 68.5 | 74.0 | 667.0 | 2026-07-30 | 68.95 | 3 | 1000.5 | -701.35 | -1.5 | -0.7 | Defensive earnings, weak follow-through | Cut early |
| 38 | ABBV | C_MEAN_REVERSION | LONG | 2026-07-27 | 205.0 | 200.0 | 215.0 | 200.0 | 2026-07-30 | 201.0 | 3 | 1000.0 | -801.0 | -1.95 | -0.8 | RSI bounce | Failed, stopped |
| 39 | MRK | C_MEAN_REVERSION | LONG | 2026-07-27 | 128.0 | 125.0 | 134.0 | 333.0 | 2026-07-30 | 126.2 | 3 | 999.0 | -600.4 | -1.41 | -0.6 | Weak bounce | Cut early |
| 14 | HON | A_EARNINGS | LONG | 2026-07-27 | 235.0 | 229.0 | 250.0 | 167.0 | 2026-07-31 | 239.81 | 4 | 1002.0 | 802.27 | 2.04 | 0.8 | Aerospace strength | Closed at deadline |
| 28 | ORCL | B_REL_STRENGTH | LONG | 2026-07-27 | 232.0 | 225.0 | 250.0 | 143.0 | 2026-07-31 | 225.71 | 4 | 1001.0 | -900.47 | -2.71 | -0.9 | Cloud momentum | Stopped near deadline |
| 40 | CRM | C_MEAN_REVERSION | LONG | 2026-07-28 | 268.0 | 261.0 | 282.0 | 143.0 | 2026-07-31 | 272.21 | 3 | 1001.0 | 601.03 | 1.57 | 0.6 | Oversold snap | Closed at deadline |
| 60 | QQQ | E_OVERNIGHT | LONG | 2026-07-30 | 560.0 | 555.0 | 570.0 | 100.0 | 2026-07-31 | 557.51 | 1 | 500.0 | -250.0 | -0.45 | -0.5 | Index strength into close | Soft open at deadline |

---
*Methodology notes: P/L is realised on the exit date; the equity curve marks the account per business day. Sharpe/Sortino use daily returns annualised by √252 with a 4% risk-free rate. R-multiple = realised P/L ÷ initial planned risk. Prices are from a paper-trading simulation and may reflect delayed data.*
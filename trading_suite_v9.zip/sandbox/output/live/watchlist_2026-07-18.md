# Live Watchlist — 2026-07-18

Strategy: **rsi2** · Market regime: **RISK-ON** · Capital $100,000 · Risk 1.0%/trade

| ticker   | sector                 |   score |     rsi2 |   close |    stop | as_of      |   shares |   notional |   days_to_earnings | earnings_flag   | news_sentiment   | headline   |
|:---------|:-----------------------|--------:|---------:|--------:|--------:|:-----------|---------:|-----------:|-------------------:|:----------------|:-----------------|:-----------|
| EBAY     | Consumer Discretionary |      78 |  8.9388  |  112.54 |  103.32 | 2026-07-14 |       31 |    3488.74 |                 18 |                 |                  |            |
| UAL      | Industrials            |      74 |  7.71752 |  120.35 |  105.01 | 2026-07-14 |       29 |    3490.15 |                 95 |                 |                  |            |
| DAL      | Industrials            |      73 | 11.4472  |   85.51 |   76.68 | 2026-07-14 |       41 |    3505.91 |                 82 |                 |                  |            |
| SNDK     | Information Technology |      73 |  9.02857 | 1411.08 |  782.27 | 2026-07-16 |        2 |    2822.16 |                 18 |                 |                  |            |
| LUV      | Industrials            |      73 |  8.0179  |   47.56 |   42.55 | 2026-07-14 |       75 |    3567    |                  4 | SKIP-earnings   |                  |            |
| LLY      | Health Care            |      72 |  3.4748  | 1152.54 | 1037.56 | 2026-07-14 |        3 |    3457.62 |                 18 |                 |                  |            |
| EW       | Health Care            |      71 | 10.1646  |   90.09 |   82.84 | 2026-07-14 |       39 |    3513.51 |                  5 | SKIP-earnings   |                  |            |
| BAX      | Health Care            |      69 | 12.1776  |   21.8  |   19.48 | 2026-07-14 |      163 |    3553.4  |                 12 |                 |                  |            |
| QCOM     | Information Technology |      69 |  9.45977 |  178.1  |  139.11 | 2026-07-14 |       20 |    3562    |                 11 |                 |                  |            |
| CAH      | Health Care            |      68 | 10.1994  |  230.11 |  213.59 | 2026-07-14 |       15 |    3451.65 |                 24 |                 |                  |            |
| GNRC     | Industrials            |      68 |  5.62769 |  215.38 |  174.02 | 2026-07-16 |       16 |    3446.08 |                 11 |                 |                  |            |
| TTWO     | Communication Services |      68 |  5.9046  |  237.04 |  212.34 | 2026-07-14 |       15 |    3555.6  |                 20 |                 |                  |            |
| GD       | Industrials            |      67 |  7.15438 |  369.5  |  346.71 | 2026-07-14 |        9 |    3325.5  |                 11 |                 |                  |            |
| NXPI     | Information Technology |      67 | 13.0207  |  270.66 |  227.99 | 2026-07-16 |       13 |    3518.58 |                 10 |                 |                  |            |
| SJM      | Consumer Staples       |      67 |  9.00241 |  108.81 |   99.83 | 2026-07-14 |       32 |    3481.92 |                 40 |                 |                  |            |
| C        | Financials             |      66 |  7.58775 |  133.27 |  121.16 | 2026-07-14 |       26 |    3465.02 |                 87 |                 |                  |            |
| MAA      | Real Estate            |      65 | 11.4151  |  132.15 |  124.26 | 2026-07-14 |       27 |    3568.05 |                 11 |                 |                  |            |
| MRNA     | Health Care            |      65 |  9.76419 |   63.15 |   48.45 | 2026-07-16 |       56 |    3536.4  |                 13 |                 |                  |            |
| GPC      | Consumer Discretionary |      62 | 14.2551  |  122.16 |  109.95 | 2026-07-14 |       29 |    3542.64 |                  3 | SKIP-earnings   |                  |            |
| VRTX     | Health Care            |      61 |  2.42846 |  476.31 |  432.21 | 2026-07-14 |        7 |    3334.17 |                 16 |                 |                  |            |
| JNJ      | Health Care            |      58 | 12.0192  |  253.85 |  236.43 | 2026-07-14 |       14 |    3553.9  |                 87 |                 |                  |            |
| ZBRA     | Information Technology |      58 | 10.4115  |  260.11 |  228.87 | 2026-07-14 |       13 |    3381.43 |                 17 |                 |                  |            |
| DGX      | Health Care            |      56 |  1.17673 |  206    |  192.21 | 2026-07-14 |       17 |    3502    |                  5 | SKIP-earnings   |                  |            |
| YUM      | Consumer Discretionary |      56 |  7.38775 |  158.18 |  145.77 | 2026-07-14 |       22 |    3479.96 |                 12 |                 |                  |            |
| PM       | Consumer Staples       |      55 |  4.72833 |  175.95 |  161.1  | 2026-07-14 |       20 |    3519    |                  4 | SKIP-earnings   |                  |            |
| SRE      | Utilities              |      54 | 14.7333  |   93.36 |   88.12 | 2026-07-14 |       38 |    3547.68 |                 19 |                 |                  |            |
| ANET     | Information Technology |      52 |  8.6268  |  168.56 |  137.67 | 2026-07-16 |       21 |    3539.76 |                 17 |                 |                  |            |
| IFF      | Materials              |      52 |  1.57221 |   74.67 |   67.26 | 2026-07-14 |       47 |    3509.49 |                 17 |                 |                  |            |

*Earnings/news are live context, not backtested. Avoid holding swing trades through earnings. Educational use only — not investment advice.*

# Live Watchlist — 2026-07-16

Strategy: **rsi2** · Market regime: **RISK-ON** · Capital $100,000 · Risk 1.0%/trade

| ticker   | sector   |   score |   rsi2 |   close |    stop | as_of      |   shares |   notional |   days_to_earnings | earnings_flag   |   news_sentiment | headline                                                                         |
|:---------|:---------|--------:|-------:|--------:|--------:|:-----------|---------:|-----------:|-------------------:|:----------------|-----------------:|:---------------------------------------------------------------------------------|
| LLY      |          |      72 | 3.4748 | 1152.54 | 1037.56 | 2026-07-14 |        8 |    9220.32 |                 20 |                 |             0.12 | ATAI Stock Eyes Rocketing Back To 4-Year Highs: VC Sees Up to 105% Takeover Prem |

*Earnings/news are live context, not backtested. Avoid holding swing trades through earnings. Educational use only — not investment advice.*

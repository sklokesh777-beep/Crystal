# Live Watchlist — 2026-07-17

Strategy: **rsi2** · Market regime: **RISK-ON** · Capital $100,000 · Risk 1.0%/trade

| ticker   | sector                 |   score |    rsi2 |   close |    stop | as_of      |   shares |   notional |   days_to_earnings | earnings_flag   |   news_sentiment | headline                                                                         |
|:---------|:-----------------------|--------:|--------:|--------:|--------:|:-----------|---------:|-----------:|-------------------:|:----------------|-----------------:|:---------------------------------------------------------------------------------|
| EBAY     | Consumer Discretionary |      78 | 8.9388  |  112.54 |  103.32 | 2026-07-14 |      108 |   12154.3  |                 19 |                 |             0.12 | GameStop (GME) Following Uber Eats Deal Has The Bull Case Already Priced In      |
| UAL      | Industrials            |      74 | 7.71752 |  120.35 |  105.01 | 2026-07-14 |       65 |    7822.75 |                 96 |                 |             0.12 | 1 S&P 500 Stock Worth Your Attention and 2 We Question                           |
| LLY      | Health Care            |      72 | 3.4748  | 1152.54 | 1037.56 | 2026-07-14 |        8 |    9220.32 |                 19 |                 |             0    | The weight-loss drugs boom is creating both winners and wipeouts: One Big Invest |
| ABBV     | Health Care            |      71 | 1.98002 |  243.05 |  224.02 | 2026-07-14 |       52 |   12638.6  |                 14 |                 |             0.25 | Why Healthcare Stocks Look Like a Haven in This Market                           |
| QCOM     | Information Technology |      69 | 9.45977 |  178.1  |  139.11 | 2026-07-14 |       25 |    4452.5  |                 12 |                 |             0    | 4 Tech Stocks Throwing Off Dividends                                             |
| GD       | Industrials            |      67 | 7.15438 |  369.5  |  346.71 | 2026-07-14 |       43 |   15888.5  |                 12 |                 |             0.38 | Trump Presses General Dynamics as $1.5 Trillion Defense Budget Advances          |
| SJM      | Consumer Staples       |      67 | 9.00241 |  108.81 |   99.83 | 2026-07-14 |      111 |   12077.9  |                 41 |                 |             0.25 | Conagra CEO Nails It: We're Raising Prices, And Yes, We'll Lose Sales            |
| C        | Financials             |      66 | 7.58775 |  133.27 |  121.16 | 2026-07-14 |       82 |   10928.1  |                 88 |                 |             0.25 | Dollar Hedging Costs Sink to Their Lowest Level This Year                        |
| GNRC     | Industrials            |      61 | 2.26826 |  225.12 |  182.53 | 2026-07-14 |       23 |    5177.76 |                 12 |                 |             0.25 | Is Generac Holdings (GNRC) Undervalued On Its Selloff Despite Positive Guidance? |
| VRTX     | Health Care            |      61 | 2.42846 |  476.31 |  432.21 | 2026-07-14 |       22 |   10478.8  |                 17 |                 |             0.12 | 1 Nasdaq 100 Stock to Keep an Eye On and 2 We Question                           |
| DGX      | Health Care            |      56 | 1.17673 |  206    |  192.21 | 2026-07-14 |       72 |   14832    |                  6 |                 |             0.25 | Quest Diagnostics to Report Q2 Earnings: Key Customer Channels in Focus          |
| YUM      | Consumer Discretionary |      56 | 7.38775 |  158.18 |  145.77 | 2026-07-14 |       80 |   12654.4  |                 13 |                 |             0.12 | Parasite concerns cast a shadow over fast-food stocks                            |
| IFF      | Materials              |      52 | 1.57221 |   74.67 |   67.26 | 2026-07-14 |      134 |   10005.8  |                 18 |                 |             0.25 | 1 S&P 500 Stock to Target This Week and 2 Facing Challenges                      |

*Earnings/news are live context, not backtested. Avoid holding swing trades through earnings. Educational use only — not investment advice.*

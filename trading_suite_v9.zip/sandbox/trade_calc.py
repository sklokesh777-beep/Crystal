"""
Trade Calculator — position sizing, targets, stops, risk & reward.

Built on top of the model's rules (1%-risk sizing, ATR stops, the confluence
score). Two modes:

  MANUAL  — you provide the numbers:
      python trade_calc.py --entry 232.50 --stop 226 --target 245
      python trade_calc.py --entry 100 --stop 96 --rr 2.5      # target from R:R
      python trade_calc.py --entry 118 --stop 122 --target 108 # SHORT (stop>entry)

  AUTO / LIVE — give a ticker; it pulls the latest price + ATR from the model,
  derives an ATR stop and an R-based target, and shows the technical context:
      python trade_calc.py --ticker AAPL
      python trade_calc.py --ticker NVDA --rr 2.5 --atr-mult 2.5
      python trade_calc.py --ticker XOM --direction short

Common options:
      --capital 100000 --risk 0.01 --commission 1 --max-position 0.10
      --shares 50            # override the calculated share count
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import date

import config  # root config: STARTING_CAPITAL, RISK_PER_TRADE_PCT, etc.


# ---------------------------------------------------------------------------
@dataclass
class TradeCalc:
    ticker: str
    direction: str          # "LONG" / "SHORT"
    entry: float
    stop: float
    target: float
    capital: float
    risk_pct: float
    commission: float       # per side ($)
    shares: int
    max_position_pct: float

    # ---- derived ------------------------------------------------------
    @property
    def sign(self) -> int:
        return 1 if self.direction == "LONG" else -1

    @property
    def risk_per_share(self) -> float:
        return abs(self.entry - self.stop)

    @property
    def reward_per_share(self) -> float:
        return abs(self.target - self.entry)

    @property
    def reward_risk(self) -> float:
        return self.reward_per_share / self.risk_per_share if self.risk_per_share else 0.0

    @property
    def notional(self) -> float:
        return self.shares * self.entry

    @property
    def position_pct(self) -> float:
        return self.notional / self.capital if self.capital else 0.0

    @property
    def round_trip_commission(self) -> float:
        return 2 * self.commission

    @property
    def max_loss(self) -> float:
        """Dollar loss if the stop is hit (incl. round-trip commission)."""
        return self.risk_per_share * self.shares + self.round_trip_commission

    @property
    def max_loss_pct_capital(self) -> float:
        return self.max_loss / self.capital if self.capital else 0.0

    @property
    def profit_at_target(self) -> float:
        return self.reward_per_share * self.shares - self.round_trip_commission

    @property
    def profit_pct_capital(self) -> float:
        return self.profit_at_target / self.capital if self.capital else 0.0

    @property
    def profit_pct_position(self) -> float:
        return self.profit_at_target / self.notional if self.notional else 0.0

    @property
    def breakeven(self) -> float:
        """Price that covers round-trip commission."""
        per_share_cost = self.round_trip_commission / self.shares if self.shares else 0.0
        return self.entry + self.sign * per_share_cost

    def r_target(self, r: float) -> float:
        """Price at a given R multiple from entry."""
        return self.entry + self.sign * r * self.risk_per_share

    def profit_at_r(self, r: float) -> float:
        return r * self.risk_per_share * self.shares - self.round_trip_commission

    # ---- warnings -----------------------------------------------------
    def warnings(self) -> list:
        w = []
        if self.direction == "LONG" and self.stop >= self.entry:
            w.append("LONG stop must be BELOW entry.")
        if self.direction == "SHORT" and self.stop <= self.entry:
            w.append("SHORT stop must be ABOVE entry.")
        if self.reward_risk < config.MIN_REWARD_RISK:
            w.append(f"Reward:risk {self.reward_risk:.2f} is below the "
                     f"{config.MIN_REWARD_RISK:.0f}:1 minimum — widen target or "
                     "tighten stop.")
        if self.position_pct > self.max_position_pct + 1e-9:
            w.append(f"Position is {self.position_pct*100:.1f}% of capital, above "
                     f"the {self.max_position_pct*100:.0f}% cap.")
        if self.shares <= 0:
            w.append("Share count is 0 — risk-per-share too large for the budget.")
        return w


# ---------------------------------------------------------------------------
def size_shares(capital: float, risk_pct: float, risk_per_share: float,
                entry: float, max_position_pct: float) -> tuple[int, bool]:
    """Shares from the risk rule, capped by the max-position limit."""
    if risk_per_share <= 0:
        return 0, False
    by_risk = (capital * risk_pct) / risk_per_share
    by_cap = (capital * max_position_pct) / entry
    capped = by_risk > by_cap
    return int(min(by_risk, by_cap)), capped


# ---------------------------------------------------------------------------
def auto_from_ticker(ticker: str, direction: str, atr_mult: float, rr: float,
                     entry_override: float | None):
    """Pull live price + ATR + context from the model to build a trade idea."""
    from datetime import timedelta
    from backtest import data as datamod
    from backtest import indicators as ind
    from backtest import analysis as ta
    from backtest import fundamentals as fund

    today = date.today()
    start = (today - timedelta(days=420)).isoformat()
    data = datamod.get_data([ticker.upper()], start, today.isoformat(),
                            use_cache=True)
    df = data[ticker.upper()]
    close = df["Close"]
    atr = float(ind.atr(df["High"], df["Low"], close, 14).iloc[-1])
    entry = entry_override if entry_override else float(close.iloc[-1])

    if direction == "LONG":
        stop = entry - atr_mult * atr
        target = entry + rr * (entry - stop)
    else:
        stop = entry + atr_mult * atr
        target = entry - rr * (stop - entry)

    context = {
        "as_of": df.index[-1].date().isoformat(),
        "atr": atr,
        "trend": ta.classify_trend(df),
        "summary": ta.summary(ticker.upper(), df),
    }
    try:
        d2e = fund.days_to_earnings(ticker.upper(), today)
        context["days_to_earnings"] = d2e
    except Exception:
        context["days_to_earnings"] = None
    return entry, stop, target, context


# ---------------------------------------------------------------------------
def _money(x): return f"${x:,.2f}"
def _pct(x): return f"{x*100:.2f}%"


def render(tc: TradeCalc, context: dict | None) -> str:
    L, add = [], lambda s: L.append(s)
    add("=" * 60)
    add(f"  TRADE CALCULATOR — {tc.ticker} ({tc.direction})")
    add("=" * 60)
    if context:
        add(f"  As of {context['as_of']}  |  Trend: {context['trend']}")
        if context.get("days_to_earnings") is not None:
            d = context["days_to_earnings"]
            flag = "  <-- AVOID: inside typical hold window" if 0 <= d <= 7 else ""
            add(f"  Next earnings in {d} days{flag}")
        add("-" * 60)
    add("  ORDER")
    add(f"    Entry price        : {_money(tc.entry)}")
    add(f"    Stop-loss          : {_money(tc.stop)}   "
        f"({tc.sign* (tc.stop/tc.entry-1)*100:+.2f}% from entry)")
    add(f"    Target price       : {_money(tc.target)}   "
        f"({tc.sign*(tc.target/tc.entry-1)*100:+.2f}% from entry)")
    add(f"    SHARES TO {'BUY ' if tc.direction=='LONG' else 'SHORT'}      : {tc.shares}")
    add(f"    Position value     : {_money(tc.notional)}  "
        f"({_pct(tc.position_pct)} of capital)")
    add("-" * 60)
    add("  RISK")
    add(f"    Risk per share     : {_money(tc.risk_per_share)}")
    add(f"    MAX LOSS (stop hit): {_money(tc.max_loss)}   "
        f"({_pct(tc.max_loss_pct_capital)} of capital)")
    add(f"    Account if stopped : {_money(tc.capital - tc.max_loss)}")
    add("-" * 60)
    add("  REWARD")
    add(f"    Reward:risk ratio  : {tc.reward_risk:.2f} : 1")
    add(f"    PROFIT at target   : {_money(tc.profit_at_target)}   "
        f"({_pct(tc.profit_pct_capital)} of capital, "
        f"{_pct(tc.profit_pct_position)} on position)")
    add(f"    Account if target  : {_money(tc.capital + tc.profit_at_target)}")
    add(f"    Breakeven price    : {_money(tc.breakeven)}")
    add("-" * 60)
    add("  R-MULTIPLE TARGETS (profit if you exit at each)")
    add(f"    {'R':>6}{'Price':>12}{'Profit $':>14}{'% capital':>12}")
    r_values = [1.0, 2.0, 3.0]
    if all(abs(tc.reward_risk - r) > 0.05 for r in r_values):
        r_values.append(tc.reward_risk)
        r_values.sort()
    for r in r_values:
        chosen = abs(r - tc.reward_risk) < 0.05
        label = (f"{r:.2f}R*" if chosen else f"{r:.1f}R")
        price = tc.r_target(r)
        prof = tc.profit_at_r(r)
        add(f"    {label:>6}{_money(price):>12}{_money(prof):>14}"
            f"{_pct(prof/tc.capital):>12}")
    add("    (* = your chosen target)")
    add("=" * 60)
    for wn in tc.warnings():
        add(f"  ! {wn}")
    if tc.warnings():
        add("=" * 60)
    return "\n".join(L)


# ---------------------------------------------------------------------------
def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Trade calculator: shares, target, "
                                            "stop, max loss, profit, R:R.")
    p.add_argument("--ticker", default=None, help="Auto/live mode: pull price+ATR.")
    p.add_argument("--entry", type=float, default=None, help="Manual entry price.")
    p.add_argument("--stop", type=float, default=None, help="Manual stop price.")
    p.add_argument("--target", type=float, default=None, help="Manual target price.")
    p.add_argument("--rr", type=float, default=config.MIN_REWARD_RISK,
                   help="Reward:risk to derive target when target not given.")
    p.add_argument("--direction", choices=["long", "short"], default="long")
    p.add_argument("--atr-mult", type=float, default=2.5,
                   help="Auto mode: stop = entry -/+ atr_mult * ATR(14).")
    p.add_argument("--capital", type=float, default=config.STARTING_CAPITAL)
    p.add_argument("--risk", type=float, default=config.RISK_PER_TRADE_PCT,
                   help="Fraction of capital risked (0.01 = 1 percent).")
    p.add_argument("--commission", type=float, default=1.0, help="Per side ($).")
    p.add_argument("--max-position", type=float, default=config.MAX_POSITION_PCT)
    p.add_argument("--shares", type=int, default=None, help="Override share count.")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    direction = args.direction.upper()
    context = None

    if args.ticker:
        entry, stop, target, context = auto_from_ticker(
            args.ticker, direction, args.atr_mult, args.rr, args.entry)
        ticker = args.ticker.upper()
        if context:
            print("\n" + context["summary"])
    elif args.entry is not None and args.stop is not None:
        entry, stop = args.entry, args.stop
        # Infer direction from stop side if user didn't force short.
        if args.direction == "long" and stop > entry:
            direction = "SHORT"
        target = args.target if args.target is not None else (
            entry + (1 if direction == "LONG" else -1) * args.rr * abs(entry - stop))
        ticker = "MANUAL"
    else:
        print("ERROR: provide --ticker (auto) OR --entry and --stop (manual).")
        return 1

    risk_per_share = abs(entry - stop)
    if args.shares is not None:
        shares, capped = args.shares, False
    else:
        shares, capped = size_shares(args.capital, args.risk, risk_per_share,
                                     entry, args.max_position)

    tc = TradeCalc(
        ticker=ticker, direction=direction, entry=round(entry, 2),
        stop=round(stop, 2), target=round(target, 2), capital=args.capital,
        risk_pct=args.risk, commission=args.commission, shares=shares,
        max_position_pct=args.max_position)

    print()
    print(render(tc, context))
    if capped:
        print("  (Share count was reduced to respect the max-position cap;\n"
              "   actual risk is therefore below your full risk budget.)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

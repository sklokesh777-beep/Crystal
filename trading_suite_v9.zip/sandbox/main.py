"""
Paper Trading Analytics — command line interface.

Commands
--------
  report    Analyse a trade journal: metrics + charts + Markdown report.
  size      Position-size calculator for a single trade idea (1% risk rule).
  template  Write a blank trade-journal CSV template you can fill in.

Examples
--------
  python main.py report                         # uses data/sample_trades.csv
  python main.py report --file data/my_trades.csv
  python main.py size --ticker AAPL --dir LONG --entry 232.5 --stop 226 --target 245
  python main.py template --out data/my_trades.csv
"""
from __future__ import annotations

import argparse
import sys

import config
from src import journal, analytics, benchmark, charts, report
from src.position_sizing import calculate_position


def cmd_report(args: argparse.Namespace) -> int:
    trades = journal.load_trades(args.file)

    a = analytics.analyse(trades, starting_capital=config.STARTING_CAPITAL)

    start = min(t.entry_date for t in trades)
    end = max(t.exit_date for t in trades)

    b = None
    if not args.no_benchmark:
        print(f"Fetching {config.BENCHMARK_TICKER} benchmark "
              f"({start} -> {end}) ...")
        b = benchmark.get_benchmark(start, end, config.STARTING_CAPITAL)
        print("  " + b.summary())

    # Console summary
    print()
    print(report.console_summary(a, b))
    print()

    # Charts + markdown report
    if not args.no_charts:
        chart_paths = charts.generate_all_charts(a, b)
    else:
        chart_paths = []
    md_path = report.write_markdown_report(a, b, chart_paths)

    print(f"Charts written to : {config.OUTPUT_DIR}/")
    for p in chart_paths:
        print(f"    - {p}")
    print(f"Report written to : {md_path}")
    return 0


def cmd_size(args: argparse.Namespace) -> int:
    plan = calculate_position(
        ticker=args.ticker,
        direction=args.dir,
        entry=args.entry,
        stop=args.stop,
        target=args.target,
        capital=args.capital,
        risk_pct=args.risk,
    )
    print()
    print(plan.explain())
    print()
    return 0


def cmd_template(args: argparse.Namespace) -> int:
    path = journal.write_template(args.out)
    print(f"Blank journal template written to: {path}")
    print("Columns:", ", ".join(journal.ALL_COLUMNS))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Paper-trading analytics for a US swing/overnight assignment.")
    sub = p.add_subparsers(dest="command", required=True)

    pr = sub.add_parser("report", help="Analyse a journal and build the report.")
    pr.add_argument("--file", default=config.DEFAULT_TRADES_FILE,
                    help="Path to the trades CSV.")
    pr.add_argument("--no-benchmark", action="store_true",
                    help="Skip the SPY benchmark fetch.")
    pr.add_argument("--no-charts", action="store_true",
                    help="Skip chart generation.")
    pr.set_defaults(func=cmd_report)

    ps = sub.add_parser("size", help="Position-size a single trade idea.")
    ps.add_argument("--ticker", required=True)
    ps.add_argument("--dir", required=True, choices=["LONG", "SHORT"])
    ps.add_argument("--entry", type=float, required=True)
    ps.add_argument("--stop", type=float, required=True)
    ps.add_argument("--target", type=float, required=True)
    ps.add_argument("--capital", type=float, default=config.STARTING_CAPITAL)
    ps.add_argument("--risk", type=float, default=config.RISK_PER_TRADE_PCT,
                    help="Fraction of capital to risk (e.g. 0.01 for 1 percent).")
    ps.set_defaults(func=cmd_size)

    pt = sub.add_parser("template", help="Write a blank journal CSV template.")
    pt.add_argument("--out", default=config.TEMPLATE_FILE)
    pt.set_defaults(func=cmd_template)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except (FileNotFoundError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

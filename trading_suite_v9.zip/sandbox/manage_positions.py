"""
Position manager — stops a winner from turning into a loser.

The single most common mistake (yours included): holding for the full target,
then giving the whole profit back when price reverses. This tool enforces the
fix, mechanically, for every open trade:

  1. Once a trade is up ~+1R, MOVE THE STOP TO BREAKEVEN  -> it can no longer
     become a loss.
  2. Beyond that, TRAIL the stop with ATR (locks in more gain as it runs).
  3. When the mean-reversion BOUNCE completes (RSI(14) recovered, or price back
     above its 10-day average), TAKE PROFIT / a partial -> don't wait greedily
     for a target that may never come.

Usage
-----
  # maintain data/open_positions.csv (ticker,direction,entry,stop,target,qty)
  python manage_positions.py

  # or check a single position on the fly
  python manage_positions.py --ticker LNT --entry 75.39 --stop 71.98 \
        --target 81.84 --qty 132 --direction long

Works for US tickers, and for Indian NSE names add ".NS" (e.g. RELIANCE.NS).
"""
from __future__ import annotations

import argparse
import os
from datetime import date, timedelta

import numpy as np
import pandas as pd

from backtest import data as datamod
from backtest import indicators as ind

POS_FILE = os.path.join("data", "open_positions.csv")


def _sign(direction: str) -> int:
    return 1 if direction.upper() == "LONG" else -1


def analyse_position(row: dict, lookback_days: int, trail_atr: float,
                     be_trigger_r: float):
    tkr = row["ticker"].upper()
    direction = str(row.get("direction", "long")).upper()
    entry = float(row["entry"]); stop = float(row["stop"])
    target = float(row["target"]); qty = float(row["qty"])
    s = _sign(direction)

    today = date.today()
    start = (today - timedelta(days=lookback_days)).isoformat()
    try:
        data = datamod.get_data([tkr], start, today.isoformat(), use_cache=True)
        df = data[tkr]
        last = float(df["Close"].iloc[-1])
        atr = float(ind.atr(df["High"], df["Low"], df["Close"], 14).iloc[-1])
        rsi14 = float(ind.rsi(df["Close"], 14).iloc[-1])
        sma10 = float(ind.sma(df["Close"], 10).iloc[-1])
        as_of = df.index[-1].date().isoformat()
    except Exception as exc:
        return {"ticker": tkr, "error": f"data error: {exc}"}

    risk_ps = abs(entry - stop)
    r1 = risk_ps * qty                       # 1R in $
    pnl = (last - entry) * qty * s
    pnl_pct = (last / entry - 1.0) * s
    r_now = pnl / r1 if r1 else 0.0

    # breakeven & trailing suggestions
    breakeven = entry
    chandelier = last - trail_atr * atr if s > 0 else last + trail_atr * atr
    if s > 0:
        new_stop = max(stop, breakeven if r_now >= be_trigger_r else stop,
                       chandelier if r_now >= 1.0 else stop)
        new_stop = min(new_stop, last)       # never above price
    else:
        new_stop = min(stop, breakeven if r_now >= be_trigger_r else stop,
                       chandelier if r_now >= 1.0 else stop)
        new_stop = max(new_stop, last)

    # bounce-complete (mean-reversion exit) signal
    bounce = (rsi14 >= 55) or (last > sma10 if s > 0 else last < sma10)

    # recommendation
    if s > 0 and last <= stop or s < 0 and last >= stop:
        action = "STOP HIT — should already be closed"
    elif r_now >= 1.0 and bounce:
        action = "TAKE PROFIT (bounce done, >1R) — book it or sell half + trail rest"
    elif r_now >= be_trigger_r:
        moved = abs(new_stop - stop) > 0.01
        action = (f"MOVE STOP -> {new_stop:.2f} "
                  + ("(breakeven/trail — now can't lose)" if moved
                     else "(already protected)"))
    elif bounce and r_now > 0:
        action = "Bounce forming — consider partial profit; raise stop toward entry"
    elif r_now > 0:
        action = "HOLD — in profit but <1R; let it develop, keep stop"
    else:
        action = "HOLD — keep stop; thesis intact until stop/target"

    return {
        "ticker": tkr, "dir": direction, "as_of": as_of,
        "last": round(last, 2), "entry": round(entry, 2),
        "pnl$": round(pnl, 2), "pnl%": round(pnl_pct * 100, 2),
        "R_now": round(r_now, 2), "cur_stop": round(stop, 2),
        "suggested_stop": round(new_stop, 2), "target": round(target, 2),
        "rsi14": round(rsi14, 1), "action": action,
    }


def main():
    p = argparse.ArgumentParser(description="Manage open positions: breakeven / "
                                            "trail / partial-exit guidance.")
    p.add_argument("--ticker"); p.add_argument("--entry", type=float)
    p.add_argument("--stop", type=float); p.add_argument("--target", type=float)
    p.add_argument("--qty", type=float); p.add_argument("--direction", default="long")
    p.add_argument("--file", default=POS_FILE)
    p.add_argument("--lookback-days", type=int, default=420)
    p.add_argument("--trail-atr", type=float, default=2.5,
                   help="ATR multiple for the trailing (chandelier) stop.")
    p.add_argument("--be-trigger", type=float, default=1.0,
                   help="Profit in R at which to pull the stop to breakeven.")
    args = p.parse_args()

    if args.ticker:
        rows = [{"ticker": args.ticker, "direction": args.direction,
                 "entry": args.entry, "stop": args.stop,
                 "target": args.target, "qty": args.qty}]
    elif os.path.exists(args.file):
        rows = pd.read_csv(args.file).to_dict("records")
    else:
        print(f"No positions given. Create {args.file} with columns:\n"
              "  ticker,direction,entry,stop,target,qty\n"
              "or pass --ticker/--entry/--stop/--target/--qty.")
        return 1

    results = [analyse_position(r, args.lookback_days, args.trail_atr,
                                args.be_trigger) for r in rows]
    print(f"\nRule: at +{args.be_trigger:.0f}R move stop to breakeven; "
          f"trail at {args.trail_atr}xATR; book on the bounce.\n")
    hdr = (f"{'Ticker':<8}{'Last':>9}{'PnL$':>10}{'PnL%':>7}{'R':>6}"
           f"{'Stop':>9}{'->Stop':>9}  ACTION")
    print(hdr); print("-" * 96)
    for r in results:
        if "error" in r:
            print(f"{r['ticker']:<8}  {r['error']}"); continue
        print(f"{r['ticker']:<8}{r['last']:>9.2f}{r['pnl$']:>10.2f}"
              f"{r['pnl%']:>6.1f}%{r['R_now']:>6.2f}{r['cur_stop']:>9.2f}"
              f"{r['suggested_stop']:>9.2f}  {r['action']}")
    print("\nWhy this works: once the stop is at breakeven, the WORST case is $0 "
          "— a winner can never turn into a loser again. That single habit fixes "
          "the 'it was green, then went red' problem.\n"
          "Educational tool — not investment advice.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""
Per-ticker technical analysis: an annotated multi-panel chart + a written read.

Studies the chart the way an analyst would — trend (moving averages),
volatility (Bollinger bands), momentum (RSI, MACD), and trend strength (ADX) —
and prints a plain-English summary plus a 0-100 confluence score.

Examples
--------
  python analyze_ticker.py AAPL
  python analyze_ticker.py NVDA --lookback-days 500
  python analyze_ticker.py JPM MSFT XOM      # several at once
"""
from __future__ import annotations

import argparse
import os
from datetime import date, timedelta

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

from backtest import data as datamod
from backtest import indicators as ind
from backtest import analysis as ta

OUT_DIR = os.path.join("output", "analysis")


def make_chart(ticker: str, df) -> str:
    os.makedirs(OUT_DIR, exist_ok=True)
    close, high, low, vol = df["Close"], df["High"], df["Low"], df["Volume"]
    sma20, sma50, sma200 = ind.sma(close, 20), ind.sma(close, 50), ind.sma(close, 200)
    bb_mid, bb_up, bb_lo = ind.bollinger(close, 20, 2.0)
    rsi14 = ind.rsi(close, 14)
    macd_line, macd_sig, macd_hist = ind.macd(close)
    adx_, pdi, mdi = ind.adx(high, low, close, 14)
    idx = df.index

    fig, axes = plt.subplots(
        5, 1, figsize=(13, 13), sharex=True,
        gridspec_kw={"height_ratios": [3, 1, 1.2, 1.2, 1.2]})
    fig.suptitle(f"{ticker.upper()} — Technical Analysis  "
                 f"({idx[0].date()} to {idx[-1].date()})",
                 fontsize=15, fontweight="bold")

    # 1) price + MAs + Bollinger
    ax = axes[0]
    ax.plot(idx, close, color="black", lw=1.3, label="Close")
    ax.plot(idx, sma20, color="#1f77b4", lw=1, label="SMA20")
    ax.plot(idx, sma50, color="#ff7f0e", lw=1, label="SMA50")
    ax.plot(idx, sma200, color="#d62728", lw=1.2, label="SMA200")
    ax.fill_between(idx, bb_lo, bb_up, color="#9467bd", alpha=0.12,
                    label="Bollinger(20,2)")
    ax.set_ylabel("Price ($)")
    ax.legend(ncol=5, fontsize=8, loc="upper left")
    ax.grid(alpha=0.3)

    # 2) volume
    ax = axes[1]
    ax.bar(idx, vol, color="#888888", width=1.0)
    ax.plot(idx, ind.sma(vol, 20), color="black", lw=0.8, label="Vol SMA20")
    ax.set_ylabel("Volume")
    ax.legend(fontsize=8, loc="upper left")
    ax.grid(alpha=0.3)

    # 3) RSI
    ax = axes[2]
    ax.plot(idx, rsi14, color="#2166ac", lw=1)
    ax.axhline(70, color="#d73027", ls="--", lw=0.8)
    ax.axhline(30, color="#1a9850", ls="--", lw=0.8)
    ax.set_ylim(0, 100)
    ax.set_ylabel("RSI(14)")
    ax.grid(alpha=0.3)

    # 4) MACD
    ax = axes[3]
    ax.plot(idx, macd_line, color="#2166ac", lw=1, label="MACD")
    ax.plot(idx, macd_sig, color="#ff7f0e", lw=1, label="Signal")
    ax.bar(idx, macd_hist, color=["#1a9850" if v >= 0 else "#d73027"
                                  for v in macd_hist.fillna(0)], width=1.0)
    ax.axhline(0, color="black", lw=0.6)
    ax.set_ylabel("MACD")
    ax.legend(fontsize=8, loc="upper left")
    ax.grid(alpha=0.3)

    # 5) ADX
    ax = axes[4]
    ax.plot(idx, adx_, color="black", lw=1.2, label="ADX")
    ax.plot(idx, pdi, color="#1a9850", lw=0.9, label="+DI")
    ax.plot(idx, mdi, color="#d73027", lw=0.9, label="-DI")
    ax.axhline(25, color="grey", ls="--", lw=0.8)
    ax.set_ylabel("ADX / DI")
    ax.legend(fontsize=8, loc="upper left")
    ax.grid(alpha=0.3)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%b %y"))

    fig.tight_layout(rect=[0, 0, 1, 0.98])
    out = os.path.join(OUT_DIR, f"{ticker.upper()}.png")
    try:
        fig.savefig(out, dpi=130)
    except PermissionError:
        import time
        out = out.replace(".png", f"_{int(time.time())}.png")
        fig.savefig(out, dpi=130)
        print(f"  ! chart file was open/locked — saved to {out} instead.")
    plt.close(fig)
    return out


def main() -> int:
    p = argparse.ArgumentParser(description="Technical analysis + chart for tickers.")
    p.add_argument("tickers", nargs="+")
    p.add_argument("--lookback-days", type=int, default=420)
    p.add_argument("--no-cache", action="store_true")
    args = p.parse_args()

    today = date.today()
    start = (today - timedelta(days=args.lookback_days)).isoformat()
    end = today.isoformat()

    data = datamod.get_data([t.upper() for t in args.tickers], start, end,
                            use_cache=not args.no_cache)
    for t in args.tickers:
        t = t.upper()
        if t not in data or len(data[t]) < 210:
            print(f"\n{t}: not enough data.\n")
            continue
        df = data[t]
        print()
        print(ta.summary(t, df))
        path = make_chart(t, df)
        print(f"  Chart saved: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

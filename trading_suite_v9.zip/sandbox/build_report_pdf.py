"""
Builds a detailed presentation PDF about the swing-trading backtest model,
written in the voice of a student explaining the project to a professor.

Run:  python build_report_pdf.py
Output: Swing_Trading_Model_Report.pdf
"""
from __future__ import annotations

import os
from datetime import date

from reportlab.lib import colors
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                TableStyle, Image, PageBreak, HRFlowable)

# ----- editable header details -----
STUDENT_NAME = "[Your Name]"
ROLL_NO = "[Your Roll No.]"
PROFESSOR = "[Professor's Name]"
COURSE = "Finance / Investments — Paper Trading Assignment"

OUT_PDF = "Swing_Trading_Model_Report.pdf"
BT = os.path.join("output", "backtest")
AN = os.path.join("output", "analysis")

# ---------------------------------------------------------------------------
styles = getSampleStyleSheet()
NAVY = colors.HexColor("#1f3864")
BLUE = colors.HexColor("#2166ac")
GREY = colors.HexColor("#555555")

H1 = ParagraphStyle("H1", parent=styles["Heading1"], textColor=NAVY,
                    fontSize=16, spaceBefore=14, spaceAfter=8)
H2 = ParagraphStyle("H2", parent=styles["Heading2"], textColor=BLUE,
                    fontSize=12.5, spaceBefore=10, spaceAfter=5)
BODY = ParagraphStyle("BODY", parent=styles["BodyText"], fontSize=10.5,
                      leading=15, alignment=TA_JUSTIFY, spaceAfter=7)
NOTE = ParagraphStyle("NOTE", parent=BODY, textColor=GREY, fontSize=9.5,
                      leading=13)
BULLET = ParagraphStyle("BULLET", parent=BODY, leftIndent=14, spaceAfter=3)
TITLE = ParagraphStyle("TITLE", parent=styles["Title"], textColor=NAVY,
                       fontSize=24, leading=28)
SUB = ParagraphStyle("SUB", parent=styles["Normal"], fontSize=12,
                     alignment=TA_CENTER, textColor=GREY)
CENTER = ParagraphStyle("CENTER", parent=BODY, alignment=TA_CENTER)


def P(txt, style=BODY):
    return Paragraph(txt, style)


def bullets(items):
    return [Paragraph(f"&bull;&nbsp;&nbsp;{it}", BULLET) for it in items]


def img(path, width=16 * cm):
    if not os.path.exists(path):
        return P(f"<i>[chart not found: {path}]</i>", NOTE)
    from reportlab.lib.utils import ImageReader
    iw, ih = ImageReader(path).getSize()
    return Image(path, width=width, height=width * ih / iw)


def table(data, col_widths=None, header=True, font=9):
    t = Table(data, colWidths=col_widths, hAlign="LEFT")
    style = [
        ("FONTSIZE", (0, 0), (-1, -1), font),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#bbbbbb")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
    ]
    if header:
        style += [("BACKGROUND", (0, 0), (-1, 0), NAVY),
                  ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                  ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                  ("ROWBACKGROUNDS", (0, 1), (-1, -1),
                   [colors.white, colors.HexColor("#eef2f8")])]
    t.setStyle(TableStyle(style))
    return t


def hr():
    return HRFlowable(width="100%", thickness=0.6, color=colors.HexColor("#cccccc"),
                      spaceBefore=6, spaceAfter=6)


# ---------------------------------------------------------------------------
def build():
    doc = SimpleDocTemplate(OUT_PDF, pagesize=A4, topMargin=1.6 * cm,
                            bottomMargin=1.6 * cm, leftMargin=2 * cm,
                            rightMargin=2 * cm, title="Swing Trading Model Report",
                            author=STUDENT_NAME)
    S = []

    # ---------------- COVER ----------------
    S += [Spacer(1, 3 * cm)]
    S += [P("A Systematic Swing-Trading &amp; Backtesting Model", TITLE)]
    S += [Spacer(1, 0.3 * cm)]
    S += [P("Built and tested on 15+ years of real US stock-market data", SUB)]
    S += [Spacer(1, 1.4 * cm)]
    S += [P(f"<b>Course:</b> {COURSE}", CENTER)]
    S += [P(f"<b>Submitted by:</b> {STUDENT_NAME} ({ROLL_NO})", CENTER)]
    S += [P(f"<b>Submitted to:</b> {PROFESSOR}", CENTER)]
    S += [P(f"<b>Date:</b> {date.today().strftime('%d %B %Y')}", CENTER)]
    S += [Spacer(1, 1.6 * cm)]
    S += [P("<i>Respected Sir/Ma'am, this report explains the trading model I "
            "built for our paper-trading assignment — what it does, the ideas "
            "and indicators behind it, how I tested it on real historical data, "
            "and — very importantly — what it honestly can and cannot do. I have "
            "tried to explain each part in simple language so that the logic is "
            "clear.</i>", NOTE)]
    S += [PageBreak()]

    # ---------------- 1. INTRODUCTION ----------------
    S += [P("1. Introduction &amp; Objective", H1)]
    S += [P("Sir, our assignment was to paper-trade a virtual capital of "
            "<b>US $100,000</b>, complete a minimum of <b>60 trades</b>, and try "
            "to earn a good profit while protecting the capital from big losses. "
            "Instead of picking stocks by guesswork, I decided to build a proper "
            "<b>rule-based system</b> — a computer model that follows the same "
            "logic every single time, with no emotions involved.", BODY)]
    S += [P("The model has two halves:", BODY)]
    S += bullets([
        "<b>A research half (the backtester)</b> — it downloads 15+ years of "
        "real market data and checks how a trading strategy <i>would have</i> "
        "performed in the past, so I can trust it before using it.",
        "<b>A live half (scanner + trade calculator)</b> — every day it tells me "
        "which stocks match my strategy and exactly how many shares to buy, "
        "where to keep the stop-loss, and where to book profit."])
    S += [P("This document explains the whole system, the results I got, and the "
            "honest conclusions — including the parts that did <i>not</i> work as "
            "expected, because I believe being truthful about that is the most "
            "important part of research.", BODY)]

    # ---------------- 2. WHAT IT DOES ----------------
    S += [P("2. What the Model Does (in simple words)", H1)]
    S += [P("The model answers three questions:", BODY)]
    S += bullets([
        "<b>\"Does this strategy actually work?\"</b> — by testing it on 15 years "
        "of real data (the backtest).",
        "<b>\"Is that success real, or just luck/curve-fitting?\"</b> — by testing "
        "it separately on older and newer time periods (out-of-sample test).",
        "<b>\"What should I buy today, and exactly how much?\"</b> — the live "
        "scanner and trade calculator."])
    S += [P("In one line: <b>it turns raw price data into disciplined buy/sell "
            "decisions, measures honestly how those rules performed versus the "
            "market, and then tells me what to trade today with correct risk "
            "sizing.</b>", BODY)]

    # ---------------- 3. DATA ----------------
    S += [P("3. The Data It Uses", H1)]
    S += bullets([
        "<b>Source:</b> real daily price data (Open, High, Low, Close, Volume) "
        "from Yahoo Finance, adjusted for splits and dividends.",
        "<b>Universe:</b> the full <b>S&amp;P 500</b> (around 500 of the largest "
        "US companies), fetched automatically with their sectors.",
        "<b>Period:</b> January 2010 to July 2026 — over <b>15 years</b>, covering "
        "bull markets, the 2020 COVID crash, and the 2022 bear market.",
        "<b>Caching:</b> the data is saved locally, so after the first download "
        "it runs fast and even works offline."])
    S += [PageBreak()]

    # ---------------- 4. INDICATORS ----------------
    S += [P("4. The Technical Indicators It Applies", H1)]
    S += [P("Sir, the model calculates the standard indicators that analysts use "
            "to read a chart. Each one measures a different thing:", BODY)]
    ind_rows = [
        ["Indicator", "What it measures", "Why it is used"],
        ["SMA / EMA (20/50/200)", "Average price / trend", "Is the stock in an up or down trend?"],
        ["RSI (2 &amp; 14)", "Overbought / oversold", "Timing the dip to buy"],
        ["MACD", "Momentum shift", "Is momentum turning up or down?"],
        ["ADX (+DI / -DI)", "Trend strength", "Is there a real trend or just noise?"],
        ["ATR (14)", "Volatility", "Used to place a sensible stop-loss"],
        ["Bollinger Bands / %B", "Price stretch vs normal", "How far from average is the price?"],
        ["Stochastic (%K/%D)", "Momentum position", "Confirming oversold/overbought"],
        ["OBV", "Volume flow", "Is volume supporting the move?"],
        ["ROC (3m / 6m)", "Momentum / return", "Is the stock a strong performer?"],
    ]
    S += [table(ind_rows, col_widths=[4.2 * cm, 5.3 * cm, 6.5 * cm])]
    S += [Spacer(1, 0.3 * cm)]
    S += [P("These are combined into a single <b>0–100 \"confluence score\"</b> "
            "(explained in Section 6) so that many indicators can be judged "
            "together in one number.", NOTE)]

    # ---------------- 5. STRATEGIES ----------------
    S += [P("5. The Trading Strategies", H1)]
    S += [P("The model has four well-known, proven strategies. I can run any of "
            "them and compare:", BODY)]
    strat_rows = [
        ["Strategy", "Idea (simple words)", "Style"],
        ["RSI-2 (mean reversion)", "Buy a strong stock when it dips and is very oversold; sell when it bounces back.", "High win-rate"],
        ["Bollinger", "Buy when price falls below the lower band in an uptrend; exit at the middle band.", "Mean reversion"],
        ["SMA Cross (trend)", "Buy when the 50-day average crosses above the 200-day; ride the trend.", "High profit"],
        ["TrendPullback (hybrid)", "Buy small dips ONLY in strong leaders (uptrend + positive momentum). My main strategy.", "Best win-rate"],
    ]
    S += [table(strat_rows, col_widths=[3.8 * cm, 9.2 * cm, 3 * cm])]
    S += [Spacer(1, 0.2 * cm)]
    S += [P("Every strategy has strict written rules for <b>entry</b>, "
            "<b>exit</b>, and a <b>stop-loss</b>, so the computer always behaves "
            "the same way. There is no guessing.", NOTE)]

    # ---------------- 6. CONFLUENCE SCORE ----------------
    S += [P("6. The Confluence Score", H1)]
    S += [P("Instead of looking at ten indicators separately, I blend them into "
            "one <b>0–100 score</b> that answers: \"how healthy is this setup?\" "
            "It rewards a stock that is in a proper uptrend, has positive "
            "momentum, rising MACD, a real trend (ADX) and good volume — and "
            "penalises a stock that is over-stretched. The model uses this score "
            "to <b>rank</b> which stocks to buy first when there are many "
            "choices.", BODY)]

    # ---------------- 7. RISK MANAGEMENT ----------------
    S += [P("7. Risk Management (the most important part)", H1)]
    S += [P("Sir, my main aim was to <b>protect the capital</b>. The model follows "
            "strict risk rules on every single trade:", BODY)]
    S += bullets([
        "<b>1% rule:</b> never risk more than 1% of capital (about $1,000) on one "
        "trade. If the stop-loss is hit, that is the most I lose.",
        "<b>Position size formula:</b> shares = (capital &times; 1%) &divide; "
        "(entry price &minus; stop price).",
        "<b>ATR-based stop-loss:</b> the stop is placed using the stock's own "
        "volatility, so it is neither too tight nor too loose.",
        "<b>Reward:risk of at least 2:1:</b> I aim to make at least twice what I "
        "risk.",
        "<b>Maximum 10% of capital in one stock</b>, and a market-regime filter "
        "that only allows buying when the overall market (S&amp;P 500) is above "
        "its 200-day average."])
    S += [PageBreak()]

    # ---------------- 8. ENGINE ----------------
    S += [P("8. The Backtesting Engine (how the test is fair)", H1)]
    S += [P("A backtest is only useful if it is honest. My engine is built to "
            "avoid the common cheating mistakes:", BODY)]
    S += bullets([
        "<b>No looking into the future:</b> a buy signal is read at today's "
        "closing price and the order is filled at the <i>next</i> day's opening "
        "price — exactly like real life.",
        "<b>Real costs:</b> a brokerage commission and slippage are subtracted on "
        "every trade, so profits are not imaginary.",
        "<b>Bounded risk:</b> every trade has a stop-loss and a maximum holding "
        "period, so no single loss can become huge.",
        "<b>Portfolio limits:</b> a maximum number of trades at once and a fixed "
        "size per trade, so the account cannot over-invest."])

    # ---------------- 9. METRICS ----------------
    S += [P("9. Performance Metrics (how I judge results)", H1)]
    met_rows = [
        ["Metric", "Meaning"],
        ["Win rate", "% of trades that made a profit"],
        ["CAGR", "Yearly compounded return"],
        ["Max drawdown", "Worst drop from a peak (how much pain)"],
        ["Profit factor", "Total profit &divide; total loss (&gt;1 = profitable)"],
        ["Reward : risk / R-multiple", "Profit earned per unit of risk taken"],
        ["Sharpe / Sortino", "Return earned per unit of risk (higher = better)"],
        ["Expectancy", "Average profit expected per trade"],
        ["vs SPY (benchmark)", "Did I beat simply buying the S&amp;P 500 index?"],
    ]
    S += [table(met_rows, col_widths=[5.5 * cm, 10.5 * cm])]

    # ---------------- 10. RESULTS ----------------
    S += [P("10. Results — Full S&amp;P 500, 2010 to 2026", H1)]
    S += [P("I tested all four strategies on the full S&amp;P 500 over 15+ years. "
            "Here is the honest comparison (SPY = simply buying the index):", BODY)]
    res_rows = [
        ["Strategy", "Win rate", "CAGR", "vs SPY", "Max DD", "Profit factor"],
        ["RSI-2", "62.6%", "+5.0%", "-9.1%", "-28.1%", "1.09"],
        ["Bollinger", "57.3%", "+6.4%", "-7.8%", "-24.5%", "1.14"],
        ["SMA Trend", "50.7%", "+33.8%", "+19.6%", "-43.4%", "6.60"],
        ["TrendPullback", "64.3%", "+5.2%", "-9.0%", "-36.2%", "1.08"],
        ["SPY buy &amp; hold", "—", "+14.1%", "—", "-33.7%", "—"],
    ]
    S += [table(res_rows, col_widths=[3.6 * cm, 2.4 * cm, 2.2 * cm, 2.2 * cm,
                                      2.4 * cm, 3 * cm])]
    S += [Spacer(1, 0.35 * cm)]
    S += [img(os.path.join(BT, "comparison.png"))]
    S += [P("<i>Figure 1: Growth of $100,000 under each strategy versus the "
            "market (log scale).</i>", NOTE)]
    S += [PageBreak()]
    S += [img(os.path.join(BT, "equity_curve.png"))]
    S += [P("<i>Figure 2: My main strategy (TrendPullback) equity curve versus "
            "SPY buy-and-hold.</i>", NOTE)]
    S += [Spacer(1, 0.3 * cm)]
    S += [img(os.path.join(BT, "drawdown.png"))]
    S += [P("<i>Figure 3: The drawdown (\"underwater\") curve — how far the "
            "account fell from its peak at any time.</i>", NOTE)]
    S += [PageBreak()]

    # ---------------- 11. OOS ----------------
    S += [P("11. Out-of-Sample Test (is the result trustworthy?)", H1)]
    S += [P("To check the strategy is not just \"fitted\" to old data, I split the "
            "history into two separate periods and measured each one:", BODY)]
    oos_rows = [
        ["Period", "Return", "CAGR", "Win rate", "Max DD"],
        ["In-sample 2010–2018", "+88%", "+7.3%", "65.2%", "-14.2%"],
        ["Out-of-sample 2019–2026", "+22%", "+2.7%", "63.3%", "-36.2%"],
    ]
    S += [table(oos_rows, col_widths=[5.5 * cm, 2.6 * cm, 2.4 * cm, 2.6 * cm,
                                      2.6 * cm])]
    S += [Spacer(1, 0.25 * cm)]
    S += [P("<b>The important result:</b> the <b>win rate stayed almost the same "
            "(65% &rarr; 63%)</b> across two completely different market periods. "
            "This tells me the high win-rate edge is <b>real and consistent</b>, "
            "not a fluke. (Returns and drawdown were worse in 2019–2026 because "
            "that period included the COVID crash and the 2022 fall.)", BODY)]

    # ---------------- 12. HONEST FINDINGS ----------------
    S += [P("12. My Honest Conclusions", H1)]
    S += [P("Sir, these are the real lessons from the data — including what "
            "surprised me:", BODY)]
    S += bullets([
        "<b>High win-rate and high profit pull in opposite directions.</b> Mean "
        "reversion gave the best win-rate (62–64%) but modest profit. Trend "
        "following gave the highest profit (beat the market) but a lower win-rate "
        "and deeper falls. You cannot maximise both at once.",
        "<b>More indicators did NOT increase accuracy.</b> When I grouped trades "
        "by their confluence score, the win-rate stayed flat (~64%) at every "
        "level — even the highest-scoring trades did not win more. Adding "
        "indicators mostly adds noise, not edge. This was an eye-opener.",
        "<b>A bigger universe did not help.</b> Going from a few quality names to "
        "all 500 gave more trades but lower quality — quality beats quantity.",
        "<b>\"No losses\" is not possible — but \"small losses\" is.</b> Every "
        "strategy had losing trades, but my risk rules kept drawdowns much "
        "smaller than a random approach."])
    S += [PageBreak()]

    # ---------------- 13. LIVE TOOLS ----------------
    S += [P("13. How I Use It Live (daily workflow)", H1)]
    S += [P("Besides the backtest, the model gives me practical daily tools:", BODY)]
    S += bullets([
        "<b>Live scanner:</b> each day it scans all 500 stocks and lists the ones "
        "that match my strategy today, ranked by score, already sized at 1% risk, "
        "and it warns me if a company has earnings coming up.",
        "<b>Trade calculator:</b> for any stock it gives the exact shares to buy, "
        "the stop-loss, the target, the maximum loss, and the profit at target.",
        "<b>Chart analysis:</b> for any stock it prints a full technical read and "
        "draws a 5-panel chart (price + averages, volume, RSI, MACD, ADX)."])
    S += [Spacer(1, 0.3 * cm)]
    S += [img(os.path.join(AN, "AAPL.png"), width=15 * cm)]
    S += [P("<i>Figure 4: Example of the automatic chart analysis (Apple), "
            "showing price with moving averages and Bollinger bands, volume, "
            "RSI, MACD and ADX in one view.</i>", NOTE)]
    S += [Spacer(1, 0.3 * cm)]
    S += [P("<b>My daily routine:</b> run the scanner &rarr; pick 3–4 clean "
            "setups in different sectors &rarr; size each with the calculator "
            "&rarr; place the orders in TradingView paper trading with the "
            "stop-loss and target &rarr; note the trade in a journal. Doing this "
            "over two weeks easily gives the 60+ trades required.", BODY)]

    # ---------------- 14. HOW TO RUN ----------------
    S += [P("14. How to Run It", H1)]
    run_rows = [
        ["Command", "What it does"],
        ["python run_backtest.py --compare", "Test all strategies on 15 years"],
        ["python scan_live.py --sp500 --top 15", "Today's qualifying stocks"],
        ["python trade_calc.py --ticker AIZ", "Exact shares / stop / target"],
        ["python analyze_ticker.py AAPL", "Full chart + technical read"],
        ["python main.py report", "Grade my paper-trading journal"],
    ]
    S += [table(run_rows, col_widths=[8 * cm, 8 * cm], font=8.5)]

    # ---------------- 15. LIMITATIONS ----------------
    S += [P("15. Limitations &amp; Honesty (important)", H1)]
    S += bullets([
        "The test uses <b>today's</b> S&amp;P 500 companies, which have survived "
        "— this \"survivorship bias\" makes past results look a bit better than "
        "reality.",
        "2010–2026 was mostly a very strong bull market, so results may not "
        "repeat in a weak market.",
        "<b>News and earnings are used only for live decisions, not in the "
        "backtest</b>, because reliable 15-year news data is not freely available "
        "and using it would be unfair (looking into the future).",
        "<b>Past performance does not guarantee future results.</b> This is an "
        "educational project for the assignment, not real investment advice."])

    # ---------------- 16. CONCLUSION ----------------
    S += [P("16. Conclusion &amp; What I Learned", H1)]
    S += [P("Through this project I learned that successful trading is much more "
            "about <b>discipline and risk management</b> than about predicting the "
            "market. A simple rule followed every time, with a strict 1% "
            "stop-loss, protects capital far better than emotional guessing. I "
            "also learned the value of <b>testing honestly</b> — measuring on "
            "out-of-sample data and admitting when something (like adding more "
            "indicators) did not help.", BODY)]
    S += [P("For the assignment itself, I am using the high win-rate mean-reversion "
            "strategy (TrendPullback / RSI-2), because it gives many trades, a "
            "~64% win-rate, and controlled losses — which matches my goal of "
            "steady, safe profits rather than risky bets.", BODY)]
    S += [Spacer(1, 0.4 * cm)]
    S += [hr()]
    S += [P("Thank you, Sir/Ma'am, for reading. I would be happy to run any of "
            "these tools live during the presentation to demonstrate how they "
            "work.", NOTE)]

    doc.build(S)
    print(f"Wrote {OUT_PDF}")


if __name__ == "__main__":
    build()

"""Dedicated short-selling backtest model (mirror of the long suite)."""

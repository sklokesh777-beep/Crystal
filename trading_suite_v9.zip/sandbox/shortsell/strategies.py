"""
Short-selling strategies (the mirror image of the long suite).

Each strategy's `prepare(df)` returns the price frame plus:
    entry : bool  - a SHORT-entry (sell-short) signal at this bar's close
    exit  : bool  - a COVER (buy-to-close) signal at this bar's close
    rank  : float - priority when capital is limited (LOWER = take first)
    atr   : float - ATR(14), used to place a stop ABOVE entry
    score : float - short-setup confluence score (0-100, higher = better short)

The engine reads a signal at bar t's close and fills at bar t+1's open, so
there is no look-ahead.

Strategies
----------
1. ShortRSI2       - short a stock that is deeply OVERBOUGHT inside a DOWNTREND
                     (mirror of the long RSI-2 mean reversion).
2. ShortBollinger  - short a close ABOVE the upper band in a downtrend; cover at
                     the middle band.
3. ShortBreakdown  - short a bounce in a weak/downtrend LAGGARD (price < 200-SMA,
                     SMA50 < SMA200, negative 6-month momentum) — the mirror of
                     TrendPullback's "buy dips in leaders".
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from backtest import indicators as ind


def _clip01(s):
    return np.clip(s, 0.0, 1.0)


def short_quality_score(df: pd.DataFrame) -> pd.Series:
    """
    0-100 'short-setup quality' per bar (higher = healthier context for a
    SHORT). The mirror of the long confluence score: rewards a confirmed
    downtrend, negative momentum, MACD below zero, real trend strength (ADX)
    and volume, and penalises names already crashed far below the 200-SMA
    (snap-back risk).
    """
    close, high, low, vol = df["Close"], df["High"], df["Low"], df["Volume"]
    sma50 = ind.sma(close, 50)
    sma200 = ind.sma(close, 200)
    roc63 = ind.roc(close, 63)
    _, _, macd_hist = ind.macd(close)
    adx_, _, _ = ind.adx(high, low, close, 14)
    vol_sma = ind.sma(vol, 20)
    slope50 = ind.sma_slope(close, 50, 20)
    ext = close / sma200                       # <1 in a downtrend

    score = (
        20.0 * (close < sma200).astype(float)
        + 15.0 * (sma50 < sma200).astype(float)
        + 15.0 * _clip01(-roc63 / 20.0)        # negative momentum rewarded
        + 10.0 * (macd_hist < 0).astype(float)
        + 10.0 * _clip01((adx_ - 15.0) / 25.0)
        + 10.0 * (vol > vol_sma).astype(float)
        + 10.0 * _clip01(-slope50 / 10.0)      # falling 50-SMA rewarded
        # penalise already-crashed names (ext well below 1 -> snap-back risk)
        + 10.0 * (1.0 - _clip01((1.0 - ext) / 0.5))
    )
    return score.fillna(0.0).clip(0, 100)


class ShortStrategy:
    name: str = "base_short"
    max_hold_days: int = 10
    stop_atr_mult: float = 3.0   # stop = entry + mult * ATR (above entry)

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError


# ---------------------------------------------------------------------------
@dataclass
class ShortRSI2(ShortStrategy):
    trend_period: int = 200
    cover_sma: int = 5
    rsi_period: int = 2
    rsi_entry: float = 90.0        # deeply OVERBOUGHT
    rsi_cover: float = 35.0
    max_hold_days: int = 10
    stop_atr_mult: float = 3.0
    min_dollar_volume: float = 1e7
    min_up_days: int = 2           # require a genuine multi-day bounce
    rank_by: str = "score"
    name: str = "ShortRSI2"

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        close = out["Close"]
        out["trend"] = ind.sma(close, self.trend_period)
        out["cover_ma"] = ind.sma(close, self.cover_sma)
        out["rsi"] = ind.rsi(close, self.rsi_period)
        out["atr"] = ind.atr(out["High"], out["Low"], close, 14)
        out["score"] = short_quality_score(out)

        dollar_vol = (close * out["Volume"]).rolling(20, min_periods=20).mean()
        liquid = dollar_vol >= self.min_dollar_volume
        up = close > close.shift(1)
        up_streak = up
        for k in range(1, self.min_up_days):
            up_streak = up_streak & up.shift(k).fillna(False)
        bounce = up_streak if self.min_up_days > 0 else True

        out["entry"] = ((close < out["trend"]) &
                        (out["rsi"] > self.rsi_entry) &
                        liquid & bounce)
        # Cover when the drop resumes (below short MA) or RSI unwinds.
        out["exit"] = (close < out["cover_ma"]) | (out["rsi"] < self.rsi_cover)
        out["rank"] = -out["score"] if self.rank_by == "score" else -out["rsi"]
        return out


# ---------------------------------------------------------------------------
@dataclass
class ShortBollinger(ShortStrategy):
    trend_period: int = 200
    bb_period: int = 20
    bb_std: float = 2.0
    max_hold_days: int = 10
    stop_atr_mult: float = 3.0
    min_dollar_volume: float = 1e7
    name: str = "ShortBollinger"

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        close = out["Close"]
        mid, upper, lower = ind.bollinger(close, self.bb_period, self.bb_std)
        out["trend"] = ind.sma(close, self.trend_period)
        out["bb_mid"], out["bb_up"] = mid, upper
        out["atr"] = ind.atr(out["High"], out["Low"], close, 14)
        out["score"] = short_quality_score(out)
        dollar_vol = (close * out["Volume"]).rolling(20, min_periods=20).mean()
        liquid = dollar_vol >= self.min_dollar_volume

        out["entry"] = (close < out["trend"]) & (close > upper) & liquid
        out["exit"] = close <= mid
        std = (upper - mid) / self.bb_std
        # most stretched ABOVE the band first
        out["rank"] = -((close - mid) / std.replace(0.0, np.nan))
        return out


# ---------------------------------------------------------------------------
@dataclass
class ShortBreakdown(ShortStrategy):
    """Short a bounce in a weak downtrend laggard (mirror of TrendPullback)."""
    trend_period: int = 200
    align_fast: int = 50            # require SMA50 < SMA200 (downtrend structure)
    mom_period: int = 126           # ~6-month momentum must be NEGATIVE
    rsi_period: int = 4
    rsi_entry: float = 75.0         # a bounce into resistance to short
    rsi_cover: float = 45.0
    cover_sma: int = 10
    max_hold_days: int = 12
    stop_atr_mult: float = 2.5
    min_dollar_volume: float = 1e7
    rank_by: str = "score"
    name: str = "ShortBreakdown"

    def prepare(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        close = out["Close"]
        sma_slow = ind.sma(close, self.trend_period)
        sma_fast = ind.sma(close, self.align_fast)
        out["trend"] = sma_slow
        out["cover_ma"] = ind.sma(close, self.cover_sma)
        out["rsi"] = ind.rsi(close, self.rsi_period)
        out["atr"] = ind.atr(out["High"], out["Low"], close, 14)
        out["score"] = short_quality_score(out)
        mom = ind.roc(close, self.mom_period)
        dollar_vol = (close * out["Volume"]).rolling(20, min_periods=20).mean()

        laggard = (close < sma_slow) & (sma_fast < sma_slow) & (mom < 0)
        liquid = dollar_vol >= self.min_dollar_volume
        bounce = out["rsi"] > self.rsi_entry

        out["entry"] = laggard & liquid & bounce
        out["exit"] = (close < out["cover_ma"]) | (out["rsi"] < self.rsi_cover)
        out["rank"] = -out["score"] if self.rank_by == "score" else -out["rsi"]
        return out


SHORT_STRATEGIES = {
    "shortrsi2": ShortRSI2,
    "shortbollinger": ShortBollinger,
    "shortbreakdown": ShortBreakdown,
}


def build_short_strategy(name: str, **kwargs) -> ShortStrategy:
    key = name.lower()
    if key not in SHORT_STRATEGIES:
        raise ValueError(f"Unknown short strategy '{name}'. "
                         f"Choose from {list(SHORT_STRATEGIES)}.")
    return SHORT_STRATEGIES[key](**kwargs)

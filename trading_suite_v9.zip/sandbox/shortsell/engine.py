"""
Short-selling portfolio backtest engine.

The mirror of the long engine, with correct short mechanics:

  * Enter by SELLING short at the next bar's open (proceeds credited to cash).
  * The protective stop sits ABOVE entry; it is hit when the day's HIGH >= stop.
  * Cover (buy-to-close) on a stop, a strategy cover-signal, or a time stop.
  * P/L = (entry - exit) * shares  (you profit when the price falls).
  * A daily BORROW COST is charged on the short's market value (shorts are not
    free to hold) — a realism most naive short backtests omit.
  * Optional trailing stop ratchets the stop DOWN as price falls, never up.

No look-ahead: signals read at bar t's close, filled at bar t+1's open;
trailing stop uses only the last completed bar.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

import config
from backtest.engine import BacktestResult, _SymbolData
from shortsell.strategies import ShortStrategy


@dataclass
class ShortTrade:
    symbol: str
    strategy: str
    entry_date: pd.Timestamp
    entry_price: float
    exit_date: pd.Timestamp
    exit_price: float
    shares: int
    stop_price: float
    exit_reason: str
    entry_score: float = float("nan")
    initial_stop: float = float("nan")

    @property
    def pnl(self) -> float:                       # short: profit if exit < entry
        return (self.entry_price - self.exit_price) * self.shares

    @property
    def pnl_pct(self) -> float:
        return (self.entry_price - self.exit_price) / self.entry_price \
            if self.entry_price else 0.0

    @property
    def holding_days(self) -> int:
        return (self.exit_date - self.entry_date).days

    @property
    def r_multiple(self) -> float:
        base = self.initial_stop if np.isfinite(self.initial_stop) else self.stop_price
        risk = (base - self.entry_price) * self.shares     # stop is ABOVE entry
        return self.pnl / risk if risk > 0 else np.nan


@dataclass
class ShortPosition:
    symbol: str
    entry_date: pd.Timestamp
    entry_price: float
    shares: int
    stop_price: float
    initial_stop: float = float("nan")
    entry_score: float = float("nan")
    bars_held: int = 0


class ShortBacktester:
    def __init__(self,
                 strategy: ShortStrategy,
                 initial_capital: float = 100_000.0,
                 max_positions: int = 10,
                 position_size_pct: float = 0.10,
                 commission_per_trade: float = 1.0,
                 slippage_bps: float = 5.0,
                 borrow_annual: float = 0.01,     # ~1%/yr borrow cost on short MV
                 trailing_stop: bool = False):
        self.strategy = strategy
        self.initial_capital = initial_capital
        self.max_positions = max_positions
        self.position_size_pct = position_size_pct
        self.commission = commission_per_trade
        self.slip = slippage_bps / 10_000.0
        self.borrow_daily = borrow_annual / 252.0
        self.trailing_stop = trailing_stop

    def _sell_price(self, raw: float) -> float:   # short entry (fill worse = lower)
        return raw * (1.0 - self.slip)

    def _cover_price(self, raw: float) -> float:  # buy-to-close (fill worse = higher)
        return raw * (1.0 + self.slip)

    def run(self, data: Dict[str, pd.DataFrame],
            market_ok: "pd.Series | None" = None,
            exposure_multiplier: "pd.Series | None" = None) -> BacktestResult:
        # Short-friendly regime gate {date -> bool} (True = OK to short).
        regime = None
        if market_ok is not None:
            regime = {pd.Timestamp(d): bool(v) for d, v in market_ok.items()}
        expo = None
        if exposure_multiplier is not None:
            expo = {pd.Timestamp(d): float(v) for d, v in exposure_multiplier.items()}

        sym: Dict[str, _SymbolData] = {}
        for t, df in data.items():
            sym[t] = _SymbolData(self.strategy.prepare(df))

        all_dates = sorted(set().union(*[set(s.dates) for s in sym.values()]))
        all_dates = pd.DatetimeIndex(all_dates)

        cash = self.initial_capital
        positions: Dict[str, ShortPosition] = {}
        trades: List[ShortTrade] = []
        eq_dates, eq_vals, inv_vals = [], [], []

        for i in range(1, len(all_dates)):
            today = all_dates[i]
            prev = all_dates[i - 1]

            # ---- 1. COVERS (execute at today's open / stop) ------------
            for t in list(positions.keys()):
                p = positions[t]
                sd = sym[t]
                j = sd.pos_of.get(today)
                if j is None:
                    continue
                p.bars_held += 1

                # trailing stop: ratchet DOWN using last completed bar
                if self.trailing_stop and p.initial_stop > 0:
                    pj = sd.pos_of.get(prev)
                    if pj is not None and np.isfinite(sd.atr[pj]):
                        trail = sd.c[pj] + self.strategy.stop_atr_mult * sd.atr[pj]
                        if trail < p.stop_price:
                            p.stop_price = trail

                open_px = sd.o[j]
                high_px = sd.h[j]
                exit_reason = None
                fill = None

                if p.stop_price > 0 and high_px >= p.stop_price:
                    # gap up above stop -> fill at the open
                    fill = self._cover_price(max(open_px, p.stop_price))
                    exit_reason = "stop"
                else:
                    pj = sd.pos_of.get(prev)
                    signalled = pj is not None and sd.exit[pj]
                    timed_out = p.bars_held >= self.strategy.max_hold_days
                    if signalled:
                        fill, exit_reason = self._cover_price(open_px), "signal"
                    elif timed_out:
                        fill, exit_reason = self._cover_price(open_px), "time"

                if exit_reason:
                    cash -= fill * p.shares + self.commission   # buy to close
                    trades.append(ShortTrade(
                        symbol=t, strategy=self.strategy.name,
                        entry_date=p.entry_date, entry_price=p.entry_price,
                        exit_date=today, exit_price=fill, shares=p.shares,
                        stop_price=p.stop_price, exit_reason=exit_reason,
                        entry_score=p.entry_score, initial_stop=p.initial_stop))
                    del positions[t]

            # ---- 2. SHORT ENTRIES (rank, fill at today's open) ---------
            mult = 1.0 if expo is None else expo.get(prev, 1.0)
            ok = True if regime is None else regime.get(prev, True)
            if ok and mult > 0 and len(positions) < self.max_positions:
                candidates = []
                for t, sd in sym.items():
                    if t in positions:
                        continue
                    pj = sd.pos_of.get(prev)
                    j = sd.pos_of.get(today)
                    if pj is None or j is None:
                        continue
                    if sd.entry[pj] and np.isfinite(sd.o[j]) and sd.o[j] > 0:
                        candidates.append((sd.rank[pj], t))
                candidates.sort(key=lambda x: (np.inf if np.isnan(x[0]) else x[0]))

                # equity = cash - short liability
                liab = sum(positions[t].shares * self._last_close(sym[t], today)
                           for t in positions)
                mtm = cash - liab
                for _, t in candidates:
                    if len(positions) >= self.max_positions:
                        break
                    sd = sym[t]
                    j = sd.pos_of[today]
                    raw_open = sd.o[j]
                    price = self._sell_price(raw_open)
                    target_value = mtm * self.position_size_pct * mult
                    shares = int(target_value // price)
                    if shares <= 0:
                        continue
                    atr_val = sd.atr[j]
                    stop = (raw_open + self.strategy.stop_atr_mult * atr_val
                            if self.strategy.stop_atr_mult > 0 and np.isfinite(atr_val)
                            else 0.0)
                    cash += shares * price - self.commission   # short proceeds
                    pj = sd.pos_of.get(prev)
                    escore = sd.score[pj] if pj is not None else float("nan")
                    positions[t] = ShortPosition(
                        symbol=t, entry_date=today, entry_price=price,
                        shares=shares, stop_price=stop, initial_stop=stop,
                        entry_score=escore)

            # ---- 3. MARK TO MARKET + borrow cost -----------------------
            liab = 0.0
            for t, p in positions.items():
                liab += p.shares * self._last_close(sym[t], today)
            cash -= liab * self.borrow_daily          # daily borrow fee
            equity = cash - liab
            eq_dates.append(today)
            eq_vals.append(equity)
            inv_vals.append(liab / equity if equity > 0 else 0.0)

        equity_series = pd.Series(eq_vals, index=pd.DatetimeIndex(eq_dates),
                                  name="equity")
        invested_series = pd.Series(inv_vals, index=pd.DatetimeIndex(eq_dates),
                                    name="invested_pct")
        return BacktestResult(
            equity=equity_series, invested_pct=invested_series, trades=trades,
            initial_capital=self.initial_capital,
            strategy_name=self.strategy.name, universe=list(data.keys()))

    @staticmethod
    def _last_close(sd: _SymbolData, day: pd.Timestamp) -> float:
        j = sd.pos_of.get(day)
        if j is not None and np.isfinite(sd.c[j]):
            return sd.c[j]
        idx = sd.dates.searchsorted(day, side="right") - 1
        if 0 <= idx < len(sd.c):
            return sd.c[idx]
        return 0.0

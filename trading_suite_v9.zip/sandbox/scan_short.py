"""
LIVE short-selling scanner — the daily tool for the short side.

Finds names that are OVERBOUGHT inside a DOWNTREND (the short setups), shows
the short-friendly market regime (SPY below its 200-SMA), ranks candidates by
short-setup score, sizes each at 1% risk with a stop ABOVE entry, and flags
earnings + attaches news.

Examples
--------
  python scan_short.py                        # default 26-name basket
  python scan_short.py --sp500 --top 15 --skip-earnings
  python scan_short.py --strategy shortrsi2 --tickers TSLA XOM
"""
from __future__ import annotations

import argparse
import os
from datetime import date, timedelta

import numpy as np
import pandas as pd

from backtest import data as datamod
from backtest import fundamentals as fund
from backtest import indicators as ind
from backtest import universe as uni
from shortsell.strategies import build_short_strategy, SHORT_STRATEGIES

OUT_DIR = os.path.join("output", "short_live")


def parse_args():
    p = argparse.ArgumentParser(description="Live short-selling scanner.")
    p.add_argument("--strategy", default="shortbreakdown",
                   choices=list(SHORT_STRATEGIES))
    p.add_argument("--tickers", nargs="+", default=None)
    p.add_argument("--sp500", action="store_true")
    p.add_argument("--lookback-days", type=int, default=420)
    p.add_argument("--capital", type=float, default=100_000.0)
    p.add_argument("--risk", type=float, default=0.01)
    p.add_argument("--top", type=int, default=15)
    p.add_argument("--earnings-window", type=int, default=5)
    p.add_argument("--skip-earnings", action="store_true")
    p.add_argument("--no-news", action="store_true")
    p.add_argument("--no-cache", action="store_true")
    return p.parse_args()


def main():
    args = parse_args()
    today = date.today()
    start = (today - timedelta(days=args.lookback_days)).isoformat()

    if args.tickers:
        tickers = [t.upper() for t in args.tickers]
        sectors = {t: "" for t in tickers}
    elif args.sp500:
        tickers, sectors = uni.get_sp500()
    else:
        tickers = list(datamod.DEFAULT_UNIVERSE)
        sectors = {t: "" for t in tickers}
    if "SPY" not in tickers:
        tickers.append("SPY")

    print(f"Scanning {len(tickers)} names for SHORT setups "
          f"({start} -> {today}) ...")
    data = datamod.get_data(tickers, start, today.isoformat(),
                            use_cache=not args.no_cache)

    regime_ok = True
    if "SPY" in data:
        spy = data["SPY"]["Close"]
        regime_ok = bool(spy.iloc[-1] < ind.sma(spy, 200).iloc[-1])
    print("Short regime (SPY < 200-SMA): "
          + ("RISK-OFF - shorts favoured" if regime_ok
             else "RISK-ON - shorting is fighting an uptrend, be cautious") + "\n")

    strat = build_short_strategy(args.strategy)
    candidates = []
    for t, df in data.items():
        if t == "SPY" or len(df) < 210:
            continue
        last = strat.prepare(df).iloc[-1]
        if not bool(last.get("entry", False)):
            continue
        close = float(last["Close"])
        atr = float(last["atr"]) if np.isfinite(last["atr"]) else np.nan
        stop = close + strat.stop_atr_mult * atr if np.isfinite(atr) else np.nan
        candidates.append({
            "ticker": t, "sector": sectors.get(t, ""),
            "score": round(float(last.get("score", np.nan)), 0),
            "rsi": round(float(last.get("rsi", np.nan)), 1),
            "close": round(close, 2),
            "stop": round(stop, 2) if np.isfinite(stop) else np.nan,
        })
    candidates.sort(key=lambda c: (-c["score"] if np.isfinite(c["score"]) else 0))
    print(f"{len(candidates)} names triggered a SHORT signal today.\n")

    risk_budget = args.capital * args.risk
    rows = []
    for c in candidates[: args.top]:
        if np.isfinite(c["stop"]) and c["stop"] > c["close"] > 0:
            shares = int(risk_budget // (c["stop"] - c["close"]))
        else:
            shares = 0
        c["shares"] = shares
        c["notional"] = round(shares * c["close"], 2)
        d2e = fund.days_to_earnings(c["ticker"], today)
        c["days_to_earnings"] = d2e if d2e is not None else ""
        blackout = d2e is not None and 0 <= d2e <= args.earnings_window
        c["earnings_flag"] = "SKIP-earnings" if blackout else ""
        if not args.no_news:
            c["news_sentiment"] = round(fund.news_sentiment_score(c["ticker"], 8), 2)
            heads = fund.get_news(c["ticker"], 1)
            c["headline"] = heads[0].title[:70] if heads else ""
        else:
            c["news_sentiment"], c["headline"] = "", ""
        if args.skip_earnings and blackout:
            continue
        rows.append(c)

    if not rows:
        print("No qualifying SHORT setups today. (Normal — especially when the "
              "market is in an uptrend; shorts should be rare then.)")
    else:
        hdr = (f"{'#':>2} {'Ticker':<7}{'Score':>6}{'RSI':>6}{'Close':>9}"
               f"{'Stop':>9}{'Shares':>7}{'Notional':>11}{'ToEarn':>7}{'News':>6}"
               f"  Flag / Headline")
        print(hdr); print("-" * len(hdr))
        for i, c in enumerate(rows, 1):
            print(f"{i:>2} {c['ticker']:<7}{c['score']:>6.0f}{c['rsi']:>6.1f}"
                  f"{c['close']:>9.2f}"
                  f"{(c['stop'] if isinstance(c['stop'],(int,float)) else 0):>9.2f}"
                  f"{c['shares']:>7}{c['notional']:>11,.0f}"
                  f"{str(c['days_to_earnings']):>7}{str(c['news_sentiment']):>6}  "
                  f"{c['earnings_flag']} {c['headline']}")

    os.makedirs(OUT_DIR, exist_ok=True)
    if rows:
        path = os.path.join(OUT_DIR, f"short_watchlist_{today.isoformat()}.csv")
        try:
            pd.DataFrame(rows).to_csv(path, index=False)
            print(f"\nSaved: {path}")
        except PermissionError:
            print("\n(watchlist file locked — close it and re-run to save.)")
    print("\nReminder: shorting has unlimited-loss risk (squeezes), pays a "
          "borrow fee, and fights the market's long-term up-drift. Size small, "
          "always keep the stop, avoid earnings. Educational — not advice.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
